# UniverAcademy API Contract — 0.2.5-two-grading-review.1

**2026-11-05, Asia/Tashkent.** Joriy review, published release emas. Manbalar U5/U6: `USER_DECISIONS_2026-11-05.md`; exact xesh `REVIEW-SOURCE-INDEX.json`da. Oldingi `0.2.4-rasch-review.1` baseline uch baholash talabi endi tarixiy; faqat quyidagi ikki tizim amal qiladi. API texnik shakli agent reviewida, MAPni foydalanuvchi tanlagan deb yozilmaydi.

## 1. Ikki baholash

1. **Oddiy baholash — doimiy asosiy natija.** Teacher «Individual baholash» o‘chiq: har savol1; yoqilgan: har savol uchun0dan katta ball, kasr mumkin. To‘g‘riga asosiy ball, noto‘g‘riga0. Maksimal ball barcha asosiy ballar yig‘indisi>0. `Foiz=to‘plangan/maksimal×100`. Full precision hisoblanadi/saqlanadi, student ball/maksimal/foiz2 kasr bilan ko‘radi. Tugashi bilan saqlanadi, Raschni kutmaydi. Bo‘sh test va individual0/negative publish qilinmaydi. Midpoint rounding/storage scale hali texnik review.
2. **Rasch1PL — Teacher ixtiyoridagi qo‘shimcha tahlil.** `P(Xij=1)=1/(1+exp(-(θi−bj)))`. Teacherning savol ballari modelga kiritilmaydi. Rasch hisoblanmasa oddiy natija baribir ishlaydi; teacher tanlovi avtomatik majburiy bosqichga aylantirilmaydi.

Statistik bonus to‘liq chiqarildi: endpoint, request/response field, sxema, oldingi bonus formule/DB/UI/QA vazifalari joriy spetsifikatsiyada yo‘q. Bu ishlab turgan bazadan ma’lumot/jadval o‘chirish yoki migration bajarish topshirig‘i emas. Tarixiy fayllar `references/`da faqat manba sifatida.

## 2. Savollar soni va vaqt

Yangi testda boshlang‘ich **45 savol**, Teacher o‘zgartiradi. 45 qat’iy maksimum yoki hamma eski testni45ga aylantirish talabi emas. Actual published question set barcha savollarni belgilaydi; model40/45ga hardcode qilinmaydi. Mavjud content/Version endpoints Teacherga savollarni yozish/nashr qilishni beradi; yangi `question_count` request maydoni o‘ylab topilmadi. Panelda default45 ko‘rsatiladi, pinned versionda haqiqiy son olinadi.

Zona **Asia/Tashkent**, U6 bilan tasdiqlangan. Oldindan ro‘yxatdagi kechikkan start huquqi keyingi mahalliy kun00:00gacha (exclusive); auditoriya erta tugashi buni qisqartirmaydi. UTC cutoff IANA calendar orqali; misol 2026-11-06 00:00 Asia/Tashkent → 2026-11-05T19:00:00Z. Bu haqiqiy demo sanasi tanlangani emas. Boshlangan urinish full duration oladi, cutoffdan keyin tugashi mumkin. Rosterga keyin yangi odam qo‘shish qoidasi o‘zgartirilmadi.

## 3. Rasch statistikasiga kiradigan urinishlar

**Faqat o‘quvchi o‘zi muvaffaqiyatli yakunlagan valid current `submitted` urinish.** Boshlangan imtihonni vaqt tugashi yoki administrator yakunlasa (`expired/forced`), u ordinary natija oladi, Raschga kirmaydi. Deadlinega teng/keyin student submit qilsa ham oldingi timer qoidasi bo‘yicha `expired`; eligibilityni «o‘zi bosdi» deb ochmaydi. Texnik bekor predecessor, ready/in_progress/recovery_lapsed va testga kirmaganlar ham kiritilmaydi. Bir o‘quvchi uchun bir valid current self-submitted urinish; stable original group/demo/session/version, boshqalardan pooling yo‘q.

Kiritilgan urinishda javobsiz savol0, noto‘g‘ri0, to‘g‘ri1. All-zero self-submitted qator qoladi, no-show bilan aralashtirilmaydi. Barcha published savollar, shu jumladan extreme columns hisobda. Array UI shufflega emas stable question IDga bog‘lanadi.

Faollashtirish barrieri statistika tarkibidan kengroq: **barcha boshlangan** urinishlar tugashi va late admission/ready recovery huquqlari yakunlanishi shart. Expired/forced keyin matritsaga kirmaydi, lekin ularning hali davom etayotgan vaqtini kutish shart. Bitta logical run, same/different Kda ayni snapshot, final immutable. Hech kim self-submit qilmagan bo‘lsa empty sample, soxta μ/σ/T/daraja berilmaydi; typed unavailable ishlovi profilda ko‘rib chiqiladi.

## 4. Daraja va MAP holati

Oldingi user Rasch formula va `Z=(θ−μ)/σ`, `T=50+10Z`ni tasdiqlagan; shu cohort μ/σsi saqlanadi. T≥70 A+; [65,70) A; [60,65) B+; [55,60) B; [50,55) C+; [46,50) C; <46 darajasiz. T yaxlitlanmasdan solishtiriladi, oddiy ko‘rinish2 kasr Rasch thresholdni o‘zgartirmaydi. Bu guruh ichidagi UniverAcademy darajasi, davlat sertifikati bilan equating da’vosi emas.

**MAP hali yakuniy tanlov emas.** User «MAP - bu nima ozi» deb tushuntirish so‘radi. MAP — javoblarga mos parametrlarni, qo‘shimcha oldindan berilgan statistik taqsimotni ham hisobga olib topish usuli. Finite proper priors extreme holatdagi θ/bning cheksizlashishini oldini oluvchi taklif; prior kuchi natijaga ta’sir qiladi, bir xil va versioned bo‘lishi kerak. Sodda tushuntirish `MAP_TUSHUNTIRISH.md`da, aniq proposed objective/profil Backend rejasida. Userning izoh so‘rashi acceptancedek talqin qilinmaydi. σ0da null daraja/«Rasch darajasini aniqlab bo‘lmadi» ham hali proposed fallback; barcha0/1 bilan finite θ olish σ0ni o‘z-o‘zidan hal qilmaydi.

## 5. Joriy API

| Chegara | Natija |
|---|---|
| `AttemptGradingResult` | Faqat `attempt_id`, `ordinary`, `rasch`; `statistical_bonus` hatto null sifatida ham qabul qilinmaydi |
| Existing submit/result/history/staff results/export | Ordinary va optional own-safe Rasch, lifecycle/cancellation alohida; oldingi auth/scope saqlanadi |
| `GET /admin/assignments/{assignment_id}/rasch` | Readiness va mavjud run, valid self-submit cohort policy |
| `POST /admin/assignments/{assignment_id}/rasch` | Teacher ixtiyorida, K/no body, barrier/current auth;202 in-flight yoki200 same terminal |
| `GET /admin/assignments/{assignment_id}/rasch/diagnostics` | Staff-only original scoped θ/b/μ/σ/Z/T; pupilga latent field yo‘q |
| `QuestionWrite/QuestionSource.individual_points` | Draft nullable; numeric qiymat>0; full precision, display2 |
| `IanaTimezone` | Tasdiqlangan `Asia/Tashkent` |

Qo‘shimcha olib tashlangan yo‘l/sxemalar aniq ro‘yxati `x-decision-changes`da. Ordinary numerator/max/percentage cross-field va current submitted selection server invariantlari. Rasch job/profile/fencing va read/write guards avvalgi rejadan saqlanadi; ilova kodi bajarilgani emas. Status/no-body/auth/Error semantics tegishli oldingi API bilan saqlanadi; yangi wire review acceptance olinmagan.

## 6. Eski talablarning holati

| Eski talab | Joriy holat |
|---|---|
| U-GR-01–04 | Oddiy baholash saqlanadi, U6 musbat ball/display2 bilan aniqlashtirilgan |
| U-GR-05–10,13–14ning bonus qismi | U5 bilan bekor, amaldagi funksiya yoki blocker emas |
| U-GR-11/12/16ning bonus qismi | Bekor; ordinary o‘zgarmasligi va tegishli rollar saqlanadi |
| U-GR-15 | Kechikkanlarning kun oxirigacha huquqi saqlanadi, zona U6da aniq |
| U-R-12dagi uchinchi mexanizm | U5dan keyin ikki mexanizm: ordinary + optional Rasch |
| GB-01/03/04/06 va bonusga oid boshqa blockerlar | Funksiya bekor bo‘lgani uchun joriy blocker emas, javobi taxmin bilan topilmadi |
| R-03ning cohort tanlovi | U6: faqat valid current self-submit; qolgan terminal holatlar kutish barrieriga kiradi, statistikaga kirmaydi |


## 7. Qabul va ochiq masalalar

Default45 va boshqa Teacher count uchun QA, faqat submitted sample, excluded forced/expired, positive/zero/negative points, no retired output field/path/schema, Asia/Tashkent midnight hamda ordinary/Rasch regressiya tekshiriladi. `VALIDATION-RESULTS.json` — offline dalil. Runtime SQL/RLS/API/job/Panel/Mini App/pilot NOT_RUN. Exact profile, σ0 UX, Admin Rasch mutation va keyingi recovery oqimi reviewda; avvalgi bonus blockerlar qayta so‘ralmaydi.

Joriy full JSON `openapi-UniverAcademy-0.2.5-two-grading-review.1.json`, reja `BACKEND_IMPLEMENTATION_PLAN.md`, Master1.3. Ilova/baza/migration/provider/GitHub/deployment va agent holatiga o‘zgartirish kiritilmagan.
