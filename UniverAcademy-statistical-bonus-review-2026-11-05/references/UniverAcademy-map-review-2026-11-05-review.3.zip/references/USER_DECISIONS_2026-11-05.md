# Joriy foydalanuvchi qarorlari va hali tasdiqlanmagan masalalar

**2026-11-05, Asia/Tashkent.** Quyidagi IDlar mantiqiy manba IDlari, platforma xabari UUIDsi emas. Aniq vaqt/UUID berilmagan.

## U5 — UA-SRC-TWO-GRADING-USER-20261105

Asl foydalanuvchi xabari:

> statistik bonus tizmini olib tashla, ikki xil baholash qollansa yetarli, rasch modeli oqituvchi ixtiyorida. savollar 45 ta yoki oqituvchi belgilaydi.
> yana biror noaniqlik yoki ochiq qolgan savollar bolsa sora

## U6 — UA-SRC-GRADING-CLARIFICATIONS-20261105

Foydalanuvchining keyingi savollarga aniq javoblari:

| Savolning mazmuni | Foydalanuvchi javobi | Talqin |
|---|---|---|
| Boshlang‘ich45 savol, Teacher o‘zgartiradi | «Ha, 45 ta; o‘qituvchi o‘zgartiradi» | Tasdiqlangan default45, hard limit emas |
| MAP va variance0 fallbackni qo‘llash | «Avval hisoblashni tushuntiring», keyin «MAP - bu nima ozi. shuni tushuntir» | **Tasdiqlanmagan**; izoh so‘ralgan, yes deb talqin qilinmaydi |
| Qaysi urinish Raschga kiradi | «Faqat o‘zi yakunlagan urinish olinsin» | Faqat current valid `submitted`; `expired`, `forced`, `cancelled`, `in_progress`, `ready`, `recovery_lapsed` kirmaydi |
| Musbat/kasr savol balli, 2 kasr ko‘rinish, to‘liq ichki hisob | «Ha, shu tartib bo‘lsin» | 0dan katta savol ballari, kasr mumkin, ko‘rinish2 kasr; hisob/saqlash to‘liq aniqlikda |
| O‘zbekiston vaqti | «Ha, O‘zbekiston vaqti bo‘yicha» | `Asia/Tashkent`. Oldindan kiritilgan izohga ko‘ra bu faqat vaqt zonasi; kechikkanlarning kun oxirigacha huquqini qisqartirish ruxsati emas |

O‘qituvchi auditoriyadagi sessiyani erta tugatsa ham avvaldan ro‘yxatdagi kechikkanlarning **shu kun oxirigacha boshlash huquqi saqlanadi**. Cutoff — keyingi mahalliy kun00:00, exclusive; boshlangan urinish to‘liq vaqt oladi.

Raschga expired/forced kiritilmasligi, ularni tugashini kutmaslik degani emas: button uchun barcha boshlangan urinishlar terminal bo‘lishi, late admission va mavjud ready recovery huquqi tugashi kerak.

## Hali ochiq

- MAP nima ekanini tushuntirish so‘raldi; aniq estimator/MAP profili va variance0dagi foydalanuvchi holati hali tasdiqlangan deb yozilmaydi.
- Ball/foiz display2 kasr aniq; aynan yarmida rounding usuli, storage precision/format cheklovlari texnik reviewda. O‘qituvchining oddiy «Individual baholash» tugmasi boshlang‘ich holati belgilanmagan.
- Rasch hisobidan keyingi texnik recovery qanday boshqarilishi, Adminning Raschni faollashtirish vakolati va amaldagi backend/job joylashuvi ochiq. Bir martalik immutable natijani overwrite qilish ruxsati yo‘q.
- Haqiqiy demo kontenti/kaliti/davomiyligi va roster/jadval qiymatlari hali konfiguratsiya qilinmagan.

Statistik bonusga oid javobsiz ulush, warning/minimum, bonus vakolati va bonus snapshot savollari endi joriy blocker emas: funksiya bekor qilingan. Tarixiy ma’lumot o‘chirilmaydi; production table/drop/migration topshirig‘i berilmagan.
