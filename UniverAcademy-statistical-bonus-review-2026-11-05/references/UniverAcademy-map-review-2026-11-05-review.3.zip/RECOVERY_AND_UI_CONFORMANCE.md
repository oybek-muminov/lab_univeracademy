# Review.3 recovery projections and UI conformance

**Product source:** direct user message Sentinel_936e922ad45081918da58fa51f33d892, exact question/answer in USER_DECISIONS_REVIEW3_2026-11-05.md. **Implementation status:** proposed conformance requirements, NOT_IMPLEMENTED / NOT_RUN / pending Backend API-owner review. No new wire field, route, capability or recovery authorization is created.

## Confirmed policy versus retained rules

The new confirmation says only that Admin does not activate Rasch, a restored attempt does not inherit the old Rasch result, and new-test individual grading starts off. Existing Teacher own-group/subject and Owner rights remain. Existing immutable one-shot frozen-run and recovery/cancellation rules remain. The successor receives its own ordinary result under the existing lifecycle; this is not a new independent permission to start, recover, reset, recalculate or publish.

## Recovery/read projection matrix

| Situation/surface | Required attribution and behavior | Remaining verification |
|---|---|---|
| Recovery before any Rasch run exists | Existing authorization creates a blank successor, no copied answers/result. Once valid current self-submitted and all activation gates pass, it can enter the first snapshot under the existing population rule. | Actual auth, generation/current pointer and snapshot selection NOT_RUN |
| Recovery after a queued/running run snapshot | Old snapshot remains frozen and worker computes only its original input. If a predecessor is later cancelled, keep its cancelled/nonofficial identity separate. Never attach the old-run output to the successor. | Recovery/worker lock order, atomic publication and projection races NOT_RUN |
| Recovery after a terminal run | Original saved run/results/history stay immutable. No reset/recompute/new same-session run is introduced. Successor has no inherited old-run Rasch; ordinary follows its own completion lifecycle. | Historical/current joins and one-shot guards NOT_RUN |
| Current successor result and official current view | Show successor's own ordinary when available; rasch=null if it is outside the old frozen snapshot. Never join by student/group alone and copy old-run Rasch. | Identity checks must use run/input attempt attribution; schema alone cannot compare IDs |
| Original predecessor history | Existing cancellation and nonofficial labels remain. Any retained historical Rasch is attributed to the original snapshot/attempt, not relabeled current or as successor. Existing audience privacy applies. | Own-history and cancellation/nullability tests NOT_RUN |
| Official export | Do not present old predecessor Rasch as a successor/current official result. Keep current ordinary attribution correct. | Backend export semantics and tests pending |
| Historical export and staff diagnostics | Authorized readers may see original stored run/cohort diagnostics under existing scope, with original attribution. Recovery does not change cohort counts, norm, hashes or parameters. Do not expose those staff latent fields in pupil views. | Scope/privacy and output/history labeling tests NOT_RUN |
| Existing-run POST replay after recovery | Current authorized Teacher/Owner, canonical lock and existing-run lookup, same200/202 receipt. Do not run new-activation checks as if this were a new snapshot. Admin mutation/replay denied; Admin read scope unchanged. | Current-auth, same/different K, concurrent recovery and revoked-rights tests NOT_RUN |

This matrix applies to the old frozen session/run. It does not impose an unsupported permanent ban on every future result or future independent test a student may take. It does not ban an otherwise authorized recovery. New product choices about recovery rights or terminal numerical retries remain separate.

## Panel and Bot/Mini App requirements

- New-test creation initializes individual_enabled=false. Off means every question1. On permits positive fractional points under existing rules. The client sends the existing required boolean explicitly; no JSON Schema default annotation, server fallback, omitted-field acceptance or field removal is introduced. Editing/loading an existing test retains its stored choice, rather than resetting it to false.
- Teacher optional activation remains own-group/subject scoped; Owner existing rights remain. Admin gets no activation button and cannot bypass this through POST, a different Idempotency-Key or replay. Readiness for an Admin may be read under existing scope but can_calculate=false; client display is not authorization.
- A true readiness response must satisfy all local flags/run-null/empty-blocker constraints. UI still handles authorization changes and409/403 on POST; stale GET cannot grant a run. Existing run polling/replay is distinct from first activation.
- For successor current results, show own ordinary normally and no inherited old Rasch. Historical original results retain cancellation/nonofficial attribution. Do not display an old level as if it were newly earned by the recovery attempt.
- Preserve exact mathematically-unavailable message «Rasch darajasini aniqlab bo‘lmadi», with separate failed/CALCULATION_UNAVAILABLE and no_level/BELOW_T46 states. No latent values or peer data reach the pupil UI.

All of the above needs actual Backend/Bot/Panel/QA tests and exact-byte acceptance. The local353 schema cases verify the two schema changes only, not these runtime/role/identity/UI rules.
