# UniverAcademy API Contract — 0.2.6-map-review.3

**2026-11-05, Asia/Tashkent.** Joriy review, published release emas. Manbalar U5/U6: `references/USER_DECISIONS_2026-11-05.md`; exact xesh `REVIEW-SOURCE-INDEX.json`da. Oldingi `0.2.4-rasch-review.1` baseline uch baholash talabi endi tarixiy; faqat quyidagi ikki tizim amal qiladi. API texnik shakli agent reviewida, U7 bilan MAP va teng natijadagi xabar tanlandi. Sonli qiymatlar ushbu tahrirning asoslangan texnik tavsiyasi, user ularni o‘zi bergan deb yozilmaydi.

**Review.3 holati: PROVISIONAL, NOT ACCEPTED.** Backend yagona API egasi. RaschRun status/reason va readiness true-branch sxemasi ushbu draftda tuzatildi; runtime va API-owner qabuli hali yo‘q. Numerical cutoff xatosi ochiq, faqat yechim tavsiyasi qo‘shildi. User uch product qoidani yangi direct javob bilan tasdiqladi; exact scope va manba §10da. Current holat §10 va `REVIEW_FINDINGS_AND_DECISIONS.md`da. Oldingi review.2 hujjati `source/map-review.2/`da exact saqlangan.

## 1. Ikki baholash

1. **Oddiy baholash — doimiy asosiy natija.** Yangi testda initial individual toggle o‘chiq (review.3 direct user confirmation); existing API boolean required. Teacher «Individual baholash» o‘chiq: har savol1; yoqilgan: har savol uchun0dan katta ball, kasr mumkin. To‘g‘riga asosiy ball, noto‘g‘riga0. Maksimal ball barcha asosiy ballar yig‘indisi>0. `Foiz=to‘plangan/maksimal×100`. Full precision hisoblanadi/saqlanadi, student ball/maksimal/foiz2 kasr bilan ko‘radi. Tugashi bilan saqlanadi, Raschni kutmaydi. Bo‘sh test va individual0/negative publish qilinmaydi. Midpoint rounding/storage scale hali texnik review.
2. **Rasch1PL — Teacher ixtiyoridagi qo‘shimcha tahlil.** `P(Xij=1)=1/(1+exp(-(θi−bj)))`. Teacherning savol ballari modelga kiritilmaydi. Rasch hisoblanmasa oddiy natija baribir ishlaydi; teacher tanlovi avtomatik majburiy bosqichga aylantirilmaydi.

Statistik bonus to‘liq chiqarildi: endpoint, request/response field, sxema, oldingi bonus formule/DB/UI/QA vazifalari joriy spetsifikatsiyada yo‘q. Bu ishlab turgan bazadan ma’lumot/jadval o‘chirish yoki migration bajarish topshirig‘i emas. Tarixiy fayllar `references/`da faqat manba sifatida.

## 2. Savollar soni va vaqt

Yangi testda boshlang‘ich **45 savol**, Teacher o‘zgartiradi. 45 qat’iy maksimum yoki hamma eski testni45ga aylantirish talabi emas. Actual published question set barcha savollarni belgilaydi; model40/45ga hardcode qilinmaydi. Mavjud content/Version endpoints Teacherga savollarni yozish/nashr qilishni beradi; yangi `question_count` request maydoni o‘ylab topilmadi. Panelda default45 ko‘rsatiladi, pinned versionda haqiqiy son olinadi.

Zona **Asia/Tashkent**, U6 bilan tasdiqlangan. Oldindan ro‘yxatdagi kechikkan start huquqi keyingi mahalliy kun00:00gacha (exclusive); auditoriya erta tugashi buni qisqartirmaydi. UTC cutoff IANA calendar orqali; misol 2026-11-06 00:00 Asia/Tashkent → 2026-11-05T19:00:00Z. Bu haqiqiy demo sanasi tanlangani emas. Boshlangan urinish full duration oladi, cutoffdan keyin tugashi mumkin. Rosterga keyin yangi odam qo‘shish qoidasi o‘zgartirilmadi.

## 3. Rasch statistikasiga kiradigan urinishlar

**Faqat o‘quvchi o‘zi muvaffaqiyatli yakunlagan valid current `submitted` urinish.** Boshlangan imtihonni vaqt tugashi yoki administrator yakunlasa (`expired/forced`), u ordinary natija oladi, Raschga kirmaydi. Deadlinega teng/keyin student submit qilsa ham oldingi timer qoidasi bo‘yicha `expired`; eligibilityni «o‘zi bosdi» deb ochmaydi. Texnik bekor predecessor, ready/in_progress/recovery_lapsed va testga kirmaganlar ham kiritilmaydi. Bir o‘quvchi uchun bir valid current self-submitted urinish; stable original group/demo/session/version, boshqalardan pooling yo‘q.

Kiritilgan urinishda javobsiz savol0, noto‘g‘ri0, to‘g‘ri1. All-zero self-submitted qator qoladi, no-show bilan aralashtirilmaydi. Barcha published savollar, shu jumladan extreme columns hisobda. Array UI shufflega emas stable question IDga bog‘lanadi.

Faollashtirish barrieri statistika tarkibidan kengroq: **barcha boshlangan** urinishlar tugashi va late admission/ready recovery huquqlari yakunlanishi shart. Expired/forced keyin matritsaga kirmaydi, lekin ularning hali davom etayotgan vaqtini kutish shart. Bitta logical run, same/different Kda ayni snapshot, final immutable. Hech kim self-submit qilmagan bo‘lsa empty sample, soxta μ/σ/T/daraja berilmaydi; typed unavailable ishlovi profilda ko‘rib chiqiladi.

## 4. Daraja va MAP holati

Oldingi user Rasch formula va `Z=(θ−μ)/σ`, `T=50+10Z`ni tasdiqlagan; shu cohort μ/σsi saqlanadi. T≥70 A+; [65,70) A; [60,65) B+; [55,60) B; [50,55) C+; [46,50) C; <46 darajasiz. T yaxlitlanmasdan solishtiriladi, oddiy ko‘rinish2 kasr Rasch thresholdni o‘zgartirmaydi. Bu guruh ichidagi UniverAcademy darajasi, davlat sertifikati bilan equating da’vosi emas.

**MAP — tasdiqlangan usul.** U7 (`UA-SRC-MAP-CONFIRMATION-20261105`) bilan MAP usullar oilasi tanlandi; aynan Gaussian joint/centered MAP varianti ushbu paketning texnik tavsiyasi, foydalanuvchi alohida tanlagan variant emas. Priors/optimizerning exact sonlari quyidagi pilot tavsiyasi; deployment yoki barcha agent acceptance deb ko‘rsatilmaydi. `RASCH_MAP_PROFILE_RECOMMENDED.json` ushbu tavsiyaning yagona sonli nusxasi, Backend qabul qilgan production profil emas; SHA256 `497db1eb16cd5b624caf57cb81719c3ed548dcb17a9ab5167c12e549ef5b08ef`. Asoslash va sintetik solishtirish `MAP_SETTINGS_RECOMMENDATION.md`/`QA/MAP-SENSITIVITY-RESULTS.json`da.

| Sozlama | Tavsiya | Sabab |
|---|---|---|
| O‘quvchi prior | θᵢ ~ Normal(0,1.5²) | Boshlang‘ich1dan yumshoqroq shrinkage; turli va yuqoriroq meanli guruhlar uchun muvozanatli pilot kompromissi |
| Item prior | β ~ Normal(0,2²I), b=Qβ | Qiyinlikka kengroq erkinlik, extreme item uchun proper finite penalty |
| Identifikatsiya | sum(b)=0, orthonormal Q | Centered variantning ta’rifi; proper Gaussian priorlar posterior optimumni yagona qiladi; diskriminatsiya doim1 |
| Optimizer | Float64 damped Newton, analytic gradient/Hessian | Kichik30×45 masalada tekshiriladigan deterministik yechim |
| To‘xtash | gradient∞≤1e−7, max200 iteration | Finite-precision stallga ortiqcha qat’iy1e−8dan yumshoqroq, oldingi parity1e−6dan aniqroq gradient darvozasi; maxiter success emas |
| Line search | Boshlang‘ich step1, Armijo1e−4, max50 backtrack | Objective kamayishini tekshiradi, yashirin clipping/retry tuning yo‘q |
| Guruh standartlash | μ=mean(θ), σ=sqrt(sum((θ−μ)²)/N), ddof0 | To‘liq frozen eligible cohortni o‘z ichida standartlash; N roster yoki30 konstanta emas |
| Degenerate guard | Equal raw totals yoki σ≤1e−8 | Z/Tga bo‘lish yo‘q, null level va tasdiqlangan xabar; floor bilimga qo‘yilgan minimum emas |
| Versiya | rasch_joint_map_centered_v1 /1.0.0 +SHA256 | Hamma guruh uchun oldindan belgilangan profil, Teacher numeric sozlamani o‘zgartirmaydi |

**Teng natija — tasdiqlangan xulq.** Bir xil published savollar va bir xil prior ostida hamma eligible o‘quvchining unweighted correct counti teng bo‘lsa, θlar teng; oddiy weighted ballni bu tekshiruvga mezon qilib bo‘lmaydi. Model finite θ/b topsa ham normσ0: saqlangan μ/σ/diagnostics qoladi, Z/T/level null. Existing pupil DTO `status=not_estimable`, `reason_code=STANDARDIZATION_UNAVAILABLE`, `level=null`; Mini App va Panel aynan **«Rasch darajasini aniqlab bo‘lmadi»**ni ko‘rsatadi. Ordinary ball/maksimal/foiz o‘zgarmaydi. Equal raw-total proof guardi va recommended sigma≤1e−8 numerik himoyasi Z/T bo‘lishidan oldin tekshiriladi. N1 ham shunday, N0 uchun existing EMPTY_COHORT/null norm; T<46 `no_level` va numerical failure `failed` alohida qoladi. Bu fake T50/C+ emas, mathematical unavailable outcome. Wire fieldlar kengaytirilmadi.


## 5. Joriy API

| Chegara | Natija |
|---|---|
| `AttemptGradingResult` | Faqat `attempt_id`, `ordinary`, `rasch`; `statistical_bonus` hatto null sifatida ham qabul qilinmaydi |
| Existing submit/result/history/staff results/export | Ordinary va optional own-safe Rasch, lifecycle/cancellation alohida; oldingi auth/scope saqlanadi |
| `GET /admin/assignments/{assignment_id}/rasch` | Readiness va mavjud run, valid self-submit cohort policy |
| `POST /admin/assignments/{assignment_id}/rasch` | Teacher ixtiyorida, K/no body, barrier/current auth;202 in-flight yoki200 same terminal |
| `GET /admin/assignments/{assignment_id}/rasch/diagnostics` | Staff-only original scoped θ/b/μ/σ/Z/T; pupilga latent field yo‘q |
| `QuestionWrite/QuestionSource.individual_points` | Draft nullable; numeric qiymat>0; full precision, display2 |
| `IanaTimezone` | Tasdiqlangan `Asia/Tashkent` |

Qo‘shimcha olib tashlangan yo‘l/sxemalar aniq ro‘yxati `x-decision-changes`da. Ordinary numerator/max/percentage cross-field va current submitted selection server invariantlari. Rasch job/profile/fencing va read/write guards avvalgi rejadan saqlanadi; ilova kodi bajarilgani emas. Status/no-body/auth/Error semantics tegishli oldingi API bilan saqlanadi; yangi wire review acceptance olinmagan.

## 6. Eski talablarning holati

| Eski talab | Joriy holat |
|---|---|
| U-GR-01–04 | Oddiy baholash saqlanadi, U6 musbat ball/display2 bilan aniqlashtirilgan |
| U-GR-05–10,13–14ning bonus qismi | U5 bilan bekor, amaldagi funksiya yoki blocker emas |
| U-GR-11/12/16ning bonus qismi | Bekor; ordinary o‘zgarmasligi va tegishli rollar saqlanadi |
| U-GR-15 | Kechikkanlarning kun oxirigacha huquqi saqlanadi, zona U6da aniq |
| U-R-12dagi uchinchi mexanizm | U5dan keyin ikki mexanizm: ordinary + optional Rasch |
| GB-01/03/04/06 va bonusga oid boshqa blockerlar | Funksiya bekor bo‘lgani uchun joriy blocker emas, javobi taxmin bilan topilmadi |
| R-03ning cohort tanlovi | U6: faqat valid current self-submit; qolgan terminal holatlar kutish barrieriga kiradi, statistikaga kirmaydi |


## 7. Qabul va ochiq masalalar

Default45 va boshqa Teacher count uchun QA, faqat submitted sample, excluded forced/expired, positive/zero/negative points, no retired output field/path/schema, Asia/Tashkent midnight hamda ordinary/Rasch regressiya tekshiriladi. `VALIDATION-RESULTS.json` — offline dalil. Runtime SQL/RLS/API/job/Panel/Mini App/pilot NOT_RUN. MAP/σ0 UX endi user qarori; recommended numeric profile conformance va runtime recovery projectionlari reviewda; Admin activation yo‘q va tiklangan urinishga old Rasch ko‘chirilmasligi yangi direct user qarori; avvalgi bonus blockerlar qayta so‘ralmaydi.

Joriy full JSON `openapi-UniverAcademy-0.2.6-map-review.3.json`, reja `BACKEND_IMPLEMENTATION_PLAN.md`, Master1.4. Ilova/baza/migration/provider/GitHub/deployment va agent holatiga o‘zgartirish kiritilmagan.

## 8. U7 qarori va manba

`USER_MAP_DECISION_2026-11-05.md` SHA256 `4e18fecfd80d4df1ff68d4694674ed1f2176e8d5139c4a0c201efd9d74f3341c`; current chat2026-11-05. Method va exact teng-natija matni tasdiqlangan, exact prior raqamlari asoslangan **tavsiya**. Statistical bonus qaytarilmadi; two systems/default45/editable/self-submitted-only/positive points/display2/Asia-Tashkent/one-shot o‘zgarishsiz. Backend/agent qabuli yoki migration/deployment bajarilmadi.

## 9. Tarixiy review.2 aniqlashtirishlari — joriy holat §10da

- **Replay (MR2-C01):** current auth/scope har safar; canonical lock ostida mavjud logical run topilsa, same terminal 200 yoki in-flight 202 qaytadi. Yangi activation barrier/profile tekshiruvlari faqat yangi run yaratishga tegishli. Keyingi recovery existing runni qayta snapshot yoki overwrite qilishga sabab bo‘lmaydi. Reja §5 shu tartibga tuzatildi, runtime isbotlanmagan.
- **Status/reason (MR2-C02):** proposed schema hardening not_estimable uchun EMPTY_COHORT/ZERO_OR_NEGLIGIBLE_VARIANCE, failed uchun numerical/input reasonlar, completed uchun nullni ajratishi kerak. Current wire shu cheklovni to‘liq enforce qilmaydi; xato payloadlar evidence faylida. API egasi qabulisiz sxema o‘zgartirilmadi.
- **Readiness (MR2-C03):** can_calculate=true barcha first-activation gate bajarilgan, blocker yo‘q, mavjud run yo‘q holatni bildirishi kerak; server gate baribir atomik. False faqat flaglarning mantiqiy teskarisi emas. Negative fixtures hali acceptance rejasidir.
- **Numerical cutoff (MR2-N01):** original 5×12 oracle case question reorder bilan 69.99999999999999/A va70/A+ beradi. θ/b/Z/T tolerance yetarli emas. End-to-end categorical invariance va reviewed near-boundary numerical handling Backend/QA qabulidan oldin zarur. Inclusive cutofflar/no display rounding unchanged; profil/oracle hali tuzatilmagan.
- **Ordinary precision (MR2-D03):** full precision display roundingni input/sumga qo‘llamaslikni talab qiladi; JSON numberning cheksiz exact decimal kafolati emas. Decimal computation/storage va recurring percentage precision hujjati kerak; half-up/decimal-string/scale/cap bu paketda qabul qilinmagan.
- **Pending decisions:** Admin activation vakolati, post-run recoveryning predecessor/successor projectioni, initial individual toggle, terminal failure policy. Tasdiqlangan MAP/equal-message/self-submitted scope qayta savolga aylantirilmaydi.

`source/map-review.1/` yuborilgan 30 faylning exact nusxasi. Joriy file SHA, test holatlari va source yo‘llari manifest/validationda. Ushbu API label vaqtinchalik review versiyasi, published/final yoki implementatsiya ruxsati emas.

**Profile metadata talqini:** unchanged `RASCH_MAP_PROFILE_RECOMMENDED.json`da `method=joint_map` va `method_approval_status=USER_CONFIRMED` yonma-yon turishi MAP oilasi tasdig‘ini qo‘pol ifodalaydi. Bu joint/centered variant, priors, optimizer yoki numeric qiymatlar user tomonidan tanlanganini bildirmaydi. Shu aniqlashtirish current API review talqinidir; source/profile bytes dalil uchun o‘zgartirilmadi.


## 10. Review.3: audit asosidagi draft tuzatishlar

**MR2-C02:** `RaschRun` now restricts `not_estimable` to EMPTY_COHORT or ZERO_OR_NEGLIGIBLE_VARIANCE and `failed` to NONCONVERGENCE, NONFINITE_OPTIMIZATION, NUMERICAL_FAILURE or INVALID_INPUT_SNAPSHOT. queued/running/completed require null reason. queued/running require null completed_at; terminal outcomes require a UTC timestamp. No new reason code or pupil field was introduced. Local schema evidence is in `evidence/REVIEW3-SCHEMA-VERIFICATION.json`; actual server responses are NOT_RUN.

**MR2-C03:** `can_calculate=true` implies admission_closed=true, all_started_attempts_completed=true, pending_recovery_start_rights=false, blocking_codes=[] and run=null. There is intentionally no reverse implication: false can reflect other authorization/profile/policy blockers. Schema cannot validate current permissions, live clocks, identity equality or concurrent DB state. POST always rechecks atomically; GET readiness never authorizes a mutation.

**MR2-C01:** POST description and Backend plan now agree on current auth/scope → canonical lock/existing run → same authorized receipt → only if absent, first-activation gates and frozen snapshot. A recovery after snapshot cannot turn receipt replay into a fresh activation or allow revoked rights. Runtime replay/race proof remains NOT_RUN.

**MR2-N01:** the external audit did not reproduce the original quoted 5×12 flip in its BLAS environment, but independently reproduced the defect with seed5 5×12 and seed9 30×45 fixtures. In the latter, 24 rows total44 and6 rows total45; the upper group has exact Z=√(24/6)=2 and T70/A+. Original order returned69.99999999999997/A and reversed order70/A+ there. These are supplied-audit observations, not a newly fixed solver. `NUMERICAL_BOUNDARY_RECOMMENDATION.md` gives the proposed certified/structural approach, its limits and acceptance gates. No sorting-only fix, display rounding, arbitrary epsilon or cutoff change is adopted.

**Direct product confirmation:** MR2-D01/D02/D04 are now USER_CONFIRMED by message Sentinel_936e922ad45081918da58fa51f33d892. Exact question and answer are in USER_DECISIONS_REVIEW3_2026-11-05.md. Admin may not activate Rasch; Teacher own-group/subject and Owner existing rights remain. A restored attempt must not inherit the old Rasch; original frozen history/one-shot and existing recovery rights remain unchanged. New-test individual toggle starts off, but clients still send the required boolean and existing tests are not reset. RECOVERY_AND_UI_CONFORMANCE.md sets projection and UI acceptance requirements. These are narrowly scoped product confirmations, not API/numeric/runtime acceptance. The attached audit's older original user messages remain unverified and its exact source files are unchanged.

**Other gates:** decimal arithmetic/storage and midpoint display rounding remain technical design review; terminal failure/retry behavior remains a separate policy review. Existing one-shot rights do not authorize new reset/recompute. Backend, Bot/Mini App, Panel and QA acceptance for these exact bytes is NOT_REVIEWED. Full OpenAPI3.1 validation in this build is NOT_RUN because its validator is unavailable; the attached review.2 full-validator pass remains historical evidence only.
