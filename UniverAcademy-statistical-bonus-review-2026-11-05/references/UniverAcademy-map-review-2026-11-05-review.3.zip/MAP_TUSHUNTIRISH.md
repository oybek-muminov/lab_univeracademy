# MAP nima?

MAP — Maximum A Posteriori, javoblardan parametrlarni baholash usuli. Rasch — baholash modeli, MAP esa uning ichidagi o‘quvchi bilim ko‘rsatkichi va savol qiyinligini topish usullaridan biri. Bu alohida uchinchi baholash turi emas.

Masalan, o‘quvchi45 savolning hammasini to‘g‘ri ishladi. Oddiy maksimal likelihood hisobida bu o‘quvchining bilim ko‘rsatkichi cheksizlikka intilishi mumkin. MAP «45 ta to‘g‘ri javob juda yaxshi dalil, lekin bilim cheksiz degani emas» deya chekli parametr topishga yordam beradi. Savolni hamma to‘g‘ri/noto‘g‘ri ishlaganida qiyinlik parametrida ham shunday himoya kerak.

Matematik jihatdan javoblarning likelihoodi va oldindan tanlangan statistik taqsimot — prior — birga hisoblanadi. Bir xil qoidalar barcha o‘quvchi/savollarga qo‘llanadi; ma’lumotlar shunga qo‘shiladi. Prior kuchi θ/b va oxirgi Rasch darajasiga ta’sir qilishi mumkin. Shu sababli uning turi/qiymati ochiq, hamma uchun bir xil, sinovdan o‘tgan va hisob bilan birga saqlanadigan bo‘lishi kerak. Ta’rif: [Stan rasmiy hujjati — MAP posterior mode](https://mc-stan.org/docs/reference-manual/analysis.html).

Oddiy to‘plangan ball, maksimal ball va foiz MAPga bog‘liq emas va o‘zgarmaydi. O‘qituvchi qo‘ygan savol ballari Raschga kiritilmaydi.

Keyin θlar guruh ichidagi μ/σga nisbatan Z/Tga aylantiriladi. Guruh o‘rtachasi T50, siz bergan jadvalda C+. Hamma θ bir xil bo‘lsa σ0 bo‘ladi; MAP finite θ topsa ham bu bo‘lishni aniqlamaydi. U7 bilan tasdiqlandi: oddiy natija qoladi, «Rasch darajasini aniqlab bo‘lmadi» ko‘rsatiladi, Z/T/level null va C+ o‘ylab topilmaydi. MAPdan foydalanish ham tanlandi; exact numeric settings alohida asoslangan tavsiya.

Boshlang‘ich numeric tavsiya: θ prior SD1.5, item contrast SD2, zero-sum b, float64 stable MAP va populationσ. Bu raqamlar majburiy Rasch standartlari emas; sabab va sensitivity dalili `MAP_SETTINGS_RECOMMENDATION.md`da. Teacher faqat Raschni ishga tushiradi, prior raqamlarini guruhga qarab o‘zgartirmaydi.
