# UniverAcademy MAP review.2 o‘zgarishlari

**2026-11-05. Provisional API0.2.6-map-review.2 / Master1.4-map-review.2. Backend acceptance olinmagan; final/published/deployed emas.**

## Saqlangan

Barcha user qarorlari, Master §13 jumladan1–127 exact bytes, source30 fayl, original ZIP, root QA scripts/inputs/historical outputs va numerical profile exact bytes. Bonus qaytmadi. Ordinary + optional Teacher Rasch/MAP,45/editable,self-submitted-only,unanswered0,all-started barrier,Asia/Tashkent,positive fractional ordinary/display2,one logical immutable run va exact unavailable xabar o‘zgarmadi. T cutoff va numerical profile qiymatlariga o‘zgartirish yo‘q.

## Hujjat va metadata tuzatishlari

- Backend yagona API egasi; barcha yangi label provisional. Real agent acceptance jadvali added, acceptance taxmin qilinmadi.
- Master §0.5/20 joriy overlay; §17–18 superseded tarixiy holat deb aniq belgilandi, registry untouched.
- API/OpenAPI review.2 status/metadata va findings pointers added. Paths/components semantik unchanged; schema gaps yashirilmagan.
- Reja: current auth → canonical existing-run lookup → faqat first-creation gates. Keyingi recovery existing receiptni avtomatik yangi activationga aylantirmaydi.
- Source-index/manifest besh baseline source path references/ bilan tuzatildi. Historical raw sources saqlandi.
- Historical135case report current rerun/acceptancega tenglashtirilmadi; original harness yo‘qligi ochiq qayd qilindi.

## Ochiq P1 va qarorlar

- Original oracle5×12 reorderda69.99999999999999/A va70/A+: yangi mustaqil dalil. End-to-end categorical permutation/boundary review zarur, kod tuzatilmadi.
- RaschRun status/reason va RaschAnalysisStatus readiness gaplar: Backend schema/server hardening proposal, current schema unchanged.
- Admin mutation, post-run recovery projections, ordinary decimal/storage/display tie details, initial toggle va terminal failure policy alohida qayd qilindi. Product decision o‘rniga taxmin kiritilmadi.
- Real-data calibration, Backend-stack benchmark/auth/RLS/parallel jobs/UI/pilot va exact-byte agent qabuli hali yo‘q.

Yangi evidence/test statusi `VALIDATION-RESULTS.json`da; original review.1 natijalar `source/map-review.1/`da. Bu paket hech qanday production migration/provider/GitHub/deploy bajarmadi. Yangi review.2 yuborilmagan; original review.1 bo‘yicha koordinator aloqa urinishlari AGENT_REVIEW_TABLE.md da.
