# UniverAcademy: agent/egalar review jadvali

**API0.2.6-map-review.2 / Master1.4-map-review.2. PROVISIONAL, NOT ACCEPTED.** Backend yagona API egasi. Quyidagi yangi review.2 exact-byte qabullar olinmagan; yangi .2 hali yuborilmagan. Mahalliy mustaqil source/contract/math tekshiruvlari haqiqiy loyiha agentlariga xabar yuborildi yoki ular faylni qabul qildi degani emas.

| Egasi | Review predmeti | Local topilma/tayyor material | Exact-byte qabul | Keyingi zarur dalil |
|---|---|---|---|---|
| Backend | API/MD, schemas, current auth, replay, snapshot/job, numerical profile | MR2-N01/C01/C02/C03/D03/D05 | NOT_REVIEWED_NOT_SENT_FOR_REVIEW_2 | Yangi API/MD/profile/code hashlar bo‘yicha explicit accept/block; numerical/schema fixes va runtime evidence. |
| Bot/Mini App | Own-safe result/history, exact unavailable xabar, ordinary2 decimal | MR2-D02 recovery projection va numerical failure/unavailable/no_level farqi | NOT_REVIEWED_NOT_SENT_FOR_REVIEW_2 | Backend accepted DTO hashiga mos UI/runtime/privacy dalili. |
| Panel | Optional Teacher action, readiness/poll/replay,45 editable, individual toggle | MR2-C01/C03/D01/D04 | NOT_REVIEWED_NOT_SENT_FOR_REVIEW_2 | Disabled/first activation/existing-run polling/current-auth, repeated-click/recovery UX dalili. |
| QA | Source integrity, offline math, contract negatives, runtime suite | New P1 counterexample reproduced; schema gaps documented; historical135 harness missing | NOT_REVIEWED_NOT_SENT_FOR_REVIEW_2 | Exact new artifactsga independent explicit report; proposed regression coverage va actual auth/DB/UI/pilot. |
| User/product authority | Admin mutation, recovery projection, initial toggle; failure retry rights if changed | Tafsilot REVIEW_FINDINGS_AND_DECISIONS.md | PENDING_DECISIONS | Faqat ochiq qarorlar; MAP, equal message, cohort, cutofflar qayta so‘ralmaydi. |

Mahalliy hujjat tekshiruvlari natijasi `VALIDATION-RESULTS.json` va `evidence/`da. Accepted status, sana, identity yoki signature o‘ylab topilmagan. Qabul olinsa har role uchun aynan ko‘rilgan fayl/version/SHA, source message/receipt, qabul/rad, blocker va test environment qayd qilinadi; eski acceptance yangi xeshlarga ko‘chirilmaydi.

## Review.1 uchun aloqa holati, review.2 qabuli emas

Koordinator 2026-11-05da original review.1 ZIP bo‘yicha yuborish/review urinishini bildirdi. Quyidagilar uning qaydiga asoslanadi; bu paket yaratish jarayoni agent tool receiptlarini mustaqil qayta olmagan.

| Rol | Original review.1 urinish natijasi | Chegara |
|---|---|---|
| Backend | NOT_REVIEWED; environment unavailable, ZIP bytes not read | Xabar ID: msg_0830c9cf60064580016aec14a2907081999f3bb45cbb42600d. API qabul yo‘q. |
| Bot/Mini App | SEND_ERROR, delivery uncertain | Qabul qilindi yoki o‘qildi deb aytilmaydi. |
| Panel | SEND_ERROR, delivery uncertain | Qabul qilindi yoki o‘qildi deb aytilmaydi. |
| QA | TIMEOUT, delivery uncertain | Review bajarilgan yoki qabul mavjud deb aytilmaydi. |

Yangi review.2 barcha rollar uchun **NOT_REVIEWED**. Review.1ning qabul qilinmagan yoki noaniq yuborish holati review.2ga acceptance bo‘lib ko‘chmaydi. Noaniq yuborishlar avtomatik qayta yuborilgan deb ko‘rsatilmaydi.
