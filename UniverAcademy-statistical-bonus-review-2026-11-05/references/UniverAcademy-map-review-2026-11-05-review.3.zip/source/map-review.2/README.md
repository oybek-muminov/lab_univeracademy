# UniverAcademy MAP review.2

**2026-11-05. API0.2.6-map-review.2, Master1.4-map-review.2. PROVISIONAL REVIEW, NOT ACCEPTED.** Faqat yuborilgan ZIP asosida. Backend yagona API egasi. User qarorlari va Master §13/1–127 saqlangan. App/test/oracle/profile kod/qiymatlar, database/migration/provider/deploy o‘zgarmagan.

**Muhim:** original Rasch oracleda question reorder top levelni A↔A+ o‘zgartiradigan P1 floating-point chegara muammosi qayta ishlab ko‘rsatildi. Status/reason va readiness schemada ham P1 bo‘shliqlar bor. Shu sabab paket final yoki to‘liq accepted emas.

O‘qish tartibi:
1. `MAP_REVIEW_CHANGES.md`: shu tahrir o‘zgarishlari.
2. `REVIEW_FINDINGS_AND_DECISIONS.md`: dalil, xavf, tuzatish taklifi va ochiq qarorlar.
3. `AGENT_REVIEW_TABLE.md`: egalar review/qabul holati, hammasi aniq ajratilgan.
4. `UNIVERACADEMY_MASTER_CONTEXT.md` §0.5/20; API MD va `openapi-UniverAcademy-0.2.6-map-review.2.json`.
5. `BACKEND_IMPLEMENTATION_PLAN.md` va `QA_ACCEPTANCE_MATRIX.md`: proposed ordering va acceptance regressions.
6. `VALIDATION-RESULTS.json`, `evidence/`, `MANIFEST.json`, `REVIEW-SOURCE-INDEX.json`, `SHA256SUMS.txt`: yangi/historical dalil va integrity.

Root `QA/` va `RASCH_MAP_PROFILE_RECOMMENDED.json` exact original. `source/map-review.1/` barcha30 source faylni original bytesda, `source/UniverAcademy-map-review-2026-11-05.zip` original ZIPni saqlaydi. Source ichidagi eski current/PASS iboralari o‘sha historical report; review.2 statusi emas. `references/` oldingi baselinelar ham unchanged. Root diff fayllari review.1→review.2 hujjat farqlaridir.

`sha256sum -c SHA256SUMS.txt` payload va manifestni tekshiradi; SHA256SUMS o‘zini hash qilmaydi. Manifest files o‘zini va SHA256SUMSni o‘z ichiga olmaydi, circular hash yo‘q. ZIP tashqi hash alohida yetkaziladi. Yangi tekshiruv natijasi source135 historical case harnessi bor degani emas; runtime SQL/auth/RLS/API/worker/UI/pilot va agent acceptance yo‘q.

QA scriptlarini qayta ishga tushirish kerak bo‘lsa, alohida ish nusxasida bajaring: original study/test skriptlari o‘z QA papkasidagi natijalarni yozishi mumkin. Hujjatlardagi tashqi ilmiy havolalar source paketdan saqlangan, bu reviewda jonli qayta tekshirilmagan.

**MAP approval scope:** user MAP usullar oilasini tasdiqlagan. Joint/centered Gaussian variant va exact numerical qiymatlar texnik tavsiya. Unchanged profiledagi `method=joint_map` / `method_approval_status=USER_CONFIRMED` coarse source metadata shu tor doirada talqin qilinadi, specific variantga user approval degani emas.
