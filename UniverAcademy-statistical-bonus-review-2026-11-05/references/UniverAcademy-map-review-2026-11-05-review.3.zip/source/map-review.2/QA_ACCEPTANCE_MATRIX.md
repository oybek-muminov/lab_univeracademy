# UniverAcademy Rasch — qabul va sinov matritsasi

**2026-11-05.** `QA/test_rasch_reference.py` faqat tavsiya qilingan mathematical profile; MAP method user-confirmed uchun executable offline oracle. U haqiqiy API yoki bazani tekshirmaydi. 30×45 fixture sintetik: 33 roster, 30 started/completed va 3 no-show, 4 ta unanswered cell, all-zero/all-one participant. Default45 Teacher-editable; fixture haqiqiy demo kontenti emas.

## 1. Offline testlar — bajarilganligi TEST-RESULTS.jsonda

| ID | Tekshiruv | Kutiladigan dalil |
|---|---|---|
| M01 | 33 roster ichidan 30 started | 30×45 shape |
| M02 | None/unanswered | X=0 |
| M03 | No-show va all-zero started farqi | 3 no-show tashqarida, started all-zero ichkarida |
| M04–M05 | Foreign group/session row | Candidate snapshot builder reject; pooling yo‘q |
| M06 | Bir person/attempt takror | Duplicate reject |
| M07 | Noto‘g‘ri uzunlik | Ragged reject |
| M08 | Cancelled predecessor | Statistikaga kirmaydi, qolgan submitted sample |
| N01 | 30×45 complete matrix MAP | Converged, finite params, gradient norm≤profile tolerance |
| N02–N03 | Extreme person va identification | Finite θ/b, sum(b)≈0 |
| N04 | Teacher ballarini o‘zgartirish | X/digest/θ o‘zgarmaydi |
| N05 | All-zero/all-one item ustunlari | Barcha45 item qoladi, finite b; all-wrong b all-right bdan qiyinroq |
| N06 | Equal correct count/different patterns | Bir xil savol/prior ostida θ teng |
| N07 | η±1000 | Stable P/loss, NaN/overflow yo‘q |
| N08 | Gradient/Hessian numerical check | Finite difference mos, Hessian SPD |
| N09 | Maxiter0 | Typed failed/NONCONVERGENCE, partial θ publish yo‘q |
| N10 | Nonbinary/NaN/Infinity/negative X | Reject |
| S01 | μ/σ va standartlash | Saved mu mean(theta), sigma population, mean(Z)≈0, mean(T)≈50 |
| S02–S03 | Har cutoff va uning pastki qo‘shnisi | 46/50/55/60/65/70 inclusive; rounding ko‘tarmaydi |
| S04 | σ0 | not_estimable, Z/T/level null; C+ taxmini yo‘q |
| S05 | N0 va N1 | Typed unavailable, crash yo‘q; extreme finite bo‘lishi norm aniqligiga teng emas |
| S06–S07 | Hamma0/1, equal-total va near-zero σ | Finite MAP, typed no norm |
| S08 | T diapazoni va nofinite | Tga 0..100 clamp yo‘q, nofinite reject |
| R01–R02 | Row/column permutation, repeat | Alignment bo‘yicha θ/b invariant, deterministic, strict JSON |
| R03–R04 | Oldingi ordinary fixture va profile | Input mutatsiyasi yo‘q, method USER_CONFIRMED, numerical profile RECOMMENDED |

Row selection tasdiqlangan self-submitted-only; actual DB query sinovi emas. M09 expired/forced28 sample, M10 empty self-submit sample, Q01 boshqa configured savol soni ham tekshiriladi. Offline input immutability testi bazadagi immutability kafolati emas. MAP va equal-outcome exact matn user tasdiqi; recommended prior/σ floor raqamlari userning literal numeric qarori deb olinmaydi.

## 2. Keyingi real API/DB/integration sinovlari — NOT_RUN

| ID | Ssenariy | Qabul mezoni va kuzatiladigan dalil |
|---|---|---|
| I01 | Same K parallel POST | Bitta run ID/input hash/job/terminal output; DB query/count evidence |
| I02 | Different K parallel POST | Session+rasch_1pl UNIQUE bitta run; ikkinchi cohort snapshot yo‘q |
| I03 | Snapshot bilan start/recovery race | Bir xil locks/barrier; active/ready recovery bo‘lsa faollashtirish yo‘q |
| I04 | Keyin pupil/guruh/javob/profile o‘zgaradi | Old run/input/output/μσ/result exact hash o‘zgarmaydi |
| I05 | Worker crash commitdan oldin/keyin | Same run resumable; max bir final atomic commit |
| I06 | Lease timeout va stale worker | Fence token stale publishni to‘xtatadi |
| I07 | DB output yozishda xato | Hech qisman person/item result ko‘rinmaydi; transaction rollback |
| I08 | Retry terminal completed/failed/not_estimable | 200 ayni final run; qayta hisob/reset yo‘q |
| I09 | Durable enqueue ishlamadi | Run/job atomik: ishlamaydigan yolg‘iz run yoki yo‘qolgan job yo‘q |
| I10 | Production-stack numerical parity/resource benchmark | Approved profile/Xda oracle bilan θ/b/Z/T tolerance ichida; haqiqiy Edge/worker CPU/memory/timeout dalili; hozir SLA yo‘q |
| A01 | Teacher foreign group yoki faqat content right | 403/404, list/count/diagnostics leak yo‘q |
| A02 | Pupil POST/diagnostics va staff credentials bilan pupil route | Auth turiga mos rad, oldingi ajratish saqlanadi |
| A03 | Owner/Admin current rights/revoked replay | Owner umumiy huquq, Admin read saqlanadi; mutation faqat approved policy; replay current auth |
| A04 | Client body/profile/matrix/role/θ inject | No-body server422; role/param trusted emas |
| A05 | DB RLS/finite/terminal guard/unique | Direct unauthorized row read/write/delete rad; Infinity/NaN va ikkinchi terminal overwrite rad |
| A06 | Rasch/T/θ staff data student result/history/exportga kiradi | Closed safe DTO, own membership, no peer/latent fields |
| P01 | Auditoriya erta tugaydi | Late pupil admissiongacha button disabled; server ham409 |
| P02 | Admission yopiq, lekin active deadline bor | Tugma disabled, full attempt duration saqlanadi |
| P03 | 2 marta click/network lost | Same run poll, yangi run yo‘q; initial POST202 keyin GET |
| P04 | Optional action | Panelga kirish yoki detailed reviewni ochish Raschni avtomatik hisoblamaydi; faqat Teacher ixtiyoriy actioni |
| P05 | Terminal failure/σ0 | Aniq holat, reset/recalculate tugmasi yo‘q, oddiy ko‘rinadi |
| P06 | Server profil/cohort blocker va role revoke | UI can_calculate serverdan; stale flag authni chetlab o‘tmaydi |
| U01 | Natija Raschdan oldin | Oddiy ball/maksimal/foiz darhol, Rasch null/kutilmoqda |
| U02 | Rasch completed | Mustaqil daraja, oddiy ball/maksimal/foiz o‘zgarmagan |
| U03 | T<46 vs σ0 vs failed | Darajasiz, aniqlab bo‘lmagan va hisob xatosi bir holat emas |
| U04 | Student privacy | θ/logit/b/μ/σ/Z/T yoki peer/staff data yo‘q |
| U05 | Group transfer/cancel/history | Original run attribution, cancelled never official; foreign cohortga ko‘chirish yo‘q |
| U06 | Kechikkan pupil local cutoff va reconnect | Start huquqi kun oxirigacha, full server duration; hisob finaldan keyin yozilmaydi |

Final qabul uchun har NOT_RUN satriga aniq code/profile/schema/input/output hash, test environment, haqiqiy request/DB dalil va reviewer qo‘shiladi. Bu hujjat ularni o‘tgan deb belgilamaydi.

## 3. U7 uchun qo‘shimcha QA

S09 exact xabar +null level; S10 turli pattern/lekin equal raw total; S11 equal weighted ordinary score/lekin different raw total valid Rasch; S12 explicit equality guardda floating noise. Recommended prior1.5/2, gradient1e−7; all previous schema/privacy/cohort/45-editable/timezone/one-shot constraints saqlanadi. `QA/map_profile_study.py`60 distinct synthetic matrices/6 profiles/360fits; `MAP-SENSITIVITY-RESULTS.json`prior tanlovi natijaga ta’sirini beradi. Bu posterior SBC yoki actual-data validation deb yozilmaydi.

Mini App/Panel U7 acceptance: `not_estimable` +STANDARDIZATION_UNAVAILABLEda aynan **«Rasch darajasini aniqlab bo‘lmadi»** render; ordinary unchanged; no_level BELOW_T46 yoki failed bilan aralashtirmaslik. UI runtime hali NOT_RUN, offline mathematical evidence alohida.

## 4. Review.2 yangi topilmalar va qabul mezonlari

Quyidagi satrlar original37 testni o‘zgartirmaydi; yangi acceptance talab/proposal. Faqat counterexample reproduksiyasi bajarilgan, proposed fix testi emas.

| ID | Holat | Tekshiruv / kutilgan natija |
|---|---|---|
| V-N01 | REPRODUCED_FAILURE | Original5×12 va reversed questions top level A/A+ farqi. Exact mathematical T70. Dalil evidence/INDEPENDENT-RASCH-NUMERICS.json. |
| V-N02 | NOT_IMPLEMENTED | Barcha46/50/55/60/65/70 near-boundary fit→norm→level; row/question permutation bilan categorical invariant; no display rounding/clamp. |
| V-N03 | NOT_RUN | Backend/reference same input/profileda θ/b/Z/T tolerance bilan birga exact status/level parity; reviewed error-bound/high-precision boundary mechanism. |
| V-C01 | NOT_RUN | Current authorized same/different-K existing-run replay keyingi recovery ochiq paytda ham same202/200; revoked auth qayta rad; no second snapshot. |
| V-C02 | CURRENT_SCHEMA_ACCEPTS_INVALID | not_estimable+NONCONVERGENCE va failed+ZERO_OR_NEGLIGIBLE_VARIANCE rad etilishi kerak; proposed schema fix hali yo‘q. |
| V-C03 | CURRENT_SCHEMA_ACCEPTS_INVALID | can_calculate=true va unmet barrier/pending recovery/blocker holatlari rad etilishi kerak; falsega blanket inverse rule qo‘ymang. |
| V-C04 | NOT_RUN | Original run snapshotdan keyingi recovery: queued/running/terminal, predecessor cancelled/nonofficial, successor ordinary, immutable receipt, all projections; approved policy kerak. |
| V-C05 | NOT_RUN | Ordinary0.1/0.2/large fractional amounts, recurring percentage va exact midpoint display fixtures; approved decimal precision/rounding/wire policy kerak. |
| V-P01 | VERIFIED_SEPARATELY | Source ZIP/extracted bytes, §13 exact preservation, corrected source file paths va manifest hashes; runtime validation emas. |
| V-A01 | NOT_RECEIVED | Backend/Bot-Mini App/Panel/QA exact new file hashes + explicit acceptance/blocker response. |

Original135-case report executable harness bilan berilmagan: yangi135 rerun deb hisoblanmaydi. Yangi verification `VALIDATION-RESULTS.json`da; source historical results `source/map-review.1/VALIDATION-RESULTS.json`da.
