# UniverAcademy: review.2 topilmalari va ochiq qarorlar

**2026-11-05, Asia/Tashkent. API 0.2.6-map-review.2, Master 1.4-map-review.2. PROVISIONAL REVIEW, NOT ACCEPTED.** Bu faqat yuborilgan ZIP asosidagi hujjat va dalil paketi. Backend yagona API egasi. Mustaqil lokal tekshiruv Backend, Bot/Mini App, Panel yoki QA egalarining exact-byte qabuli o‘rnini bosmaydi. Source, oracle, test va profil qiymatlari o‘zgartirilmagan.

## Tasdiqlangan va qayta ochilmaydigan qoidalar

Faqat ordinary va Teacher ixtiyoridagi haqiqiy Rasch 1PL/MAP. Bonus bekor. Individual off: har savol 1; on: musbat kasr ball; noto‘g‘ri 0; hisobning ichki aniqligi saqlanadi, ko‘rinish 2 kasr. Default 45, Teacher o‘zgartiradi. Raschda Teacher ballari yo‘q. Faqat aynan shu original guruh/test sessiyasidagi valid current self-submitted urinishlar; unanswered 0; expired/forced/cancelled/no-show chiqariladi. Barrier barcha boshlangan urinishlar va protected late admission/ready recoveryni kutadi. Asia/Tashkent; auditoriya erta tugashi kun oxirigacha start huquqini qisqartirmaydi. Bitta immutable logical run; yangi so‘rov/yangi K ikkinchi natija yaratmaydi. Equal Rasch outcome: aynan **«Rasch darajasini aniqlab bo‘lmadi»**, Z/T/level null; ordinary saqlanadi. T cutofflar o‘zgarmaydi. Master §13, jumladan 1–127, aynan saqlangan.

## MR2-N01: P1, end-to-end daraja barqarorligi

Original oracle bilan yangi mustaqil reproduksiya: 5×12 binary matrix, raw totals [11,11,11,11,12]. 1–2-qatorlarda 3-savol noto‘g‘ri; 3-qatorda 10-savol; 4-qatorda 12-savol; boshqa kataklar 1. Original tartibda 5-o‘quvchi T=69.99999999999999, daraja A; barcha savol ustunlarini teskari tartibga aylantirish T=70.0, daraja A+ beradi. Bir xil javoblar va exact mathematical fitda beshinchi θ yuqori, qolgan to‘rttasi teng: μ=(4a+b)/5, σ=2(b−a)/5, Z_top=2 va T_top=70. Shuning uchun bu foydalanuvchi chegarasi noaniqligi emas, floating-point/end-to-end classifier muammosi.

Gradient∞ taxminan 7.424727499483197e−12 bo‘lsa ham farq bor; faqat optimizer toleranceni qat’iylashtirish yetarli yechim emas. Amaldagi R01 testi θ/b toleranceni tekshiradi, level equalityni emas. Existing S02–S03 bevosita classifier threshold tests ham butun fit→standardize→classify zanjirini sertifikatlamaydi.

**Tavsiya, hali tanlanmagan:** Backend bilan reviewed numerical error bound, zarur joyda high-precision yoki certified boundary fallback; barcha cutofflarda end-to-end permutation/near-boundary fixtures va exact categorical parity. Arbitrary epsilon yoki Tni 2 kasrga yaxlitlab darajani ko‘tarish kiritilmasin. θ/b/Z/T uchun 1e−6 yaqinlik darajalar tengligini kafolatlamaydi. Oracle/profil/testni bu paket o‘zgartirmadi. Dalil: `evidence/INDEPENDENT-RASCH-NUMERICS.json`.

SD1.5/2 hali texnik tavsiya, yagona isbotlangan optimum emas. 60 synthetic matrix/360 fit real cohort calibration emas. Guruh-relative Z/Tning o‘zidan N=2 unequal θ uchun T=40/60; N<5 uchun A+ mumkin emas, chunki max Z≤sqrt(N−1). Bu tasdiqlangan normalizatsiyaning oqibati, yangi minimal cohort yoki cutoffs o‘zgartirish talabi emas.

## MR2-C01: P1, replay va activationni ajratish

Original reja barrier/recoveryni existing run lookupdan oldin tekshiradi. Keyingi recovery qayta ochilganida bu 200/202 ayni run va’dasiga zid 409 berishi mumkin. §5 hujjat taklifida tartib aniqlashtirildi: har chaqiriqda current auth/scope; canonical lock; mavjud run bo‘lsa ayni immutable/nonterminal run receipt; faqat run yo‘qligida yangi activation barrier/profile/snapshot. Bu bekor qilingan vakolatni tiklamaydi, current access har safar tekshiriladi. Runtime concurrency testi hali bajarilmagan.

## MR2-C02/C03: P1, sxema qabul qiladigan nomuvofiq holatlar

Original `/components/schemas/RaschRun/allOf/2` failed va not_estimable uchun umumiy reason enum qo‘llaydi. Mustaqil Draft202012 tekshiruvi not_estimable+NONCONVERGENCE hamda failed+ZERO_OR_NEGLIGIBLE_VARIANCE payloadlarini rad etmaydi. Taklif: not_estimable faqat EMPTY_COHORT/ZERO_OR_NEGLIGIBLE_VARIANCE; failed faqat numerical/input failure reasonlar; completed reason null. Existing exact reason enum bilan Backend review qilishi kerak. Pupil projectiondagi STANDARDIZATION_UNAVAILABLE hamda CALCULATION_UNAVAILABLE alohida qoladi.

`RaschAnalysisStatus` can_calculate=true bilan admission_closed=false, all_started_attempts_completed=false, pending_recovery_start_rights=true yoki blocking_codes bo‘sh emas holatlarni ham qabul qilishi mumkin. Taklif: true faqat tegishli auth + all first-activation gates + run absent + blockers empty. false uchun teskari equivalence majburlanmaydi: boshqa policy/auth/profile gate bo‘lishi mumkin. Server atomic gate har holda kerak; JSON Schema runtime holatni isbotlamaydi.

Bu review.2 runtime wire schemalarni o‘zgartirmadi. Exact negative payloadlar `evidence/INDEPENDENT-CONTRACT-COUNTEREXAMPLES.json`da; tuzatish Backend egasi reviewidan keyingi alohida schema change bo‘ladi. Qabul mezoni sifatida qo‘shimcha testlar QA jadvaliga qo‘shilgan, ular implementatsiya qilinmagan.

## Qarorlar: tasdiq o‘rniga aniq taklif

| ID | Ochiq masala | Tavsiya va qolgan qaror |
|---|---|---|
| MR2-D01 / R-04 | Admin Raschni boshlashi | Owner-granted explicit scoped capability tavsiya; existing closed Capabilitiesda calculate_rasch yo‘q. Admin read/export/review huquqidan mutation chiqarilmaydi. User vakolatni hal qiladi, Backend wire shaklini belgilaydi. Teacher own-group va Owner mavjud huquqi saqlanadi. |
| MR2-D02 / R-05 | Snapshotdan keyingi recovery | Original run tarixiy/o‘zgarmas qolishi, cancelled predecessor nonofficial, successor own ordinary va inherited/new Raschsiz bo‘lishi tavsiya. User qarori hali yo‘q. Existing recovery yashirin taqiqlanmaydi. Queued/running/terminal, predecessor/successor, result/history/export/diagnostics va lock orderingni birga hal qilish kerak. |
| MR2-D03 / OG-01 | Ordinary arithmetic/storage/display | Decimal input/amount arithmetic, exact numerator/denominator, hujjatlashtirilgan percentage precision va faqat final display rounding tavsiya. Half-up 2 kasr taklif, tasdiq emas. 1/3×100 kabi recurring foizni finite storage aynan saqlay olmaydi. Rasch Float64 ordinary hisobga ko‘chirilmaydi. Number→decimal-string wire, scale/cap yoki accepted-input cheklovi kiritilmadi. |
| MR2-D04 | Initial individual-toggle | Yangi test boshlanganda off/on alohida UX qarori, hisoblash aniqligi masalasi emas. Default o‘ylab topilmadi. |
| MR2-D05 | Terminal numerical failure | Same nonterminal infrastructure retry tavsiyasi va terminal failed/not_estimable immutable holati ajratildi. Terminal failed runni abadiy consume qilishi mavjud rejadagi failure-policy taklifi, userning yangi quoted qarori emas. Qayta hisob/reset ruxsati berilmadi. |

Actual demo kontenti/kaliti/duration/roster/date, target-stack resurslar, auth/RLS/job/UI, real pupil pilot va release qabul dalillari hamon yo‘q. Ular hujjat tayyor bo‘lgani sabab completedga o‘tkazilmadi.

## MR2-P01: manba yaxlitligi va tarixiy matn

`REVIEW-SOURCE-INDEX.json` va `MANIFEST.json`dagi besh baseline faylga references/ prefiksi qo‘shildi. Avval master va plan nomlari joriy fayllar bilan adashgan, qolgan uchtasi topilmagan. Manba SHA/bytes o‘zgarmadi. Master §17–18 tarixiy overlay sifatida belgilandi; §0.5/20 amaldagi review holatini beradi. §13 matni o‘zgarmadi. OpenAPI stale `x-reconstruction-decisions` metadata U5/U6/U7ga mos aniqlashtirildi; original nusxa `source/map-review.1/` va original ZIPda to‘liq saqlanadi.

## MR2-V01: nimani tekshirganimiz va nimani tekshirmaganimiz

`VALIDATION-RESULTS.json` joriy lokal dalillarni, failed/open topilmalarni va NOT_RUNni alohida qayd qiladi. Original 135 case/passed135 ro‘yxati harnesssiz tarixiy report, yangi exhaustive rerun deb ko‘rsatilmaydi. Original 37 math test/360fit natijalari source evidence sifatida saqlangan; yangi rerun bo‘lsa alohida evidence va status bilan ko‘rsatiladi. JSON parse, local refs va JSON Schema meta-validation runtime state semanticsni kafolatlamaydi. Production kod/DB/migration/provider/GitHub/deploy o‘zgarmadi; yangi review.2 tashqi agentlarga yuborilmagan; original review.1 aloqa holati AGENT_REVIEW_TABLE.md da alohida.

**MAP approval scope:** user MAP usullar oilasini tasdiqlagan. Joint/centered Gaussian variant va exact numerical qiymatlar texnik tavsiya. Unchanged profiledagi `method=joint_map` / `method_approval_status=USER_CONFIRMED` coarse source metadata shu tor doirada talqin qilinadi, specific variantga user approval degani emas.
