# UniverAcademy MAP review.2 — mustaqil tekshiruv

**2026-11-05. Xulosa: paket tuzilishi/yaxlitligi joyida, yakuniy kontrakt yoki implementatsiya uchun tayyor emas.** Tekshirilgan original ZIP SHA256 `eb3591299f669d110e4c1e4f69f98e8a76221f2a5014ab820a55cf6b88d5a6ff`. Original ZIP/fayllar o‘zgartirilmadi, attached instructionlar ijro topshirig‘i deb olinmadi.

## Tekshirilgan va tasdiqlangan

- 67 ZIP a’zo,65 manifest file va checksumlar mos. Original30 source fayl exact saqlangan; Master§13/1–127 reyestri oldingi nusxaga aynan teng.
- Bu muhitda **to‘liq OpenAPI3.1 validator ham ishga tushirildi**, xato0.193 komponent meta-sxemasi va910 ref xatosiz. Dotdagi NOT_RUN o‘sha muhit holati bo‘lib qoladi; ushbu dalil uni tarixdan o‘chirib qo‘ymaydi.
- Review.2 `paths` va `components` review.1 bilan aynan teng. Yangi tahrir topilmalarni hujjatlashtirgan, xatolarni tuzatgan deb da’vo qilmagan.

## Ochiq texnik topilmalar mustaqil tasdiqlandi

**1. Daraja savol tartibiga bog‘liq chiqmoqda (MR2-N01).** Original quoted5×12 matritsa ushbu BLAS/muhitda aynan A↔A+ bermadi; shuni takrorlangan deb ko‘rsatmaymiz. Lekin shu nuqson mustaqil5×12(seed5) va ayniqsa30×45(seed9) exact-boundary misollarda takrorlandi.30×45da24 o‘quvchi44/45,6 o‘quvchi45/45. Complete Raschda bir xil raw total θlari teng; yuqori guruhning exact Z=sqrt(24/6)=2, T70 va A+. Original tartibda6tasi69.99999999999997/A, reversed tartibda70/A+ oldi. Sonli farq juda kichik bo‘lsa ham categorical natija noto‘g‘ri o‘zgaradi.

Oldingi37 math test numeric parameter yaqinligini/threshold functionni alohida tekshirgan, bu full fit→normalization→grade chegara holatini qamrab olmagan. Bu oldingi «PASS»ni universal aniqlik isbotiga aylantirib bo‘lmasligini ko‘rsatadi. Faqat savollarni sort qilish farqni bir yo‘nalishda yashirishi mumkin, lekin exact T70ni A qilib qo‘yish xavfini hal qilmaydi. Arbitrary epsilon yoki display2 rounding bilan user cutoffini o‘zgartirmang. Reviewed numerical error control/high precision/boundary fallback va barcha cutofflar bo‘yicha categorical/permutation regression kerak; bu audit solverni o‘zgartirmadi.

**2. Status/reason semantikasi (MR2-C02).** Review.2 sxemasi `not_estimable+NONCONVERGENCE` va `failed+ZERO_OR_NEGLIGIBLE_VARIANCE`ni qabul qiladi. Ikki outcome reason enumini alohida cheklash kerak: not_estimable uchun EMPTY_COHORT/ZERO_OR_NEGLIGIBLE_VARIANCE; failed uchun numerical/input failurelar; completed/null va queued/running/null qoidalari saqlanadi. Bu actual serverda shu xato sodir bo‘lganining dalili emas.

**3. Readiness ziddiyati (MR2-C03).** `can_calculate=true` bo‘lib admission ochiq, active attempts bor, ready recovery bor va blockerlar mavjud payload schema-valid. True branchda local flags/barrier/run-null/blockers-empty consistency cheklovi kerak. False uchun blanket inverse equivalence qo‘ymang; current auth/profile va actual atomic server holati schema tashqarisida tekshiriladi.

**4. Replay tartibi (MR2-C01).** Dot taklifi mantiqan asosli: current auth/scope → canonical existing-run lookup/replay → faqat run yo‘qligida first-activation gates/snapshot. Keyingi recovery existing receiptni yangi activationga aylantirmaydi; revoked huquq replayda ham rad qilinadi. Runtime dalili hali yo‘q, bu hujjat tartibi taklifi.

## Foydalanuvchi qarorlari endi aniq

`USER_DECISIONS_AFTER_REVIEW2.md`dagi shu chat javoblari: Admin Rasch boshlamaydi (Teacher own scope va Owner oldingi huquqi saqlanadi); post-Rasch recoveryda eski Rasch immutable tarix, successor own ordinary va inherited/recomputed Raschsiz; initial individual toggle off. Ular MR2-D01/D02/D04 mahsulot tanlovlarini yopadi, technical implementation/projection testsini yopmaydi.

## Keyingi kontrakt tahriri uchun aniq ish

1. Userning uch qarorini Master/Contract/OpenAPI/projection/recovery/Panel matrixga moslab kiritish; original history/source/hashlar saqlansin.
2. Numerical cutoff mekanizmini Backend asoslab review qilsin; original va yangi30×45 counterexample, barcha46/50/55/60/65/70 exact/near boundaries, row/question permutations va Backend/reference categorical parity testlari bilan yopilsin. Core/test/oracle codega o‘zgartirish alohida tasdiqlangan scope talab qiladi; bu auditda ular o‘zgarmadi.
3. Status/reason va can_calculate local consistency sxemalarini Backend tuzatsin; ijobiy va salbiy payloadlar bilan qayta tekshirilsin. Full OpenAPI validator o‘tishi bu semantic testlarni almashtirmaydi.
4. Ordinary decimal storage/midpoint rounding va failure retry policy texnik tavsiyalari aniq ajratilsin. Existing one-shot qoidasiga zid yangi reset yoki user huquqi tasdiqsiz kiritilmasin.
5. Backend/Bot/Panel/QAning actual yangi fayl/version/xeshlarga accept/block xabarlari olinsin. Hozirgi paketda ular yo‘q; coordinatorning environment/send-error qaydlari mustaqil tasdiqlangan yuborish qabuli emas.

Asl135-case harnessi review.2da qayta bajarilmadi, actual server/DB/RLS/UI/jobs/real pupils va agent state tekshirilmadi. Migration, production kod/provider/GitHub/deploy yoki tashqi xabar yuborish bo‘lmadi. Evidence JSON barcha input, seed, permutation, schema counterexample va actual outputni saqlaydi.
