# Review.2dan keyingi foydalanuvchi qarorlari

Sana2026-11-05, Asia/Tashkent. Mantiqiy source ID `UA-SRC-REVIEW2-DECISIONS-20261105`; platforma UUIDsi/aniq vaqt berilmagan. Quyidagi javoblar shu chatdagi asinxron savollarga foydalanuvchidan olingan.

| Band | Foydalanuvchi javobi | Tasdiqlangan talqin |
|---|---|---|
| Admin Raschni o‘z vakolati doirasida boshlashi | «Yo‘q, o‘qituvchi ishga tushirsin» | Admin roliga Rasch activation vakolati berilmaydi; Teacher own-group/subject action, Eganing mavjud umumiy huquqi saqlanadi. Admin read/export va oldin tasdiqlangan boshqa huquqlar o‘zgarmaydi |
| Raschdan keyingi technical recovery | «Ha, tarix va yangi urinish alohida» | Eski Rasch original snapshotga bog‘liq immutable tarixda. Cancelled predecessor nonofficial. Successor o‘z ordinary natijasi bilan, eski Raschni meros olmasdan/qayta hisoblamasdan ko‘rsatiladi. Existing recovery vakolatlari yashirin taqiqlanmaydi |
| Yangi test initial individual toggle | «Ha, boshlanishida o‘chiq» | Initial UI off: har savol1. Teacher keyin individualni yoqib musbat kasr ball qo‘yishi mumkin. Existing required API booleanni yuborish tartibi saqlanadi; schema `default` annotation o‘zi server default yoki omitted request permissioni emas |

Bu javoblar original review.2 ZIPni o‘zgartirmaydi. Keyingi kontrakt tahririga kiritilishi kerak. Ular numeric boundary bugini tuzatmaydi va agent acceptance bermaydi. Existing confirmed45/editable,MAP,exact unavailable message,self-submitted-only,unanswered0,positive points/display2,Asia/Tashkent,one-shot va bonusning bekorligi saqlanadi.
