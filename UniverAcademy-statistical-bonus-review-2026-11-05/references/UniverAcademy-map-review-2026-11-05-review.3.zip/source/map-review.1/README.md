# UniverAcademy — MAP qarori va numeric tavsiya paketi

**2026-11-05.** MAP va teng natijadagi «Rasch darajasini aniqlab bo‘lmadi» — user tasdiqlagan. Numeric baseline1.5/2 asoslangan tavsiya, productionga joriy qilingan konfiguratsiya emas.

O‘qish tartibi:

1. `MAP_REVIEW_CHANGES.md` — qisqa o‘zgarishlar.
2. `MAP_SETTINGS_RECOMMENDATION.md` — qiymatlar, asos, alternativalar va kuzatilgan cheklovlar.
3. `RASCH_MAP_PROFILE_RECOMMENDED.json` — bir xil sonli profilning machine-readable nusxasi.
4. `UNIVERACADEMY-API-CONTRACT-0.2.6-map-review.1.md` / `openapi-UniverAcademy-0.2.6-map-review.1.json` — current contract va to‘liq JSON.
5. `UNIVERACADEMY_MASTER_CONTEXT.md` —0.4/13.11/19 joriy, tarixiy registry saqlangan.
6. `BACKEND_IMPLEMENTATION_PLAN.md` va `QA_ACCEPTANCE_MATRIX.md` — data/API/UI/test va release rejasi.

`QA/` local reference,37 test,30×45 fixture, fit natijasi va360fit sensitivity experiment. `QA/map_profile_study.py`ni qayta ishga tushirish o‘z papkasidagi artefaktlarga yozadi; production ma’lumoti yoki APIga murojaat qilmaydi. NumPy reference backend stack tanlovi emas.

`USER_MAP_DECISION_2026-11-05.md` yangi manba; `references/` oldingi pending qarorlar va exact baseline fayllari, current qoida o‘rniga olinmaydi. `VALIDATION-RESULTS.json`, `MANIFEST.json`, `SHA256SUMS.txt` dalil/hashlarni bog‘laydi. Foydalanuvchi method tasdig‘i numerical conformance/agent acceptance/production migration ruxsatiga aylantirilmaydi.
