# UniverAcademy — MAP sozlamalari uchun asoslangan tavsiya

**2026-11-05, Asia/Tashkent.** Raschda MAPdan foydalanish va teng natijada «Rasch darajasini aniqlab bo‘lmadi» ko‘rsatish — U7 foydalanuvchi tasdig‘i. Quyidagi exact raqamlar **REC-MAP-01 texnik tavsiyasi**, user ularni o‘zi bergan degan da’vo emas. Profil `RASCH_MAP_PROFILE_RECOMMENDED.json`, version1.0.0. Ishlab turgan ilova/baza/migration/deployment o‘zgartirilmagan.

## 1. Tavsiya: boshlang‘ich pilot profili

| Parametr | Qiymat | Oddiy ma’nosi va sababi |
|---|---|---|
| O‘quvchi θ priori | Normal(0,1.5²) | Oldingi SD1ga nisbatan yumshoqroq cheklov; kuchliroq yoki kengroq farqli guruhda θni markazga ortiqcha tortishni kamaytiradi, proper finite himoya qoladi |
| Item priori | β~Normal(0,2²I), b=Qβ | Qiyinlik uchun kengroq tarqoqlik, extreme itemlarni tushirib qoldirmasdan finite regularizatsiya |
| Identifikatsiya | sum(b)=0, orthonormal Helmert Q | O‘quvchi/item parametrlarining bir xil siljishi bilan bir nechta ekvivalent yechim qolmasin |
| Likelihood | Rasch1PL: sigmoid(θ−b), a1, guessing0 | Qo‘l balli, bonus faktori yoki har savol uchun erkin discrimination qo‘shilmaydi |
| Optimizer | Double precision damped Newton, analytic gradient/Hessian | 30×45 hajm uchun deterministik va tekshiriladigan lokal yechim; SPD linear solve, inverse emas |
| Boshlanish | θ=β=0 | Takroriy hisob/reference uchun deterministik |
| Convergence | max(abs(gradient))≤1e−7; max200 iteration | Floating-pointning oxirgi xonalarida stallga haddan tashqari qat’iy1e−8dan ehtiyotkorroq; hali aniq parametr yechimi talab qilinadi |
| Line search | Step1, Armijo1e−4, max50 qisqartirish | Har qadam objective kamayishini tekshiradi |
| Norm | Frozen eligible cohort mean, populationσ(ddof0) | Aynan shu guruhni o‘z ichida standartlash, boshqa population variance estimate emas |
| Degenerate himoya | Equal raw totals yoki σ≤1e−8 | Nolga/numerik shovqinga bo‘lish oldidan to‘xtatish; θ/qiyinlikni clamp qilish yoki C+ yaratish yo‘q |
| Saqlash | Profile ID/version/SHA, input hash, actual μ/σ/N, θ/b va fit diagnostikasi | Bir martalik hisobni keyin tekshirish va yangi profil bilan eski natijani overwrite qilmaslik |

SD1.5 va SD2 testning savol ballari emas. Bular ichki logit shkalasidagi prior tarqoqligi. SD1.5da markaziy taxminan95% oralig‘i ±2.94 logit, lekin bu qattiq chegara emas; javoblar tashqaridagi θni ham chiqarishi mumkin. O‘rtacha b0 item uchun ushbu prior oralig‘i taxminan5–95% to‘g‘ri ehtimolga mos — bu bizning formula bo‘yicha talqinimiz, biror o‘quvchiga oldindan berilgan baho emas.

`b=Qβ` zero-sum tekislikda: itemlar majburan mustaqil emas. `Var(bj)=4(1−1/J)`; J45da marginal SD taxminan1.978. «Har bj mustaqil SD2» deb implementatsiya qilish shu centered profilega aynan teng emas. QᵀQ=I va 1ᵀQ=0 shartlari offline testda tekshiriladigan identifikatsiyadir.

Prior SD1.5 **guruhning keyingi standartlash σsi emas**. Student darajasi uchun σ har safar saqlangan eligible θlardan hisoblanadi; uni1,1.5 yoki2ga qo‘lda almashtirish yo‘q. Frozen profile hamma guruhga bir xil, Teacher faqat optional hisobni boshlaydi. Guruhga ko‘proq A+ berish uchun priorni almashtirish yoki keyin qayta hisoblash endpointi yo‘q.

## 2. Formula va manbadan ajratilgan tanlov

Negative log posterior:

`L=Σij[softplus(θi−bj)−Xij(θi−bj)] + Σiθi²/(2·1.5²) + Σjbj²/(2·2²), sum(b)=0`.

Likelihood user bergan haqiqiy1PL formulasi. Gaussian quadratic penalty proper priorni ifodalaydi. Positive prior precisions sabab constrained Hessian SPD bo‘ladi; shu objective qat’iy convex va finite unique optimumga ega — bu aynan bizning matematik objective bo‘yicha xulosa. Float64 hisob esa convergence/finite guardlar bilan tekshiriladi, nazariya runtime test o‘rnini bosmaydi.

[Stan IRT hujjati](https://mc-stan.org/docs/stan-users-guide/regression.html#item-response-theory-models)1PL va prior/identificationni tushuntiradi, priorga sezgirlikni alohida qayd etadi. Undagi misol parametrlarini real loyiha uchun tayyor norma deb ko‘chirmadik. **1.5/2 bizning pilot kompromissimiz**, universal optimal yoki majburiy Rasch sonlari emas. Keyingi real-data/hierarchical model varianti alohida versioned review bo‘lishi mumkin; bu safar yangi hierarchical model yoki guruhlararo pooling joriy qilinmadi.

Stable softplus `max(η,0)+log1p(exp(-abs(η)))`/teng barqaror funksiya, stable sigmoid. Katta |η|da naiv log(sigmoid)ning aniqlik muammosi [SciPy rasmiy hujjatida](https://docs.scipy.org/doc/scipy/reference/generated/scipy.special.log_expit.html) ko‘rsatilgan. Bu backend uchun SciPy servisi/dependency tanlovi emas; QA oracle NumPyda, amaldagi backend stack tekshirilmagan.

## 3. Qanday tekshirildi

Mahalliy sintetik experiment: **5 scenario ×12 seed =60 distinct30×45 matritsa; har birida6 prior profili =360fit**. Scenario: balanced ability, tor ability, keng ability, higher mean va keng item difficulty. True θ/b/P simulyatsiyada ma’lum, b mean0ga keltirilgan. Barcha360 fit completed, numerical failure0. Kod, seed, scenario parametrlari va input digestlar `QA/map_profile_study.py` / `QA/MAP-SENSITIVITY-RESULTS.json`da. Bir xil inputlar variantlar orasida qayta ishlatildi; natijalar real pupil ma’lumoti emas.

RMSE — simulyatsiyadagi asl qiymatdan odatiy og‘ish, kichikroq bo‘lsa shu experimentda yaxshiroq. Jadval5 scenarioga teng vazn beradi, bu haqiqiy UniverAcademy guruhlari shunday taqsimlanganini anglatmaydi.

| θ SD / item SD | θ RMSE | b RMSE | P RMSE | T RMSE | Simulated true darajadan farq, o‘rtacha30dan |
|---|---|---|---|---|---|
| 1 / 2 | 0.4208 | 0.5209 | 0.0931 | 3.9009 | 11.68 |
| 0.75 / 2 | 0.4774 | 0.5320 | 0.0956 | 3.9178 | 11.68 |
| 1.5 / 2 | 0.3877 | 0.5148 | 0.0929 | 3.8886 | 11.70 |
| 2 / 2 | 0.3855 | 0.5143 | 0.0935 | 3.8881 | 11.62 |
| 1 / 1 | 0.4452 | 0.6472 | 0.0957 | 3.8960 | 11.68 |
| 1 / 3 | 0.4164 | 0.5202 | 0.0940 | 3.9025 | 11.68 |

Tavsiya1.5/2 oldingi1/2ga nisbatan o‘rtacha θ RMSEni **7.87%** kamaytirdi (0.4208 → 0.3877); P RMSE juda oz yaxshilandi. Balanced va tor guruhlarda ayrim kuchliroq prior variantlari yaxshiroq bo‘ldi; keng/higher-mean guruhlarda1.5 foydaliroq. SD2 θ RMSEda yana oz foyda berdi, lekin1.5ni kamroq ekstremal pilot kompromissi sifatida tanladik. Bu «hamma scenario va kelajak data uchun eng yaxshi» xulosasi emas.

**Daraja aniqligini yashirmaymiz:** recommended profileda simulated latent T darajasidan farq30dan o‘rtacha **11.70** kishida bo‘ldi, T RMSE **3.8886**. Bu actual product error rate yoki rasmiy sertifikat xatoligi emas; finite45 javobdan latent θni baholash va5-point daraja chegaralarining cheklangan ma’lumotga sezgirligi.1.5/2ni tavsiya qilish shu farqlarni «tasdiqlangan sertifikat aniqligi»ga aylantirmaydi.

Oldingi1/2dan1.5/2ga o‘tganda o‘rtacha 0.43/30, ayrim matritsada5/30 daraja o‘zgardi. Shu sababli profil birinchi hisobdan oldin muzlatiladi; eski natijalar bu hujjat sabab qayta hisoblanmaydi. Boshqa priorlarga sezgirlik exact studyda recommended va old baselinega nisbatan alohida berilgan.

## 4. User tasdiqlagan teng-natija holati

Same full question set va same prior ostida hamma eligible raw correct count teng bo‘lsa, Rasch θlari ham teng. Guard **Raschning unweighted raw total/θsiga** tegishli; teacher weighted ordinary ball tengligi yetarli mezon emas. Finite θ/b estimate saqlanishi mumkin, lekin Z/T bo‘linmaydi. Student status `not_estimable`, reason STANDARDIZATION_UNAVAILABLE, level null; Mini App/Panelda aynan **«Rasch darajasini aniqlab bo‘lmadi»**.

σ≤1e−8 numeric floor faqat hisoblash himoyasi; yangi minimal cohort yoki o‘quvchining bilimi chegarasi emas. N0da existing EMPTY_COHORT, N1da variance0, equal totals/different patterns, all-right/all-wrong va numerical error oldingidek alohida tekshiriladi. Numerical failed haqiqiy mavjud T<46 `no_level` bilan aralashtirilmaydi. Ordinary ball/maksimal/foiz o‘zgarmaydi, fake T50/C+ berilmaydi.

## 5. Qaysi dalil hali yo‘q

37 local executable math test va sintetik profile comparison formal real-population calibration emas. [Stan predictive checking qo‘llanmasi](https://mc-stan.org/docs/stan-users-guide/posterior-predictive-checks.html) prior va modeldan qanday data chiqishini tekshirish zarurligini bayon qiladi; bizning experimentni full posterior predictive validation yoki SBC deb atamaymiz. Real anonymized pilot javoblari bilan model fit, sensitivity va natijani talqin qilish keyingi ish.

30 kishilik kichik sample cheklovlari [Linacre sample-size muhokamasida](https://www.rasch.org/rmt/rmt74m.htm) ham ko‘rsatilgan; bu manba maxsus1.5/2ni ma’qullamaydi. Kontrakt minimal30 cheklov qo‘shmadi. Teacher kamroq/ko‘proq savol tanlasa core soniga hardcode yo‘q, lekin qisqaroq testning statistik aniqligi avtomatik bir xil bo‘lmaydi.

Actual Backend/SQL/RLS/worker concurrency/UI/runtime benchmark, actual pupil pilot va yangi agent exact-byte acceptance NOT_RUN. NumPy oracle runtime qaysi xizmatda ishlashini tanlamaydi. Existing release/production migration ruxsati alohida; bu topshiriq faqat hujjat/QA tavsiyasidir.
