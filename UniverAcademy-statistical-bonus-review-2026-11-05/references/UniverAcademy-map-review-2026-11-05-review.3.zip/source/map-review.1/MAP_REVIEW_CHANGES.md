# UniverAcademy — MAP tasdig‘idan keyingi o‘zgarishlar

**2026-11-05, Asia/Tashkent.** API **0.2.6-map-review.1**, Master **1.4-map-review.1**; mahalliy review nusxalari, published release yoki production acceptance emas.

**Foydalanuvchi tasdiqlaganlar:** MAP usuli va bir xil Rasch natijada aynan «Rasch darajasini aniqlab bo‘lmadi» ko‘rsatish. Source U7 `UA-SRC-MAP-CONFIRMATION-20261105`; original xabar/hash `USER_MAP_DECISION_2026-11-05.md`/source indexda. Oldingi MAPni tushuntirish kutilmoqda holati yopildi.

**Tavsiya qilingan numeric profil:** θ prior SD1.5, item zero-sum contrast prior SD2, Gaussian joint MAP, sum(b)0, float64 damped Newton/Armijo, gradient1e−7/max200, populationσ(ddof0), sigma floor1e−8 va equal raw-total guard. Profile1.0.0 ID+SHA bilan muzlatiladi, Teacher numeric priorni guruhga qarab o‘zgartirmaydi. Bu exact qiymatlar userning literal topshirig‘i emas, asoslangan texnik tavsiya. Sabab/alternativalar/haqiqiy cheklovlar `MAP_SETTINGS_RECOMMENDATION.md`da.

**Joriy hujjatlar:** Master/API/Backend reja/MAP izohi/QA matrix yangilandi; alohida profile JSON va dalilli recommendation qo‘shildi. Mavjud student DTO o‘zgarmadi: `not_estimable` +STANDARDIZATION_UNAVAILABLE+null level Mini App/Panelda exact xabarni render qiladi. Equal Rasch raw totals mezoni weighted ordinary ball bilan aralashtirilmaydi. μ/σ/finite θ/b saqlanishi mumkin, Z/T/level null; ordinary unchanged.

**Saqlangan scope:** ikki baholash, statistical bonus bekor, default45 Teacher-editable, self-submitted-only va unanswered0, expired/forced/cancelled/no-show excluded, all-started/late admission/ready recovery barrieri, positive fractional ordinary/display2/full precision, Asia/Tashkent, one logical immutable run.1–127 va oldingi barcha registry matnlari aynan saqlandi; yangi13.11/19 overlay.

**Bajarilgan offline tekshiruvlar:**37 executable mathematical test,135 contract/privacy/preservation case va to‘liq OpenAPI3.1.60 yo‘l/68 amal/193 sxema/910 local ref, xato0.60 distinct synthetic30×45 matrix/6 profiles=360fit, numerical failure0. Uchta xulosa ajratildi: numerical stability kuzatildi;1.5/2 tanlovi ushbu scenariolarda kompromiss; actual pupil/official certificate accuracy hali isbotlanmagan. Simulated latent daraja bilan farqlar recommendationda yashirilmagan.

**Bajarilmagan:** real Backend/API/auth/RLS/DB/parallel jobs/UI/real pupil pilot/calibration/release tests; agent exact-byte acceptance. Ilova kodi/production DB/migration/provider/GitHub push/deploy/agent holati o‘zgarmadi; tashqi xabar yuborilmadi. Oldingi paketing barcha manifest xeshlari qayta solishtirildi, asl fayllar unchanged.

**Qolgan ochiq ishlar:** numerical Backend conformance va actual-data fit, Admin Rasch mutation, post-run recovery, ordinary midpoint rounding/storage/initial toggle, actual demo konfiguratsiya va existing staging/release checks. MAP yoki exact equal-outcome xabarni qayta tanlash so‘ralmaydi.
