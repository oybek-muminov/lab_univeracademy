# Rasch categorical boundary resolution: technical proposal

Status: **RECOMMENDED DESIGN, NOT IMPLEMENTED, NOT A CLOSED AUDIT FINDING.**

This proposal preserves the user-confirmed MAP method family, exact inclusive cutoffs46/50/55/60/65/70, no clamping, and classification before display rounding. The specific joint/centered Gaussian MAP model, population ddof0, priors and variance floor remain the recommended technical profile, not separate user-specified choices. It requires backend numerical review, a versioned implementation/profile decision, independent certification and new regression tests before acceptance. No existing solver, test, validator, production code, source ZIP or approved history was edited for this investigation.

## Evidence and limits

- Reviewed review.2 ZIP SHA256: `eb3591299f669d110e4c1e4f69f98e8a76221f2a5014ab820a55cf6b88d5a6ff`.
- Supplied independent audit ZIP SHA256: `575139d98e7adbc23e269b07492fe87640d3aa1e299a2660381f49bc1eee8779`.
- Unchanged archived `QA/rasch_reference_math.py` SHA256: `9e1020fe1d33df7a13ecbf28689b215bebf6d64f733d0798fdd421d44092cf95`.
- Fresh read-only evaluation is recorded in `evidence/NUMERICAL-BOUNDARY-DESIGN-EVIDENCE.json`. The oracle source was read directly from the original ZIP and executed without running its test-file entry point or modifying source artifacts.
- In this run, the independent audit's 30×45 seed-9 input assigned A to all six high-score pupils in original, question-reversed, row-reversed and both-reversed orders. Their approximate T values ranged from 69.99999999999993 to 69.99999999999999. The mathematically exact answer is 70/A+ in every order. Thus wrong categorical classification is independently confirmed here; the audit's particular A↔A+ order flip is **not** claimed to recur in this execution. The 5×12 seed-5 example returned A+ in these four local runs. Platform-dependent details remain recorded separately rather than overwritten.
- The mathematical proof below does not depend on a particular BLAS, seed, optimizer tolerance or observed permutation flip.

## 1. Define the target, not a numerical tolerance band

For the unique exact MAP solution θ*, let μ* be its population mean and σ* its population standard deviation (ddof=0), on the same frozen eligible cohort. When standardization is available, T*=50+10(θ*−μ*)/σ*. A level is the highest exact threshold T* reaches; equality is inclusive. A display value or an approximate intermediate float is not the definition of T*.

Keep the existing variance guard. All equal raw totals imply exactly equal θ*, hence unavailable standardization. Otherwise certify σ*>10⁻⁸ before grading, or certify σ*≤10⁻⁸ to return not_estimable/ZERO_OR_NEGLIGIBLE_VARIANCE. Do not turn uncertainty about σ* into a proven negligible variance result. An interval crossing the variance floor requires refinement or a numerical failure.

Prohibited shortcuts:

- No `T + epsilon`, `isclose(T, cutoff)`, fixed decimal rounding, ULP promotion, or tolerance band that turns genuinely subthreshold T into a higher grade.
- No assumption that two converged high-precision outputs, or equal rounded outputs, prove the exact side of a threshold.
- No sorting-only fix or post-hoc averaging of approximately equal abilities presented as a proof of correct classification.
- No treating the existing 1e−7 gradient stopping criterion as a categorical correctness certificate.

## 2. Exact structural proof for equal raw totals

In the complete same-item 1PL model with the current common zero-mean person prior, the person score equation is

r_i = Σ_j sigmoid(θ_i−b_j) + (4/9)θ_i.

For fixed item difficulties, the right-hand side is strictly increasing in θ_i. Therefore equal integer raw totals have exactly equal MAP abilities, and higher raw totals have strictly higher abilities. This remains true when unanswered entries are coded as 0 under the existing contract. It is not applicable to arbitrary missing-item likelihoods, heterogeneous person priors, 2PL or a changed model.

The likelihood depends on the response matrix through exact row and column totals. A backend may use sorted integer sufficient statistics and solve one ability per distinct raw total (with multiplicity-weighted likelihood/prior terms) rather than estimating mathematically equal persons independently. Analogous item-total grouping is possible with correctly weighted zero-sum identification. This is an exact reparameterization, not averaging fitted values. Its objective/gradient equivalence requires tests. Canonical ordering improves reproducibility but **does not itself certify boundaries**.

For precisely two distinct raw totals, with L low-score people and H high-score people, θ_low<θ_high. After the variance guard is certified:

- Z_high = √(L/H).
- Z_low = −√(H/L).

These identities eliminate all fitted ability magnitudes from classification. Compare the square-root ratios to rational cutoff Z values using exact integer products and sign checks; do not evaluate the square root in binary floating point to decide equality.

For audit counts L=24,H=6, Z_high=2 and T_high=70 exactly. All six high-score people must receive A+; Z_low=−1/2 gives T_low=45 and no level. This is exact model reasoning, not rounding an approximate T up to 70.

## 3. General-case certificate and precision fallback

Use the current float64 solver as a fast candidate producer, not as the final authority at a boundary. Verify the candidate with rigorous outward-rounded interval arithmetic, including exponentials and all sums. Ordinary arbitrary-precision point arithmetic alone is not rigorous interval certification.

A simple global certificate is available for the current prior:

- Work in variables p=(θ,b) on the subspace Σb=0. The prior precisions are 4/9 and 1/4.
- The logistic Hessian is positive semidefinite. Thus the objective is at least 1/4 strongly convex on that subspace, and has a unique optimum.
- Center the candidate b exactly for verification. Binary floating-point candidates can be treated as exact dyadic rationals before exact centering; their tiny sum error must not be assumed zero.
- Compute a certified upper bound R on the Euclidean norm of the gradient projected to the subspace. The person gradient is Σ_j sigmoid(θ_i−b_j)−r_i+(4/9)θ_i. The unprojected item gradient is c_j−Σ_i sigmoid(θ_i−b_j)+(1/4)b_j; subtract its item mean to project it.
- The exact solution is within δ=4R of the candidate in Euclidean norm. This follows from strong convexity, not a heuristic relation between gradient size and answer quality.
- Consequently each centered ability error is at most δ√(1−1/n), mean error is at most δ/√n, and standard-deviation error is at most δ/√n. Include outward-rounded candidate mean/variance errors as well. A tighter verified Hessian/interval-Newton certificate may be used if independently reviewed.

The resulting enclosure must first settle standardization availability, then settle every required grade comparison. Finite bounds that straddle a threshold are unresolved, not a tie.

To avoid unnecessary square roots, let S=Σθ_i, d_i=nθ_i−S and V=nΣθ_i²−S², so σ²=V/n² and Z_i=d_i/√V. An equivalent, often numerically preferable expression is V=Σ_{i<j}(θ_i−θ_j)². For cutoff k:

- k=50: T_i≥50 iff d_i≥0.
- k>50: T_i≥k iff d_i≥0 and 100d_i²≥(k−50)²V.
- k<50: T_i≥k iff d_i≥0, or d_i<0 and 100d_i²≤(k−50)²V.

All sign conditions matter; squaring without them is wrong. Use exact rational arithmetic for a rational test vector and certified intervals over the exact-solution enclosure for fitted parameters. An interval proving a non-strict inequality may include an exact endpoint only if its outward bound itself proves the required sign. An interval merely overlapping zero does not prove equality.

If a decision remains unresolved:

1. Apply a verified structural equality proof when its exact preconditions hold, including the two-score identities above and formally recognized complement symmetry.
2. Otherwise refine the solution and its certificate at increased precision. Each stage must target the same objective and priors, not a changed model or threshold. Backend must freeze the precision stages and resource budget in its reviewed numerical profile.
3. Proposed mapping, pending Backend and failure-policy review: if the frozen budget is exhausted without a certificate, return the existing run outcome failed/NUMERICAL_FAILURE, with no fabricated grades or partial published success. Keep the detailed cause such as boundary certification unresolved in internal diagnostics; the pupil projection remains failed/CALCULATION_UNAVAILABLE with null level. Do not misuse not_estimable for an uncertain calculation.

This terminates deterministically even when a general exact equality cannot be established in finite computation. It does not promise that finite-precision refinement alone decides every exact equality. A recognized proof may decide an equality exactly; otherwise honest failure is safer than inventing a numerical threshold band.

For deterministic behavior, freeze the verifier, arithmetic implementation/version, sufficient-statistic ordering, precision ladder, and iteration/resource budgets. Prefer deterministic work limits over environment-dependent wall-clock cutoffs. Preserve certificates internally with run input/profile hashes. Exact recognition may record a mathematically exact T=70; it must not overwrite diagnostics to disguise an inaccurate float. There is no need to expose θ, T, intervals or solver details in the pupil API.

This proposal recommends that all refinements occur inside the original nonterminal run, before committing its single terminal result. It does not independently settle terminal-failure run consumption or retry policy; that needs explicit Backend/failure-policy acceptance under the existing one-shot constraints. No new activation, user reset/recalculate right, terminal retry, revised historic result or post-recovery inheritance is introduced.

## 4. Required regression specification

These are new test requirements, **not claims that existing tests were changed or that these release gates passed**.

### A. End-to-end exact boundaries

For k=46/55/60/65/70, construct binary matrices with two distinct raw totals, for example J−1 and J with J=12 and J=45. Distribute the single zero among low-score rows to include both equal-total/different-response-pattern and duplicate-pattern cases. Use the counts below:

| Cutoff | L | H | Target group | Exact target Z | Expected level |
|---|---:|---:|---|---|---|
| 46 | 25 | 4 | low | −2/5 | C |
| 55 | 1 | 4 | high | 1/2 | B |
| 60 | 2 | 2 | high | 1 | B+ |
| 65 | 9 | 4 | high | 3/2 | A |
| 70 | 24 | 6 | high | 2 | A+ |

Also retain the original quoted 5×12 matrix, the independent seed-5 5×12 input, and the seed-9 30×45 input byte-for-byte as regression fixtures. Expected grades come from the proof, not the old oracle's observed answer.

For cutoff 50, use `[[0,0],[1,0],[1,1]]`. Complementing responses and reversing both rows and columns leaves the matrix unchanged. With symmetric priors and uniqueness, the middle ability is exactly 0 and the extremes are negatives, hence μ=0 and middle T=50/C+. Its variance must separately be certified above the floor. Include larger constructed complement-symmetric cohorts as well.

### B. Exact near-boundary normalization tests

The independent evidence JSON records 18 mathematically checked cases: below, at, and above every cutoff, using exact Fraction arithmetic rather than the implementation's numeric answer.

- For 46/55/60/65/70, start with L copies of exact rational 0 and H copies of exact rational 1 using the table. Select one target-group coordinate and change only it by −10⁻¹², 0 or +10⁻¹². The low/high target indices and exact expected grades are in the JSON.
- For 50, start with exact rational abilities [−1,0,1] and change the middle value by the same three perturbations.
- Independently evaluate the sign-aware polynomial inequalities above. In all six families, the negative perturbation is strictly below the cutoff, zero is exactly at it, and the positive perturbation is strictly above it.
- Preserve decimal/rational input semantics in the independent oracle. If implementation tests instead use binary64 vectors, derive expectations from those exact dyadic values; do not pretend a parsed binary64 decimal is its original exact rational.
- Add direct comparator tests at `nextafter(k,−∞)`, k and `nextafter(k,+∞)` for all six cutoffs. Every immediate representable value below a cutoff must remain in the lower band. Existing subthreshold tests remain unchanged.

These constructed ability vectors are normalization-layer fixtures, not a claim that each vector is the MAP solution of a valid binary-response matrix. Additional general-cohort, near-boundary end-to-end binary fixtures must be found and certified independently before numerical acceptance. Two-score count families (changing L or H by one) provide exact full-fit fixtures on each side for 46/55/60/65/70; the distance and cohort size must be recorded rather than mislabeled as arbitrarily close. Near-50 binary fixtures require an independently certified nonsymmetric cohort.

### C. Categorical permutation and cross-implementation tests

- For every retained binary fixture, compare grades mapped to stable pupil identity after identity, reverse, and seeded independent row/question permutations; include both together. Exhaust all permutations for sufficiently small fixtures and a fixed documented seed set for larger ones.
- Assert exactly equal grade, status and reason after mapping. Numeric `allclose(θ)` or `allclose(T)` does not satisfy this requirement. All members of one raw-total class must receive the same grade.
- Independently verified backend/reference parity must use the same frozen binary input, cohort, prior/profile and thresholds. Backend and a copied oracle making the same mistake is not independent evidence.
- Exercise both solver fast path and forced high-precision fallback; vary candidate solver tolerance to show the certificate, not stopping tolerance, controls acceptance. Run supported runtime/library builds with pinned versions and record evidence.

### D. Certification and failure tests

- Feed candidates whose apparent T lies just above or below the cutoff while the certified interval crosses it. Neither may be classified until refinement/proof resolves the boundary.
- Verify the structural proof applies only after its preconditions and variance availability are established. All equal totals must still produce not_estimable, not a two-score branch or a fabricated C+.
- Force precision/resource exhaustion, interval-arithmetic failure, nonfinite input/optimization, and uncertain variance-floor comparisons. Check the correct failed result and absence of published grades; do not relabel them as valid no_level or mathematical not_estimable.
- Preserve empty cohort, equal totals, sigma floor, unanswered=0, ordinary-weight independence, snapshot immutability, no clamp, exact below-46 behavior and one-terminal-result coverage.
- Run the original suite unchanged in addition to these additions. A new verifier is not allowed to redefine the oracle, relax expected grades or delete the counterexamples merely to achieve a green report.

## 5. Acceptance and scope

Numerical closure requires approved implementation, independent certificate review, exact/near-boundary and categorical permutation tests across all six cutoffs, and backend/reference parity with hashes. This document and the fresh reproduction are **design/research evidence only**. They neither change the approved thresholds nor assert an implemented numerical repair. Existing profile/history hashes remain untouched; any deployed numerical implementation/profile revision must be explicit and frozen for each new run, with no retroactive recalculation.
