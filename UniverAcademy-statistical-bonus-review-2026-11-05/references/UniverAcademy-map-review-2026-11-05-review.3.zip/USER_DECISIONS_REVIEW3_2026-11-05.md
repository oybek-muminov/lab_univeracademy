# Direct user confirmation for review.3

Date:2026-11-05. User message ID: `Sentinel_936e922ad45081918da58fa51f33d892`. Logical source ID: `UA-SRC-REVIEW3-DIRECT-CONFIRMATION-20261105`. This is a new direct confirmation of the exact three questions below. The user's statement that they confirmed them earlier is preserved verbatim; the earlier original messages remain independently unverified. No earlier platform ID or timestamp is invented.

## Exact conversation evidence

Assistant:
Kontraktga kiritishdan oldin bir narsani aniqlashtiraman: auditdagi uchta qoida bo‘yicha asl tasdiq xabarlarini topa olmadim. **Admin Raschni ishga tushirmasligi, tiklangan urinishga eski Rasch natijasi ko‘chirilmasligi va individual baholash dastlab o‘chiq bo‘lishini tasdiqlaysizmi?** Uchalasini birga tasdiqlashingiz yoki o‘zgartiriladiganini aytishingiz mumkin.

User:
yuqoridagilarni tasdiqlayman. ularni oldingi hujjaatda ham rasdiqlaganman

## Confirmed scope

1. Admin does not activate Rasch. Existing Teacher own-group/subject action and Owner rights remain unchanged. No new delegated Admin activation capability is introduced.
2. A restored/recovery attempt does not inherit the old Rasch result. This does not grant new recovery rights or determine every recovery implementation detail. Existing immutable frozen-run/one-shot rules remain; the successor's ordinary result follows the already confirmed ordinary lifecycle. No old Rasch is relabeled as its result.
3. Individual grading is initially off for a new test. This is the initial UI/configuration choice, not permission to omit the existing required API boolean, modify existing tests, or choose a rounding/storage policy.

The user did not approve this API implementation, numeric profile, boundary solver, agent acceptance, DB/migration/deployment, new reset/recompute or broad future policy. Those gates remain separate. The supplied audit decision file remains unchanged under source/review2-independent-audit/ and is not relabeled as authenticated history.
