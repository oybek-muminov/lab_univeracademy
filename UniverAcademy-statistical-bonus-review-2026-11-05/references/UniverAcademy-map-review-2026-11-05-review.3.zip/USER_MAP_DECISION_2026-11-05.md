# U7 — MAP tanlandi, teng natijadagi holat tasdiqlandi

Mantiqiy manba ID: `UA-SRC-MAP-CONFIRMATION-20261105`. Sana **2026-11-05, Asia/Tashkent**. Platforma message UUIDsi/aniq vaqt taqdim etilmagan; bu ID ular o‘rnida ko‘rsatilmaydi.

Foydalanuvchining asl xabari:

> Unda MAPdan foydalanamiz, maqbul sozlamalarini asoslab tavsiya qil. Hamma bir xil natija olsa, «Rasch darajasini aniqlab bo‘lmadi» deb ko‘rsatamiz. Hujjatlarni shunga moslab yangila.

Tasdiqlangan mahsulot qarorlari:

- Rasch parametrlarini baholashda **MAPdan foydalaniladi**. Oldingi «MAPni tushuntirish kutilmoqda» holati yopildi.
- Rasch uchun hamma bir xil natijada daraja aniqlanmasa, **«Rasch darajasini aniqlab bo‘lmadi»** ko‘rsatiladi. C+/T50 qiymati o‘ylab topilmaydi, ordinary natija saqlanadi.
- Sonli sozlamalar asoslab **tavsiya** qilinsin, hujjatlar yangilansin. Aniq prior SDlari, tolerance, σ convention va optimizer limitlarini userning o‘zi bergan raqamlar deb ko‘rsatmaymiz.

Oldingi tasdiqlar saqlanadi: faqat ordinary va Teacher optional Rasch; bonus bekor; default45 Teacher-editable; faqat valid current self-submitted cohort; unanswered0; expired/forced/cancelled/no-show kirmaydi; barcha started attempt/late admission/ready recovery barrieri saqlanadi; positive fractional ordinary points, display2/full precision; Asia/Tashkent; one logical immutable Rasch run. Bu xabar ilova kodi, production DB/migration/provider/agent holati yoki deploymentni o‘zgartirish topshirig‘i emas.
