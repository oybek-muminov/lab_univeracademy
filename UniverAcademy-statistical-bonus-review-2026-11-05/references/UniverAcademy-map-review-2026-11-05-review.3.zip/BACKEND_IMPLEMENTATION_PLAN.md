> Current review.3: PROVISIONAL / NOT ACCEPTED. Existing earlier sections retain historical design/test context; the appended review.3 section governs changed status. All QA code/test/profile bytes remain unchanged.

# UniverAcademy — Rasch Backend arxitekturasi va implementatsiya rejasi

**2026-11-05, Asia/Tashkent. Taklif; API 0.2.6-map-review.2.** Mahsulot talabi — `UA-SRC-RASCH-USER-20261105` §§1–6. Bu fayl konkret, tekshiriladigan texnik reja; amaldagi backend/baza auditiga yoki bajarilgan implementatsiyaga teng emas. Original ilova kodi, DB, migration va production deploymentga tegilmadi.

## 0. U5/U6 bilan joriy o‘zgarishlar

Faqat ordinary va Teacher ixtiyoridagi Rasch. Yangi test default45 savol, Teacher o‘zgartiradi; numerical engine istalgan configured published countdan foydalanadi,40/45ga hardcode qilmaydi. Ordinary individual points>0, kasr mumkin; display2 kasr, full internal precision. Zona Asia/Tashkent. Raschga faqat current valid submitted, expired/forced/cancelled kirmaydi; barrier esa barcha boshlanganlar tugashini kutadi. U7da MAP va teng natijada exact unavailable xabar tasdiqlandi. Quyidagi exact numerical profile — asoslangan pilot tavsiyasi; oldingi1/2 prior qiymatlari endi historical. Sonli va deployment conformance userning method tasdig‘iga tenglashtirilmaydi.

## 1. Chegara va modullar

```mermaid
flowchart LR
    P[Teacher Panel] --> A[Backend API: auth va session barrier]
    A --> S[O‘zgarmas binary snapshot va run]
    S --> J[Durable job, lease va fencing]
    J --> M[Backend Rasch 1PL numerical module]
    M --> R[Atomik final natija: theta, b, mu, sigma, daraja]
    R --> V[Student safe projection]
    V --> U[Mini App: oddiy natija va Rasch darajasi]
    R --> D[Scoped staff diagnostics]
```

Faqat oddiy va optional Rasch qoladi. Statistical bonus endpoint/schema/data/UI/test vazifalari joriy dizayndan chiqarildi; production ma’lumot o‘chirish yo‘q. Oddiy natijaga Rasch moduli write qilmaydi. Backend yagona API egasi. Rasch uchun yangi xizmat, provider, server yoki public endpoint origin avtomatik yaratilmaydi. Taklif qilingan core language-agnostic; amaldagi Edge/TypeScript backendga mos joylashuvi va CPU/resurs limiti oldin tekshiriladi (R-06). QA reference Python/NumPyda bo‘lishi productionda Python servisi tanlangani degani emas.

## 2. Canonical javob matritsasi

Session server tarafidan `assignment_id` orqali original guruh/demo/pinned versionga bog‘lanadi. Bir sessiya, bir published question set; original identity va row/item UUID tartibi snapshotda muzlatiladi. Tasdiqlangan selection: bir o‘quvchiga bitta valid current submitted urinish. expired/forced/cancelled/ready/in_progress/recovery_lapsed va no-show kiritilmaydi. submitted recovery valid current bo‘lsa bitta final qator sifatida; predecessor ikkinchi qator emas. All-started completion barrieriga excluded urinishlar ham kiradi. Tayyor recovery hamda kechikkan start huquqi tugamasdan snapshot olinmaydi. Zona Asia/Tashkent, protected late-start cutoff keyingi mahalliy kun00:00 exclusive.

`Xij=1` faqat committed answer o‘sha questionning serverda saqlangan correct keyiga teng bo‘lsa; noto‘g‘ri/javobsiz `0`. Hech kirmagan o‘quvchi satri kiritilmaydi; kirib savollarni javobsiz qoldirgan o‘quvchi all-zero qator sifatida qoladi. Barcha published savollar, hamma0/1 ustunlar ham kiritiladi. Option/question UI shuffle emas, stable question ID bilan canonical mapping. Oddiy ball/foiz matrix builder yoki estimatorning argumenti emas.

Input digest canonical UTF-8 serializationda stable original session/version ID, answer-key content digest, sorted row/column identity va binary/unanswered factsni qamraydi. Ball qiymatlari digestga kirmaydi, chunki Raschga aloqasiz; oddiy published-content revision o‘zgarsa xavfsiz pin saqlanadi. Matritsa va correct key student response/logiga chiqarilmaydi. Saqlangan input/key digestni keyin o‘zgartirish yo‘q.

## 3. MAP tasdiqlangan, sonli profil — asoslangan pilot tavsiyasi

Standart 1PL log-odds θ−b parametrizatsiyasi birlamchi [rasch model muallif hujjatida](https://drjoshmcgrane.github.io/rasch/) berilgan. Bu 2PL/3PL yoki vaznlangan foiz emas. Parametr baholash variantlari va penalty masalasi [ETS RR-04-20](https://www.ets.org/research/policy_research_reports/publications/report/2004/hytm.html)da muhokama qilinadi. Bizning quyidagi profilimiz o‘sha manbalardan majburiy default deb olinmagan, loyiha uchun **taklif**.

`ηij=θi−bj`; minimallashtiriladigan negative log-posterior:

`L = Σij [softplus(ηij) − Xij·ηij] + Σi θi²/(2sθ²) + Σj bj²/(2sb²)`

Tavsiya `sθ=1.5`, `sb=2`, `sum(b)=0`. β contrast-koeffitsiyentlari uchun prior SD2; sum-zero shart ostida b_jlar mustaqil emas va marginal variance4(1−1/J). Identifikatsiya uchun orthonormal Helmert contrasts `b=Qβ`, `QᵀQ=I`, `1ᵀQ=0`; penalty proper Gaussian priorni ifodalaydi. Barcha qatnashchi va savol uchun finite MAP, ekstremal qator/ustunlarni tashlab yuborish yo‘q. Oddiy MLEda perfect/zero qiymatlar muammo berishi birlamchi [Wright — extreme scores](https://www.rasch.org/rmt/rmt122h.htm) manbasida qayd etilgan; prior qo‘llash user ruxsat bergan usullardan biri.

Hisob double precision, stable sigmoid; `softplus(η)=max(η,0)+log1p(exp(-abs(η)))` yoki teng barqaror funksiya. `log(sigmoid(η))`ni naiv hisoblash katta |η|da aniqlikni yo‘qotishi [SciPy log_expit hujjatida](https://docs.scipy.org/doc/scipy/reference/generated/scipy.special.log_expit.html) ko‘rsatilgan. Ushbu manba backend uchun SciPy dependency tanlamaydi.

Analytic gradient: `gθi=Σj(Pij−Xij)+θi/sθ²`; `gbj=−Σi(Pij−Xij)+bj/sb²`; βgradient `Qᵀgb`. `W=P(1−P)`; θ Hessian diagonal `ΣjW+1/sθ²`, b diagonal `ΣiW+1/sb²`, cross `−W`, βga Q orqali transformatsiya. Positive proper priors bilan constrained parametr fazosida Hessian SPD; bu bizning objective bo‘yicha matematik xulosa. Newton linear solve, explicit matrix inverse emas; Armijo line search stepni kamaytiradi.

Candidate boshlanish θ=β=0, `max|gradient|≤1e−7`, max200 iteration, Armijo1e−4/max50 backtracks. Hech convergence bo‘lmaganida eski qiymatni completed deb publish qilmaslik. Gershgorin/ridge yoki boshqa optimizerga yashirin fallback yo‘q; production profilingdan keyin yangi approved profile versiyasi bilan tanlash kerak. R-01ning MAP tanlash savoli U7 bilan yopildi. Exact profile version/SHA va Backend deployment/conformance hali alohida texnik review; `RASCH_POLICY_UNRESOLVED` endi «MAP izoh kutilmoqda» uchun emas, haqiqiy deploy qilingan profil yo‘qligi uchun ishlatilishi mumkin. Saqlanadigan profile ID+SHA256, tolerances, priors, identification, optimizer/library/code version va diagnostics natijani qayta tekshirishga imkon beradi, lekin qayta hisoblab overwrite qilish endpointi yo‘q.

**1PLga xos qabul sharti:** bir xil barcha savollar to‘plamida bir xil unweighted correct count va bir xil priorga ega o‘quvchilar θsi teng bo‘ladi. To‘g‘ri javoblar qaysi savolda joylashgani θga alohida qo‘l vazni bermaydi; b calibration esa to‘liq matritsadan olinadi. Bunga [Wright — raw score sufficiency](https://www.rasch.org/rmt/rmt32e.htm) asos beradi. «Qiyin savolni topgani uchun shu raw totaldagi o‘quvchiga kattaroq θ»ni majburlash bu model uchun acceptance emas.

## 4. Z/T, darajalar va matematik chekkalar

Yakuniy finite θlardan o‘sha cohortning `μ=Σθ/N`; taklif `σ=sqrt(Σ(θ−μ)²/N)` population (`ddof=0`). N va N−1 farqi [NumPy std hujjatida](https://numpy.org/doc/stable/reference/generated/numpy.std.html) aniq berilgan; biz ddof0ni frozen to‘liq cohortni o‘z ichida standartlash uchun tavsiya qildik; bu userning literal sonli tanlovi emas. `Z=(θ−μ)/σ`, `T=50+10Z` — user talabi. μ,σ,N,ddof,sigma_floor va scheme/profile saqlanadi.

| T oralig‘i | Daraja |
|---|---|
| T ≥ 70 | A+ |
| 65 ≤ T < 70 | A |
| 60 ≤ T < 65 | B+ |
| 55 ≤ T < 60 | B |
| 50 ≤ T < 55 | C+ |
| 46 ≤ T < 50 | C |
| T < 46 | `null` — daraja belgilanmaydi |

Darajani displayga yaxlitlashdan **oldin** unrounded finite T bilan solishtirish; 69,9999 A+, 45,9999 C qilib yuborilmaydi. Tni 0..100ga clamp qilish yo‘q. Studentga faqat daraja/status, latent raqamlar yo‘q.

| Chekka | Taklif qilingan ishlov | Saqlanadigan/ko‘rinadigan holat |
|---|---|---|
| Hamma0 yoki hamma1, ayrim extreme person/item | MAP finite; savol va odamlar tushirib qoldirilmaydi | Finite θ/b va diagnostics; σ0 bo‘lsa quyidagi holat |
| Bir xil raw total, identical rows yoki N1; σ≤1e−8 | Z/Tga bo‘lish bajarilmaydi, σni εga almashtirib level yaratilmaydi | `not_estimable`, sabab, μ/σ/finite θ/b; Z/T/level null |
| N0 — hech kim kirmagan | Estimatorni chaqirmasdan typed outcome | `not_estimable/EMPTY_COHORT`, μ/σ null, person rows0 |
| Published question0 yoki noto‘g‘ri input/key version | Publish/preflight/snapshot validationda rad | Valid oddiy o‘zgarmaydi; reserved run bo‘lsa failed typed reason |
| Nonconvergence / line search / nonfinite | Partial parametr yoki NaN/Infinity publish qilinmaydi | `failed`, xavfsiz reason, null level; oldingi hisoblarga ta’sir yo‘q |
| Juda katta abs(η) | Stable functions, finite objective/gradient tekshiruvi | Overflow/crash yo‘q |
| T aynan46/50/55/60/65/70 | Inclusive lower/exclusive upper user qoidasi | C/C+/B/B+/A/A+ |

U7 bilan σ0/teng Rasch natijada «Rasch darajasini aniqlab bo‘lmadi» ko‘rsatish tasdiqlandi. Z/T/level null, ordinary saqlanadi. Equal raw-total guard va sigma≤1e−8 floor texnik tavsiya. Empty/no convergence outcome oldingidek alohida reason bilan, fake C+ yo‘q. 30 kishilik sintetik testdan o‘tish haqiqiy testning bir o‘lchovlilik/local independence/model fitini yoki rasmiy Milliy sertifikat bilan tenglikni isbotlamaydi. Bu loyiha talabi bo‘yicha guruh ichidagi standartlashtirish; bir nechta guruhni aralashtirish/equating qo‘shilmaydi.

Core failure mapping: `LINE_SEARCH_FAILED` yoki linear solve xatosi → staff `NUMERICAL_FAILURE`; invalid matrix/key snapshot → `INVALID_INPUT_SNAPSHOT`; maxiter → `NONCONVERGENCE`; nofinite → `NONFINITE_OPTIMIZATION`. Pupilga bu ichki xabar/trace chiqmaydi, faqat `CALCULATION_UNAVAILABLE`. Wrapper barcha kutilgan numerical exceptionlarni typed final outcomega aylantiradi, partial natija yo‘q. Bu mapping implementatsiya talabi, hozir API ishlatilmagan.

Qo‘shimcha talab: bir xil raw total (same complete question set + same prior) barcha θning matematik tengligini bildiradi; buni floating-point noise sababli fake Z/Tga aylantirmaslik uchun explicit guard kerak. Student `not_estimable` projectiondan **«Rasch darajasini aniqlab bo‘lmadi»**ni render qiladi. Weighted ordinary score tengligi shu guard uchun asos emas. Core/HTTP statuslari va existing closed pupil DTO o‘zgarmaydi.

## 5. Atomik run, job va o‘zgarmas natija

1. API current Teacher/Owner auth+scope va haqiqiy vaqtni tekshiradi; client boshqaradigan ro‘l/matrix/profilega ishonmaydi.
2. Current auth/scope tasdiqlangach, start/recovery bilan bir xil canonical session lock tartibida avval mavjud logical run qidiriladi. Mavjud bo‘lsa same/different K uchun ayni in-flight202 yoki terminal200 run qaytariladi; keyingi admission/recovery holati existing-run receiptni yangi activation sifatida rad etmaydi va snapshotni yangilamaydi. Faqat run yo‘qligida late-start cutoff, barcha boshlangan urinishlar tugashi, existing ready recovery va approved profile barrierlari tekshiriladi; shundan keyin eligible snapshot yaratiladi. Current authorization har replayda saqlanadi. Bu tartib runtime sinovidan hali o‘tmagan texnik taklif.
3. Bitta tranzaksiyada canonical response snapshot, unique run, approved profile hash va outbox/job yoziladi. Idempotency ledger faqat o‘zi yetmaydi; DB unique original session+model_family bo‘lishi shart. Uniquenessga `profile_id` yoki Kni qo‘shib ikkinchi hisobga yo‘l ochilmaydi.
4. Worker lease+monotonic fencing token bilan shu nonterminal runni oladi; snapshot/hash/profilni tekshiradi, ordinary yozuvlarini read-only hamda no-write chegarasida qoldiradi.
5. Hisob tashqarida bajariladi; yakunda fence+run state+input hash yana tekshiriladi. Barcha person/item/norm/output va terminal status **bitta atomik commit**, yarim natija ko‘rinmaydi.
6. Worker crash/tarmoq xatosida faqat o‘sha nonterminal run qayta davom ettirilishi mumkin; eski worker publish qila olmaydi. Matematik terminal failed/not_estimable ham final hisob qaydi va Teacherga reset/retry yangi run yo‘qligi — ushbu rejadagi failure-policy taklifi, alohida yangi user numeric qarori emas; MR2-D05 reviewda. Mavjud immutable natijani qayta hisoblashga bu paket ruxsat bermaydi. Infrastructure retry fizik hisobni qayta bajarishi mumkin, ikki saqlangan natijani yaratmaydi.
7. Final run/input/profile/resultlar update/deletega yopiq; yangi qatnashchi, boshqa guruh, keyingi javob/profile/recovery uni o‘zgartirmaydi. Mavjud qatorlar orqali app/worker/RPC mutation yuzasi va DB guard/RLS bilan tekshirish zarur. Bu holat hozir amalda o‘rnatilmadi.

## 6. Ma’lumotlar bazasi maydonlari — konseptual sxema, migration emas

Amaldagi physical jadval/column nomlari tekshirilmagan. Quyidagilar internal taklif; mavjud `qadam_private`/DB namingga keyin moslanadi. Studentga raw table grant berilmaydi. Existing ordinary jadvallarini rename/backfill/delete qilish kerak emas.

| Modul/jadval taklifi | Maydonlar va SQL turlari | Kalit/cheklov va maqsad |
|---|---|---|
| `rasch_profiles` | `id text`, `version text`, `sha256 char(64)`, `config jsonb`, `method_source_id text`, `numeric_recommendation_status text`, `approval_status text`, `approved_at timestamptz null`, `code_version text` | PK id+version; approved config immutable; priors/optimizer/tolerance/σ convention/level scheme hammasi versioned; R-01/02 review |
| `rasch_runs` | `id uuid`, `assignment_id/group_id/demo_id/version_id uuid`, `model_family text`, `status text`, `profile_id/version text`, `profile_sha256/input_sha256 char(64)`, `participant_count/question_count int`, `created_at/completed_at timestamptz`, `requested_by uuid`, `reason_code text null`, `output_sha256 char(64) null` | PK id; UNIQUE canonical session identity+model_family; FK pinned source; count≥0, question≥1; attribution immutable; terminal transition once |
| `rasch_participant_inputs` | `run_id/student_id/attempt_id uuid`, `row_index int`, `original_group_id uuid`, `attempt_generation int`, `committed_answer_digest char(64)` | PK run+student; UNIQUE run+row_index; bir eligible attempt, no no-show/duplicate/cancelled predecessor double counting; R-03 |
| `rasch_response_inputs` | `run_id/student_id/question_id uuid`, `column_index int`, `x smallint`, `was_unanswered boolean`, `answer_key_version_digest char(64)` | PK run+student+question; x IN(0,1); unanswered implies x0; immutable full rectangular matrix/digest, no teacher points |
| `rasch_norms` | `run_id uuid`, `mu/sigma double precision null`, `sigma_ddof int`, `sigma_floor double precision`, `level_scheme_id text`, `standardization_status text` | PK/FK run; saved actual μ/σ; finite-or-null, sigma≥0; undefined norm -> null Z/T/level, no NaN/Infinity |
| `rasch_person_results` | `run_id/student_id/attempt_id uuid`, `theta/z/t double precision null`, `level text null`, `result_status/reason_code text null` | PK run+student; level IN A+,A,B+,B,C+,C or null; original attempt attribution; θ/b internal only; unrounded T and derived level consistency guard |
| `rasch_item_results` | `run_id/question_id uuid`, `difficulty_b double precision null`, `correct_count/unanswered_count/participant_count int` | PK run+question; finite-or-null b; all published questions retained; counts and cohort equality guard |
| `rasch_fit_diagnostics` | `run_id uuid`, `optimizer_iterations int`, `gradient_inf/objective double precision null`, `converged boolean`, `library_version/code_version text` | PK run; no fake converged on maxiter; final metadata immutable; staff-only safe view |
| Existing durable jobs yoki `rasch_jobs` | `run_id uuid`, `state text`, `lease_until timestamptz null`, `fence_token bigint`, `attempt_count int`, `last_infrastructure_error text null` | UNIQUE run_id; transactional enqueue, fencing; retry faqat nonterminal same run. Yangi alohida cloud service avtomatik emas |

[PostgreSQL numeric types rasmiy hujjatiga](https://www.postgresql.org/docs/current/datatype-numeric.html#DATATYPE-FLOAT) ko‘ra `double precision` NaN/Infinityni saqlay olishi sababli faqat `NOT NULL` yetarli emas; approved implementation explicit finite checks qo‘yishi kerak. Internal profile/run config user requestdan to‘g‘ridan yozilmaydi. Staff role universal DB table access degani emas; API original group scope projection; student security-definer view/RPC bo‘lsa faqat verified own person_iddan safe result, current sessions/ownership tekshiruvi. Service credentials front-endga chiqmaydi.

## 7. Har modul uchun API, data, qabul mezoni va sinov

| Modul | API/chegara | Saqlanadigan maydonlar | Qabul mezoni | Sinovlar |
|---|---|---|---|---|
| Backend matrix builder | POST Rasch ichki snapshot | participant_inputs, response_inputs, input_sha256, original IDs | 30×M, no-show0 rows, unanswered0, every question, same session only, stable IDs | M01–M08, I01–I04 |
| Backend estimator | Frozen X + approved profile → θ,b,fit | profile, item/person params, diagnostics | 1PL/MAP finite extremes, sum b0, convergence, weight independence | N01–N10 |
| Backend normalization | θ → μ,σ,Z,T,level | norms, person_results, scheme | Exact user cutoffs, stored μ/σ, no clamp/rounding shift, typed degenerate | S01–S08 |
| Backend orchestration/API | GET/POST `/rasch`, GET diagnostics | run/jobs/idempotency/fence/status | Same/different K one logical run, atomic final, current scope, 202/200 | I01–I10, A01–A06 |
| Panel | GET readiness, POST Teacher button, poll GET | Faqat transient run/status UI, norm/score source Backend | Button disabled until actual late cutoff/completion; no auto-run, no double submit/new run; failed/undefined clear | P01–P06 |
| Mini App | Existing own result `.rasch` | Own safe result projection, no yangi client authoritative score | Oddiy ball/maks/foiz unchanged, Rasch level/status separate, no latent/peer | U01–U06 |
| QA | Fixture+reference+future API/DB tests | input hashes/fixture versions/test artifacts | 30 rows reproducible, boundary outcomes, parity/isolation/no duplicate | All; local subset below, DB/API pending |

Har rowning aniq case ssenariysi `QA_ACCEPTANCE_MATRIX.md`da. Future TypeScript/Deno core shu input/profile bilan offline reference θ,b/Z/Tga taklif qilingan abs tolerance1e−6 ichida mos bo‘lishi kerak; unrounded cutoff edge fixtures direct exact classify bilan tekshiriladi, yaqin cutoff uchun klassifikatsiya farqi yashirilmaydi. Parity tolerance ham technical review, official calibration accuracy emas.

## 8. Implementatsiya ketma-ketligi va tekshiruv darvozalari

| Bosqich | Aniq natija | Yakun sharti |
|---|---|---|
| 1. Contract review | Full JSON+MD, R-01–06, ikki hisob mosligi | MAP/degenerate user qarori bor; recommended profile va Backend/Panel/Mini/QA exact-byte review |
| 2. Local implementation | Mavjud backend stackda isolated Rasch core va matrix builder | Offline QA parity, no ordinary write, finite/convergence tests |
| 3. Local DB design | Existing schema inventari, draft migration/guards/RLS/job plan | Development/test DBda unique/fencing/atomic/no-update va rollback sinovi; productionga qo‘llanmaydi |
| 4. API/job staging | Auth+barrier+K+job orchestration, runtime resource benchmark | Actual parallel/replay/recovery races, timeout/failure outcomes, target30 no SLA taxmini |
| 5. UI staging | Panel optional button/status, Mini App safe level | Late entrant/timezone/full duration and own-scope/empty/failure UX |
| 6. Acceptance | 30 o‘quvchilik fixture+chekka tests va final packet | Exact code/schema/profile/input/output hashes va tegishli agent review |
| 7. Production | Alohida aniq deployment/migration rejasi | Faqat foydalanuvchining keyingi ruxsati bilan; bu paket ruxsat emas |

Ishlatilayotgan real DBga migration yozilmadi yoki qo‘llanmadi, provider/deploy o‘zgarmadi. Bu ishdagi Python/NumPy oracle faqat review QA materiali. Tashqi live backend, haqiqiy transaction/RLS/job API yoki 30 real pupil pilot testlari NOT_RUN.

## 9. Joriy ochiq tanlovlar

- MAP va zero-variance UX U7 bilan yopilgan. Tavsiya profilining Backend conformance va actual-data validatsiyasi hali yo‘q; bu oldingi method qarorini qayta ochmaydi.
- Teacher own-group optional Rasch aniq; Admin Rasch mutation delegation va no-body/job/backend runtime mexanikasi review.
- Self-submitted-only aniq; kelajakdagi post-run recovery/tuza­tish oqimi muzlatilgan natijani o‘zgartirmasdan kelishilishi kerak.
- Ordinary points>0/display2 va Asia/Tashkent aniq; midpoint rounding/storage bounds, individual toggle initial state va haqiqiy demo config hali yo‘q.
- Statistical bonus funksiyasi bekor: uning maxraj/ogohlantirish/bonus vakolat savollari joriy blocker emas.

## 10. Tavsiya asoslari va yangi QA

`RASCH_MAP_PROFILE_RECOMMENDED.json` — recommended technical numeric baseline, user-confirmed method/displaydan alohida. `MAP_SETTINGS_RECOMMENDATION.md` prior1.5/2, populationσ, gradient1e−7 asosini va60 distinct matrix/360fit natijalarini beradi. Sonli sozlamalar shu sessiyada natijani chiroyli qilish uchun o‘zgartirilmaydi; yangi profil faqat keyingi, hali hisoblanmagan sessiyaga tegishli bo‘lishi mumkin, eski run mutate bo‘lmaydi. Future hierarchy/real-data calibration yangi profile reviewi, avtomatik per-group tuning emas.

## 11. Historical review.2 acceptance qo‘shimchalari — current status §12da

**MR2-N01:** `evidence/INDEPENDENT-RASCH-NUMERICS.json`da 5×12 question permutation original oracle A/A+ farqini beradi. Parametr1e−6 parityning o‘zi yetarli emas. Barcha cutofflarda end-to-end fit/normalization/level invariance, stable identity alignment, exact categorical agreement va reviewed near-boundary handling talab qilinadi. Bir xil mathematical input reorderi darajani o‘zgartirmasligi kerak. Float-error handlingni Backend tanlaydi; user cutofflari/no display rounding saqlanadi. Oracle/test/profile bu paketda unchanged.

**MR2-C02/C03, historical review.2:** O‘sha OpenAPI invalid status/reason va contradictory readinessni rad etmagan. Review.3 tuzatishi §12da. `REVIEW_FINDINGS_AND_DECISIONS.md`dagi negative fixturesni yangi Backend schema/server testsga qo‘shish taklif qilinadi. Backend reviewidan oldin paths/components o‘zgartirilmadi.

**MR2-D02:** Recovery lock/replay tartibi va queued/running/terminal snapshotlarga ta’sir alohida hal qilinsin. Original immutable receipt saqlanadi. Predecessor/successor history/result/export/diagnostics projection taklifi hali product approval emas, mavjud recovery huquqini avtomatik bloklamaydi.

**MR2-D03:** Ordinary decimal arithmetic/storage/percentage precision alohida reja; Rasch Float64ni ordinaryga o‘tkazmang. Decimal half-up2 final display tavsiyasi hali tasdiqlanmagan. Yangi point cap/scale/wire turini ushbu hujjatdan infer qilmang.

API egasi Backend; qabul yozuvlari `AGENT_REVIEW_TABLE.md`da. Original evidence va yangi reproduksiyalar `VALIDATION-RESULTS.json`da ajratilgan. Runtime/migration/provider/deploy ruxsati berilmagan.


## 12. Review.3 corrections, not implementation

The OpenAPI draft now separates not_estimable and failed reasons and constrains true readiness. The plan §5 replay order is reflected in POST: current auth/scope, canonical lock, existing run receipt, then only absent-run activation gates. API owner Backend must review these exact bytes; no server code or migration ran.

Numerical conformance remains blocked. Follow NUMERICAL_BOUNDARY_RECOMMENDATION.md for proposed exact structural two-score proof plus certified enclosures/precision escalation and equality limitations. Do not edit cutoffs, floor, profile, oracle or tests in this documentation task. Do not treat small parameter error or successful schema checks as grade correctness. The original five-row replay is environment-dependent; the attached independent seed9 30×45 counterexample is separate evidence.

MR2-D01/D02/D04 now have direct user confirmation Sentinel_936e922ad45081918da58fa51f33d892: Admin cannot activate; restored attempt cannot inherit old Rasch; new-test individual initially off. Preserve Teacher/Owner scope, existing recovery authority, immutable old snapshot and required API boolean. See RECOVERY_AND_UI_CONFORMANCE.md. Runtime tests remain NOT_RUN. Decimal amount arithmetic and a specified rational percentage/storage strategy are technical recommendations, not a decided midpoint rounding rule or new wire type. Terminal numerical failure policy needs explicit review; no reset/recompute capability is added. New numerical implementation/test scope, production and all exact-byte owners' acceptance remain separate gates.
