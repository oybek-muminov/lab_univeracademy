"""Synthetic sensitivity experiment for documentation only; no production data/API."""
from pathlib import Path
import copy,hashlib,json,sys,time
import numpy as np

if Path(__file__).resolve().parent.name=='QA':
    QA=Path(__file__).resolve().parent
    OUT=QA.parent
    ROOT=OUT.parent
else:
    ROOT=Path(__file__).resolve().parents[1]
    OUT=ROOT/'UniverAcademy-map-review-2026-11-05'
    QA=OUT/'QA'
QA.mkdir(parents=True,exist_ok=True)
if (QA/'rasch_reference_math.py').exists():sys.path.insert(0,str(QA))
else:sys.path.insert(0,str(ROOT/'UniverAcademy-two-grading-review-2026-11-05'/'QA'))
import rasch_reference_math as m

PROFILES=[('baseline',1.,2.),('tighter_person',.75,2.),('wider_person',1.5,2.),('wide_person',2.,2.),('tighter_item',1.,1.),('wider_item',1.,3.)]
SCENARIOS=[('balanced',0.,1.,1.5),('narrow_ability',0.,.5,1.5),('wide_ability',0.,1.8,1.5),('higher_mean',1.5,1.,1.5),('wide_item_difficulty',0.,1.,2.5)]
def clean(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    raise TypeError(type(v).__name__)
def means(records,key):
    v=[r[key] for r in records if key in r]
    return float(np.mean(v)) if v else None

original=copy.deepcopy(m.PROFILE)
# Candidate numerical convergence tolerance, tested independently of prior variations.
m.PROFILE['gradient_tolerance']=1e-7
started=time.perf_counter();records=[]
for scenario_index,(name,mean,sd,item_sd) in enumerate(SCENARIOS):
    for replicate in range(12):
        seed=2026110500+scenario_index*100+replicate
        rng=np.random.default_rng(seed)
        theta=rng.normal(mean,sd,30);b=rng.normal(0,item_sd,45);b-=b.mean()
        p=m.sigmoid(theta[:,None]-b[None,:]);x=(rng.random(p.shape)<p).astype(int)
        truth=m.standardize(theta)
        fits={}
        for profile_id,ts,bs in PROFILES:
            m.PROFILE.update(theta_prior_sd=ts,item_prior_sd=bs)
            fit=m.fit(x);fits[profile_id]=fit
            row={'scenario':name,'replicate':replicate,'seed':seed,'profile':profile_id,'theta_prior_sd':ts,'item_prior_sd':bs,'status':fit['status'],'reason':fit['reason'],'matrix_sha256':hashlib.sha256(x.astype(np.uint8).tobytes()).hexdigest(),'iterations':fit.get('iterations'),'gradient_inf':fit.get('gradient_inf')}
            if fit['status']=='completed':
                pp=m.sigmoid(fit['theta'][:,None]-fit['b'][None,:])
                row.update(theta_rmse=float(np.sqrt(np.mean((fit['theta']-theta)**2))),item_rmse=float(np.sqrt(np.mean((fit['b']-b)**2))),probability_rmse=float(np.sqrt(np.mean((pp-p)**2))),t_rmse_vs_simulated_truth=float(np.sqrt(np.mean((fit['standardization']['t']-truth['t'])**2))),level_disagreements_vs_simulated_truth=sum(a!=b for a,b in zip(fit['standardization']['levels'],truth['levels'])))
            records.append(row)
        base=fits['baseline']
        if base['status']=='completed':
            for row in records[-len(PROFILES):]:
                fit=fits[row['profile']]
                if fit['status']=='completed':
                    row['level_changes_vs_baseline']=sum(a!=b for a,b in zip(fit['standardization']['levels'],base['standardization']['levels']))
                    row['max_abs_t_shift_vs_baseline']=float(np.max(np.abs(fit['standardization']['t']-base['standardization']['t'])))
        recommended=fits['wider_person']
        if recommended['status']=='completed':
            for row in records[-len(PROFILES):]:
                fit=fits[row['profile']]
                if fit['status']=='completed':
                    row['level_changes_vs_recommended']=sum(a!=b for a,b in zip(fit['standardization']['levels'],recommended['standardization']['levels']))
                    row['max_abs_t_shift_vs_recommended']=float(np.max(np.abs(fit['standardization']['t']-recommended['standardization']['t'])))

summary=[]
for pid,ts,bs in PROFILES:
    rows=[r for r in records if r['profile']==pid]
    summary.append({'profile':pid,'theta_prior_sd':ts,'item_prior_sd':bs,'fits':len(rows),'completed':sum(r['status']=='completed' for r in rows),'failed':sum(r['status']=='failed' for r in rows),'not_estimable':sum(r['status']=='not_estimable' for r in rows),'mean_theta_rmse':means(rows,'theta_rmse'),'mean_item_rmse':means(rows,'item_rmse'),'mean_probability_rmse':means(rows,'probability_rmse'),'mean_t_rmse_vs_truth':means(rows,'t_rmse_vs_simulated_truth'),'mean_level_disagreements_vs_truth_per30':means(rows,'level_disagreements_vs_simulated_truth'),'mean_level_changes_vs_baseline_per30':means(rows,'level_changes_vs_baseline'),'max_level_changes_vs_baseline_per30':max((r.get('level_changes_vs_baseline',0) for r in rows),default=0),'max_t_shift_vs_baseline':max((r.get('max_abs_t_shift_vs_baseline',0) for r in rows),default=0),'mean_level_changes_vs_recommended_per30':means(rows,'level_changes_vs_recommended'),'max_level_changes_vs_recommended_per30':max((r.get('level_changes_vs_recommended',0) for r in rows),default=0),'max_t_shift_vs_recommended':max((r.get('max_abs_t_shift_vs_recommended',0) for r in rows),default=0),'max_iterations_observed':max(r.get('iterations',0) for r in rows)})
by_scenario=[]
for name,_,_,_ in SCENARIOS:
    for pid,_,_ in PROFILES:
        rows=[r for r in records if r['scenario']==name and r['profile']==pid]
        by_scenario.append({'scenario':name,'profile':pid,'mean_theta_rmse':means(rows,'theta_rmse'),'mean_item_rmse':means(rows,'item_rmse'),'mean_t_rmse_vs_truth':means(rows,'t_rmse_vs_simulated_truth'),'mean_level_changes_vs_baseline_per30':means(rows,'level_changes_vs_baseline')})
report={'experiment':'UA-RASCH-MAP-SYNTHETIC-SENSITIVITY-v1','date':'2026-11-05','scope':'Synthetic numerical comparison only, no real pupil data or population calibration; not simulation-based calibration of a full posterior. No claim of optimal/official-certified settings.','participants':30,'questions':45,'replicates_per_scenario':12,'distinct_matrices':60,'fits':len(records),'gradient_tolerance':1e-7,'recommended_profile_id':'wider_person','previous_profile_id':'baseline','numpy_version':np.__version__,'summary':summary,'by_scenario':by_scenario,'records':records,'seconds_local_only':time.perf_counter()-started,'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(),'limitations':['Truth distributions selected to probe specific scenarios, not estimated from UniverAcademy data.','No profile uniformly expected to win all possible populations; mean error is not a rule for choosing more attractive certificate labels.','Posterior MAP point estimates do not quantify full parameter uncertainty or certify 1PL fit.','Reference gradients/core are locally tested; real backend/API/DB/jobs/UI/performance remain untested.']}
m.PROFILE.clear();m.PROFILE.update(original)
(QA/'MAP-SENSITIVITY-RESULTS.json').write_text(json.dumps(report,default=clean,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({'fits':len(records),'failed':sum(r['status']=='failed' for r in records),'seconds_local_only':report['seconds_local_only'],'summary':summary},ensure_ascii=True))
