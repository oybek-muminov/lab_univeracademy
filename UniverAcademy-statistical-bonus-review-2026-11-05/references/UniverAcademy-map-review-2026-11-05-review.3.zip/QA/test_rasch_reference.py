"""Executable OFFLINE QA for a recommended profile (method confirmed). No API, DB or production tests."""
from pathlib import Path
import copy
import hashlib
import json
import math
import time
import unittest
import numpy as np
from rasch_reference_math import PROFILE,binary_matrix,classify_t,contrasts,fit,objective_grad_hessian,sigmoid,standardize

HERE=Path(__file__).resolve().parent
FIXTURE=json.loads((HERE/'RASCH_30x45_INPUT.json').read_text(encoding='utf-8'))

def snapshot(fixture):
    # Candidate row-selection policy for offline review only; no actual DB query.
    rows=[];seen_students=set();seen_attempts=set()
    for row in fixture['participants']:
        if not row['started']:continue
        if any(row[k]!=fixture[k] for k in ['group_id','assignment_id','version_id']):
            raise ValueError('FOREIGN_SESSION_ROW')
        if row['status'] in ['expired','forced','cancelled','recovery_lapsed']:continue
        if row['status']!='submitted':raise ValueError('UNRESOLVED_ROW')
        if row['student_id'] in seen_students or row['attempt_id'] in seen_attempts:
            raise ValueError('DUPLICATE_PERSON_OR_ATTEMPT')
        seen_students.add(row['student_id']);seen_attempts.add(row['attempt_id'])
        if len(row['responses'])!=len(fixture['question_ids']):raise ValueError('RAGGED_MATRIX')
        rows.append(row)
    rows.sort(key=lambda r:r['student_id'])
    x=binary_matrix([r['responses'] for r in rows]) if rows else np.empty((0,len(fixture['question_ids'])))
    body={'assignment_id':fixture['assignment_id'],'group_id':fixture['group_id'],'version_id':fixture['version_id'],'rows':[(r['student_id'],r['attempt_id']) for r in rows],'question_ids':fixture['question_ids'],'x':x.tolist(),'unanswered':[[v is None for v in r['responses']] for r in rows]}
    digest=hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return rows,x,digest

def output_json(value):
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,np.generic):return value.item()
    raise TypeError(type(value).__name__)

class RaschReferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows,cls.x,cls.digest=snapshot(FIXTURE)
        cls.result=fit(cls.x)

    def test_M01_30_actual_33_roster(self):self.assertEqual(self.x.shape,(30,45))
    def test_M02_unanswered_zero(self):
        for row,data in zip(self.rows,self.x):
            for raw,val in zip(row['responses'],data):
                if raw is None:self.assertEqual(val,0)
    def test_M03_never_started_absent(self):
        self.assertFalse(any(not r['started'] for r in self.rows))
        self.assertTrue(any(not any(r['responses']) for r in self.rows))
    def test_M04_other_group_not_pooled(self):
        f=copy.deepcopy(FIXTURE);f['participants'][0]['group_id']='other-group'
        with self.assertRaisesRegex(ValueError,'FOREIGN'):snapshot(f)
    def test_M05_other_session_not_pooled(self):
        f=copy.deepcopy(FIXTURE);f['participants'][0]['assignment_id']='other-session'
        with self.assertRaisesRegex(ValueError,'FOREIGN'):snapshot(f)
    def test_M06_duplicate_person_rejected(self):
        f=copy.deepcopy(FIXTURE);f['participants'].append(copy.deepcopy(f['participants'][0]))
        with self.assertRaisesRegex(ValueError,'DUPLICATE'):snapshot(f)
    def test_M07_ragged_rejected(self):
        f=copy.deepcopy(FIXTURE);f['participants'][0]['responses'].pop()
        with self.assertRaisesRegex(ValueError,'RAGGED'):snapshot(f)
    def test_M08_cancelled_predecessor_not_second_row(self):
        f=copy.deepcopy(FIXTURE);f['participants'][0]['status']='cancelled'
        rows,x,_=snapshot(f);self.assertEqual(x.shape,(29,45));self.assertFalse(any(r['status']=='cancelled' for r in rows))
    def test_N01_full_matrix_fit_converges(self):
        self.assertEqual(self.result['status'],'completed')
        self.assertLessEqual(self.result['gradient_inf'],PROFILE['gradient_tolerance'])
        self.assertEqual(len(self.result['b']),45)
    def test_N02_extreme_persons_finite(self):
        self.assertTrue(np.isfinite(self.result['theta']).all())
        self.assertTrue(np.isfinite(self.result['b']).all())
    def test_N03_sum_b_zero(self):self.assertAlmostEqual(float(self.result['b'].sum()),0,places=10)
    def test_N04_ordinary_weights_ignored(self):
        f=copy.deepcopy(FIXTURE);f['ordinary_points_A']=f['ordinary_points_B']
        _,x,digest=snapshot(f)
        np.testing.assert_array_equal(x,self.x);self.assertEqual(digest,self.digest)
        r=fit(x);np.testing.assert_allclose(r['theta'],self.result['theta'],atol=1e-10,rtol=0)
    def test_N05_item_extremes_finite_retained(self):
        x=self.x.copy();x[:,0]=0;x[:,1]=1
        r=fit(x);self.assertIn(r['status'],['completed','not_estimable'])
        self.assertEqual(len(r['b']),45);self.assertTrue(np.isfinite(r['b']).all())
        self.assertGreater(r['b'][0],r['b'][1])
    def test_N06_equal_total_equal_theta(self):
        x=np.array([[1,1,0,0],[0,0,1,1],[1,0,1,0],[0,1,0,1],[0,0,0,0],[1,1,1,1]])
        r=fit(x)
        np.testing.assert_allclose(r['theta'][:4],np.repeat(r['theta'][0],4),atol=1e-10,rtol=0)
    def test_N07_stable_extreme_eta(self):
        with np.errstate(over='raise',invalid='raise'):
            p=sigmoid(np.array([-1000.,0.,1000.]))
            losses=np.logaddexp(0,np.array([-1000.,1000.]))
        self.assertTrue(np.isfinite(p).all());self.assertTrue(np.isfinite(losses).all())
        self.assertEqual(float(p[1]),.5)
    def test_N08_gradient_and_hessian(self):
        x=self.x[:5,:6];q=contrasts(6);a=np.linspace(-.5,.5,10)
        loss,g,h=objective_grad_hessian(a,x,q)
        eps=1e-5
        for k in range(len(a)):
            shift=np.zeros_like(a);shift[k]=eps
            lp,gp,_=objective_grad_hessian(a+shift,x,q);lm,gm,_=objective_grad_hessian(a-shift,x,q)
            self.assertAlmostEqual(g[k],(lp-lm)/(2*eps),places=7)
            np.testing.assert_allclose(h[:,k],(gp-gm)/(2*eps),atol=1e-7,rtol=0)
        self.assertGreater(float(np.linalg.eigvalsh(h).min()),0)
    def test_N09_nonconvergence_typed(self):
        r=fit(self.x,max_iterations=0)
        self.assertEqual(r['status'],'failed');self.assertEqual(r['reason'],'NONCONVERGENCE')
        self.assertNotIn('theta',r)
    def test_N10_no_nonbinary_or_nan_infinite(self):
        for raw in [[[2,0]],[[float('nan'),1]],[[float('inf'),1]],[[-1,1]]]:
            with self.assertRaises(ValueError):fit(raw)
    def test_S01_group_mu_sigma(self):
        theta=self.result['theta'];norm=self.result['standardization']
        self.assertAlmostEqual(norm['mu'],float(theta.mean()),places=12)
        self.assertAlmostEqual(norm['sigma'],float(theta.std(ddof=0)),places=12)
        self.assertAlmostEqual(float(norm['z'].mean()),0,places=10)
        self.assertAlmostEqual(float(norm['t'].mean()),50,places=10)
    def test_S02_exact_level_boundaries(self):
        for t,l in [(70,'A+'),(65,'A'),(60,'B+'),(55,'B'),(50,'C+'),(46,'C'),(45.999999,None)]:
            with self.subTest(t=t):self.assertEqual(classify_t(t),l)
    def test_S03_no_rounding_over_threshold(self):
        for t,l in [(69.999999999,'A'),(64.999999999,'B+'),(59.999999999,'B'),(54.999999999,'C+'),(49.999999999,'C'),(45.999999999,None)]:
            with self.subTest(t=t):self.assertEqual(classify_t(t),l)
    def test_S04_sigma_zero_no_fake_cplus(self):
        n=standardize([2.,2.,2.]);self.assertEqual(n['status'],'not_estimable')
        self.assertIsNone(n['z']);self.assertIsNone(n['t']);self.assertEqual(n['levels'],[None]*3)
    def test_S05_empty_and_one_person(self):
        r=fit(np.empty((0,45)));self.assertEqual(r['reason'],'EMPTY_COHORT')
        r=fit([[0,1,0,1]]);self.assertEqual(r['status'],'not_estimable')
        self.assertTrue(np.isfinite(r['theta']).all());self.assertIsNone(r['standardization']['t'])
    def test_S06_all_zero_all_one_cohort(self):
        for val in [0,1]:
            r=fit(np.full((30,45),val));self.assertEqual(r['status'],'not_estimable')
            self.assertTrue(np.isfinite(r['theta']).all());self.assertTrue(np.isfinite(r['b']).all())
            self.assertTrue(all(v is None for v in r['standardization']['levels']))
    def test_S07_equal_total_cohort_and_negligible_variance(self):
        r=fit(np.tile([1,0],(30,20)));self.assertEqual(r['status'],'not_estimable')
        n=standardize([0,1e-10,-1e-10]);self.assertEqual(n['status'],'not_estimable')
    def test_S08_t_unclamped_and_nonfinite_rejected(self):
        self.assertEqual(classify_t(150),'A+');self.assertIsNone(classify_t(-50))
        with self.assertRaises(ValueError):classify_t(float('nan'))
        with self.assertRaises(ValueError):standardize([float('inf'),1])
    def test_R01_order_permutation_invariance(self):
        r=fit(self.x[::-1,::-1])
        np.testing.assert_allclose(r['theta'][::-1],self.result['theta'],atol=1e-7,rtol=0)
        np.testing.assert_allclose(r['b'][::-1],self.result['b'],atol=1e-7,rtol=0)
    def test_R02_deterministic_and_serializable(self):
        r=fit(self.x)
        np.testing.assert_array_equal(r['theta'],self.result['theta'])
        json.dumps(r,default=output_json,allow_nan=False)
    def test_R03_snapshot_ordinary_not_mutated(self):
        before=json.dumps(FIXTURE,sort_keys=True)
        fit(self.x)
        self.assertEqual(json.dumps(FIXTURE,sort_keys=True),before)
    def test_R04_method_confirmed_profile_recommended(self):
        self.assertEqual(PROFILE['method_approval_status'],'USER_CONFIRMED')
        self.assertEqual(PROFILE['approval_status'],'RECOMMENDED_TECHNICAL_BASELINE')

    def test_M09_expired_and_forced_excluded(self):
        f=copy.deepcopy(FIXTURE);f['participants'][0]['status']='expired';f['participants'][1]['status']='forced'
        rows,x,_=snapshot(f);self.assertEqual(x.shape,(28,45));self.assertTrue(all(r['status']=='submitted' for r in rows))
    def test_M10_no_self_submit_empty_sample(self):
        f=copy.deepcopy(FIXTURE)
        for r in f['participants']:
            if r['started']:r['status']='expired'
        rows,x,_=snapshot(f);self.assertEqual(x.shape,(0,45));self.assertEqual(fit(x)['reason'],'EMPTY_COHORT')
    def test_Q01_teacher_variable_count(self):
        for count in [12,45]:
            r=fit(self.x[:,:count]);self.assertEqual(len(r['b']),count);self.assertTrue(np.isfinite(r['b']).all())

    def test_S09_exact_approved_unavailable_message(self):
        r=fit(np.zeros((30,45)))
        self.assertEqual(r['standardization']['display_message'],'Rasch darajasini aniqlab bo‘lmadi')
        self.assertTrue(all(v is None for v in r['standardization']['levels']))
    def test_S10_equal_totals_different_patterns_unavailable(self):
        x=np.array([np.roll(np.array([1]*20+[0]*25),i) for i in range(30)])
        r=fit(x)
        self.assertEqual(r['status'],'not_estimable')
        self.assertEqual(r['standardization']['display_message'],'Rasch darajasini aniqlab bo‘lmadi')
        self.assertIsNone(r['standardization']['t'])
    def test_S11_equal_weighted_score_different_raw_count_valid(self):
        x=np.array([[1,0,0],[0,1,1]])
        weights=np.array([2,1,1])
        self.assertEqual((x@weights)[0],(x@weights)[1])
        r=fit(x)
        self.assertEqual(r['status'],'completed')
        self.assertIsNone(r['standardization']['display_message'])
    def test_S12_numerical_equal_total_guard(self):
        norm=standardize([0.,1e-7,-1e-7],equal_raw_totals=True)
        self.assertEqual(norm['status'],'not_estimable')
        self.assertIsNone(norm['t'])

class RecordingResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.records=[]
    def addSuccess(self,test):super().addSuccess(test);self.records.append({'test':test.id(),'passed':True})
    def addFailure(self,test,err):super().addFailure(test,err);self.records.append({'test':test.id(),'passed':False})
    def addError(self,test,err):super().addError(test,err);self.records.append({'test':test.id(),'passed':False})

if __name__=='__main__':
    import sys
    started=time.perf_counter()
    run=unittest.TextTestRunner(verbosity=1,resultclass=RecordingResult).run(unittest.defaultTestLoader.loadTestsFromTestCase(RaschReferenceTests))
    rows,x,digest=snapshot(FIXTURE);fitted=fit(x)
    output={'scope':'OFFLINE RECOMMENDED-PROFILE ORACLE ONLY; not app/backend API, DB, jobs or production validation','profile':PROFILE,'matrix_sha256':digest,'participant_count':30,'question_count':45,'row_order':[{'student_id':r['student_id'],'attempt_id':r['attempt_id']} for r in rows],'question_order':FIXTURE['question_ids'],'numpy_version':np.__version__,'fit':fitted}
    (HERE/'REFERENCE-OUTPUT-30x45.json').write_text(json.dumps(output,default=output_json,allow_nan=False,indent=2)+'\n',encoding='utf-8')
    bindings={name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ['test_rasch_reference.py','rasch_reference_math.py','RASCH_30x45_INPUT.json','REFERENCE-OUTPUT-30x45.json']}
    report={'status':'PASS' if run.wasSuccessful() else 'FAIL','tests_run':run.testsRun,'failures':len(run.failures),'errors':len(run.errors),'seconds_local_only':time.perf_counter()-started,'cases':run.records,'matrix_sha256':digest,'file_sha256':bindings,'scope':output['scope'],'not_run':['Actual API calls/auth/privacy','Database/RLS/unique constraints','Parallel Idempotency-Key calls and worker fencing','Panel/Mini App runtime','Production deployment or real pupil pilot']}
    (HERE/'TEST-RESULTS.json').write_text(json.dumps(report,allow_nan=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'tests_run':run.testsRun,'fit_status':fitted['status'],'iterations':fitted.get('iterations'),'gradient_inf':fitted.get('gradient_inf')}))
    sys.exit(0 if run.wasSuccessful() else 1)
