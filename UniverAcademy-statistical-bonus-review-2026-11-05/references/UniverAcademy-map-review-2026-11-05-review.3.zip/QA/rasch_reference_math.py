"""Offline review oracle for a RECOMMENDED Rasch MAP profile; method user-confirmed; never imported by app code.

Only validates mathematics for the contract/implementation proposal. Does not provide
HTTP, DB, auth, jobs, migration, billing or deployment functionality.
"""
import math
import numpy as np

PROFILE = {'id': 'rasch_joint_map_centered_v1', 'version': '1.0.0', 'date': '2026-11-05', 'method': 'joint_map', 'method_approval_status': 'USER_CONFIRMED', 'method_source_id': 'UA-SRC-MAP-CONFIRMATION-20261105', 'approval_status': 'RECOMMENDED_TECHNICAL_BASELINE', 'numerical_values_status': 'ASSISTANT_RECOMMENDATION_NOT_INDIVIDUAL_USER_SPECIFICATION', 'deployment_status': 'NOT_IMPLEMENTED_OR_DEPLOYED', 'theta_prior_sd': 1.5, 'item_prior_sd': 2.0, 'theta_prior_mean': 0.0, 'item_contrast_prior_mean': 0.0, 'identification': 'sum_b_zero_orthonormal_contrasts', 'item_prior_semantics': 'beta~N(0,4I), b=Q*beta, Q^TQ=I and 1^TQ=0; equivalently Gaussian quadratic penalty on zero-sum item vector. Item marginal variance=4*(1-1/J), not independent b_j under constraint.', 'discrimination': 1.0, 'guessing': 0.0, 'optimizer': 'damped_newton_analytic_gradient_hessian_armijo', 'float_precision': 'float64', 'initialization': 'all_zero', 'initial_step': 1.0, 'gradient_tolerance': 1e-07, 'max_iterations': 200, 'armijo': 0.0001, 'max_backtracks': 50, 'sigma_ddof': 0, 'sigma_floor': 1e-08, 'equal_raw_totals_guard': True, 'normalization_population': 'same frozen eligible current self-submitted cohort', 'classification': 'unrounded_T_exact_thresholds_no_clamp', 'degenerate_display_approval_status': 'USER_CONFIRMED', 'unavailable_message': 'Rasch darajasini aniqlab bo‘lmadi', 'display_policy_id': 'rasch_unavailable_uz_v1', 'teacher_tunable': False, 'profile_frozen_per_run': True, 'prior_auto_tuning_per_group': False}

def sigmoid(value):
    x=np.asarray(value,dtype=np.float64)
    e=np.exp(-np.abs(x))
    return np.where(x>=0,1/(1+e),e/(1+e))

def contrasts(m):
    q=np.zeros((m,max(0,m-1)),dtype=np.float64)
    for k in range(1,m):
        den=math.sqrt(k*(k+1))
        q[:k,k-1]=1/den
        q[k,k-1]=-k/den
    return q

def binary_matrix(raw):
    a=np.asarray(raw,dtype=np.float64)
    if a.ndim!=2 or a.shape[1]==0:
        raise ValueError('INVALID_MATRIX_DIMENSIONS')
    # Explicit unanswered=None ->0. Reject arbitrary NaN/infinite values, not silently impute.
    null_mask=np.equal(np.asarray(raw,dtype=object),None)
    a=np.where(null_mask,0,a)
    if not np.isfinite(a).all() or not np.isin(a,[0,1]).all():
        raise ValueError('INVALID_BINARY_VALUE')
    return a

def objective_grad_hessian(params,x,q):
    n,m=x.shape
    theta=params[:n]
    b=q@params[n:]
    eta=theta[:,None]-b[None,:]
    p=sigmoid(eta)
    residual=p-x
    theta_precision=1/PROFILE['theta_prior_sd']**2
    b_precision=1/PROFILE['item_prior_sd']**2
    objective=float(np.sum(np.logaddexp(0,eta)-x*eta)+theta_precision*np.dot(theta,theta)/2+b_precision*np.dot(b,b)/2)
    gradient=np.concatenate([residual.sum(axis=1)+theta_precision*theta,q.T@(-residual.sum(axis=0)+b_precision*b)])
    w=p*(1-p)
    cross=-w@q
    hessian=np.block([[np.diag(w.sum(axis=1)+theta_precision),cross],[cross.T,q.T@((w.sum(axis=0)+b_precision)[:,None]*q)]])
    return objective,gradient,hessian

def classify_t(t):
    if not math.isfinite(float(t)):raise ValueError('NONFINITE_T')
    for cutoff,level in [(70,'A+'),(65,'A'),(60,'B+'),(55,'B'),(50,'C+'),(46,'C')]:
        if t>=cutoff:return level
    return None

def standardize(theta, equal_raw_totals=False):
    theta=np.asarray(theta,dtype=np.float64)
    if not np.isfinite(theta).all():raise ValueError('NONFINITE_THETA')
    if theta.size==0:
        return {'status':'not_estimable','reason':'EMPTY_COHORT','mu':None,'sigma':None,'z':None,'t':None,'levels':[],'display_message':PROFILE['unavailable_message']}
    mu=float(theta.mean())
    sigma=float(np.sqrt(np.mean((theta-mu)**2)))
    if equal_raw_totals or sigma<=PROFILE['sigma_floor']:
        return {'status':'not_estimable','reason':'ZERO_OR_NEGLIGIBLE_VARIANCE','mu':mu,'sigma':sigma,'z':None,'t':None,'levels':[None]*len(theta),'display_message':PROFILE['unavailable_message']}
    z=(theta-mu)/sigma
    t=50+10*z
    return {'status':'completed','reason':None,'mu':mu,'sigma':sigma,'z':z,'t':t,'levels':[classify_t(v) for v in t],'display_message':None}

def fit(raw,max_iterations=None):
    x=binary_matrix(raw)
    n,m=x.shape
    if not n:
        return {'status':'not_estimable','reason':'EMPTY_COHORT','theta':np.array([]),'b':np.array([]),'iterations':0,'gradient_inf':None,'objective':None,'standardization':standardize([])}
    q=contrasts(m)
    params=np.zeros(n+m-1,dtype=np.float64)
    limit=PROFILE['max_iterations'] if max_iterations is None else max_iterations
    for iteration in range(limit+1):
        loss,grad,hess=objective_grad_hessian(params,x,q)
        gnorm=float(np.max(np.abs(grad)))
        if not math.isfinite(loss) or not np.isfinite(grad).all() or not np.isfinite(hess).all():
            return {'status':'failed','reason':'NONFINITE_OPTIMIZATION','iterations':iteration}
        if gnorm<=PROFILE['gradient_tolerance']:
            theta=params[:n].copy();b=q@params[n:]
            totals=x.sum(axis=1)
            std=standardize(theta, equal_raw_totals=bool(np.all(totals==totals[0])))
            return {'status':std['status'],'reason':std['reason'],'theta':theta,'b':b,'iterations':iteration,'gradient_inf':gnorm,'objective':loss,'standardization':std}
        if iteration==limit:break
        direction=np.linalg.solve(hess,-grad)
        slope=float(np.dot(grad,direction))
        alpha=1.0
        for _ in range(PROFILE['max_backtracks']):
            trial=params+alpha*direction
            trial_loss,_,_=objective_grad_hessian(trial,x,q)
            if math.isfinite(trial_loss) and trial_loss<=loss+PROFILE['armijo']*alpha*slope:
                params=trial
                break
            alpha*=0.5
        else:
            return {'status':'failed','reason':'LINE_SEARCH_FAILED','iterations':iteration}
    return {'status':'failed','reason':'NONCONVERGENCE','iterations':limit,'gradient_inf':gnorm}
