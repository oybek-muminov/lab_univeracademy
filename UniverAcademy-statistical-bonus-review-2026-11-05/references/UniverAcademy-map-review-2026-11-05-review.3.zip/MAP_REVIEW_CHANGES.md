# Review.2 → review.3 changes

**Docs/OpenAPI draft only. PROVISIONAL, NOT ACCEPTED.** Backend owns API acceptance.

- RaschRun: not_estimable reasons restricted to EMPTY_COHORT/ZERO_OR_NEGLIGIBLE_VARIANCE; failed reasons restricted to NONCONVERGENCE/NONFINITE_OPTIMIZATION/NUMERICAL_FAILURE/INVALID_INPUT_SNAPSHOT. Other reason/timestamp invariants retained.
- RaschAnalysisStatus: true branch requires all local gates satisfied, empty blockers and no run. False is intentionally not the inverse; runtime auth/profile/live-state checks remain mandatory.
- POST Rasch description matches the already-proposed replay order: current auth, canonical lock/existing run, same receipt, absent-run-only activation gates.
- Numerical design describes exact structural equality plus rigorous error bounds/precision escalation. Original code, tests, numeric profile and cutoffs unchanged; MR2-N01 remains OPEN.
- Audit distinctions preserved: original quoted5×12 flip was not reproduced in that independent environment; seed5 and30×45 seed9 reproduced the same defect. Supplied evidence is not mislabeled as a new local run.
- Direct user confirmation Sentinel_936e922ad45081918da58fa51f33d892 now confirms no Admin activation, no old Rasch inheritance on a restored attempt, and initial individual off. Exact source saved; previous audit claims stay historical. No API/agent acceptance or broader recovery permission inferred.
- 353 local schema payload cases pass (138 accepted,215 rejected), including all3 audit counterexamples. 193 component metaschemas and910 local refs pass. This does not equal full OpenAPI3.1 validation or runtime acceptance.
- Review.2 and independent audit archives/extracts retained byte-for-byte; Master§13/1–127 and root QA/profile unchanged. New source index, diffs, evidence, manifest and checksums document provenance.

Not performed: app/test/oracle/validator changes; DB/migration/provider/GitHub/deploy; external agent-state changes. Not run: full OpenAPI validator on review.3, original135 harness, repaired numerical implementation suite, actual server/auth/RLS/concurrency/UI/pilot.


Fresh local numerical reproduction (unchanged archived oracle): the seed9 30×45 input returned incorrect A for all6 upper-group pupils in all4 tested row/question orders, rather than exact70/A+. Approximate top T ranged69.99999999999993–69.99999999999999. This verifies the wrong-boundary result here, not the audit's particular permutation flip. Seed5 5×12 returned A+ in those4 local orders.18 independent rational below/at/above normalization fixtures were verified separately. Evidence: evidence/NUMERICAL-BOUNDARY-DESIGN-EVIDENCE.json. No corrected implementation was tested.
