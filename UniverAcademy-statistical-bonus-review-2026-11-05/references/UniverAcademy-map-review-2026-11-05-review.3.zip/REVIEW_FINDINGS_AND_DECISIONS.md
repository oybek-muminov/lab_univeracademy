# Review.3 findings and decision provenance

**PROVISIONAL, NOT ACCEPTED.** Backend is sole API owner. This is a document/OpenAPI correction package. Local schema passes do not resolve the numerical defect, implementation gates or owner acceptance.

## Resolved in draft, pending owner and runtime verification

**MR2-C02:** terminal outcome semantics are now enforced in JSON Schema. not_estimable permits EMPTY_COHORT and ZERO_OR_NEGLIGIBLE_VARIANCE only; failed permits the4 numerical/input failure reasons only. queued/running/completed retain null reasons. The terminal timestamp rules remain. All status × reason × timestamp combinations were checked, including the two exact audit contradictions.

**MR2-C03:** can_calculate=true now requires closed admission, completed started attempts, no pending recovery rights, no blockers and run=null. Exhaustive local flag/blocker/run cases passed. False has no converse, so an otherwise locally ready payload may be false due to auth/profile/policy. Real-time authorization, admission, attempts, profile, identity and concurrent transaction checks cannot be proven by JSON Schema.

**MR2-C01:** POST documentation now explicitly reflects current authorization → canonical session lock/existing-run lookup → same receipt → absent-run-only activation checks. The change adds no endpoint, reset, recompute or privilege. Current auth applies to replay; later recovery never makes old receipt replay a new snapshot. Actual replay/lock/race tests are NOT_RUN.

Evidence: evidence/REVIEW3-SCHEMA-VERIFICATION.json. 353 cases,138 expected-valid and215 expected-invalid, all pass. Exact attached audit payloads validate under review.2 and are rejected under review.3. 193 component metaschemas and910 local refs pass. Full OpenAPI3.1 validator is absent locally and NOT_RUN; the audit's full pass belongs to review.2 only.

## MR2-N01 remains a numerical blocker

The attached independent audit did not reproduce the originally quoted5×12 A/A+ flip in its BLAS environment. It did reproduce the same bug with seed5 5×12 and seed9 30×45. The latter has24 pupils with44/45 and6 with45/45: complete equal-prior Rasch implies two abilities a<b; population normalization gives upper Z=√(24/6)=2 and exact T70/A+. Its original order produced69.99999999999997/A, reversed order70/A+. This source evidence is preserved unchanged; it is not a corrected-solver run.

NUMERICAL_BOUNDARY_RECOMMENDATION.md provides a proposed exact structural fallback plus certified error-bound/precision-escalation design. It includes equality limitations, genuine near-boundary cases and all cutoffs46/50/55/60/65/70. Sorting, display rounding, arbitrary epsilon and merely tightening optimizer tolerance do not close this issue. No existing oracle/test/profile code or value was changed. Backend/reference categorical parity and permutations are NOT_RUN for any repaired implementation.

## Product decisions: new direct confirmation, narrow scope

Exact user source: USER_DECISIONS_REVIEW3_2026-11-05.md, message Sentinel_936e922ad45081918da58fa51f33d892. The user directly confirms the three bundled policies. Their statement that they already confirmed them earlier is preserved verbatim; the earlier original messages remain independently unverified. The source audit is unchanged.

| ID | Directly confirmed policy | Remaining scope/implementation limits |
|---|---|---|
| MR2-D01 / R-04 | Admin does not activate Rasch | Teacher own-group/subject and Owner existing rights unchanged. Admin read/export does not grant POST or replay. No new capability added; runtime auth tests NOT_RUN. |
| MR2-D02 / R-05 | Restored attempt does not inherit the old Rasch | Frozen old run/history remains immutable under existing rules. Existing recovery authority preserved. Successor ordinary follows prior lifecycle; no broader permanent successor prohibition or new recovery/reset rights inferred. Projection/concurrency tests NOT_RUN. |
| MR2-D04 | Individual grading initially off on a new test | UI sends required boolean explicitly. No server default/omitted-field permission, existing-test reset, midpoint rule or storage scale inferred. UI tests NOT_RUN. |

RECOVERY_AND_UI_CONFORMANCE.md provides the current/result/history/export/diagnostics and Panel/Bot acceptance matrix. Product confirmation is not API implementation, numerical profile, Backend/agent acceptance, migration or deployment approval.

Existing confirmed ordinary + optional Rasch, MAP family, exact unavailable message,45/editable, self-submitted cohort, unanswered0, positive points/display2, Asia/Tashkent, one-shot and removed bonus remain unchanged. Specific joint/centered Gaussian priors and numeric constants remain technical recommendations, not user-specified values.

## Separate unresolved technical choices

**MR2-D03:** recommend decimal amount arithmetic, retained earned/max values and a documented percentage precision/error strategy; round display only once. A binary Float64 implementation must not silently claim exact decimal storage. Half-up versus half-even, scale/caps and decimal-string wire format remain undecided; no schema type or cap is changed.

**MR2-D05:** existing immutable one-shot result grants no reset/new-run retry. Same nonterminal infrastructure retry is distinct from terminal numerical failure policy. Any certification-budget failure mapping is a proposed Backend design and must be reviewed with resource/retry semantics; no new product right is assumed.

## Acceptance and scope

Backend/Bot-Mini App/Panel/QA have no new exact-byte accept/block receipt in this package. Independent local reviewers do not become those project owners. Historical communication failures stay historical; no new send or delivery is claimed.

Master§13 and1–127 are byte-identical. All root QA code/tests/results and profile are unchanged. Full source review.2 and independent audit archives/extracts are included, with hashes. No DB, migration, provider, GitHub, deployment, app/test/oracle/validator code or actual agent state changes occurred. Runtime privacy/auth/RLS/API/jobs/concurrency/UI/recovery/pilot and numerical repaired-core tests are NOT_RUN.


Fresh local numerical reproduction (unchanged archived oracle): the seed9 30×45 input returned incorrect A for all6 upper-group pupils in all4 tested row/question orders, rather than exact70/A+. Approximate top T ranged69.99999999999993–69.99999999999999. This verifies the wrong-boundary result here, not the audit's particular permutation flip. Seed5 5×12 returned A+ in those4 local orders.18 independent rational below/at/above normalization fixtures were verified separately. Evidence: evidence/NUMERICAL-BOUNDARY-DESIGN-EVIDENCE.json. No corrected implementation was tested.
