# Mini App F1 verified local package

F1 P1 is VERIFIED_FIXED for the two exact QA-reviewed file hashes in
qa/INDEPENDENT-QA-STATUS.json. The independent QA verdict was relayed by the
architect in the parent thread. A raw independent retest log is not available
in this environment; the included test logs are explicitly author-local.

This package contains the original 22-file Bot33 source set with exactly two
F1 changes: src/transport.ts and tests/transport.test.mjs. The other 20 source
files are byte-identical to Bot33. The source Markdown documents retain their
historical checkpoint counts; this handoff and the root manifests supersede
those counts for this package. No new source file was introduced.

The common request executor checks auth epoch again after JSON body completion
or parse failure, before returning payloads or changing proof/refresh/retry state.
The existing refresh single-flight and mutation retry policy are preserved.
The 17 new regressions cover streaming responses, parse failures, logout-only,
same-person fresh login, logout plus fresh login, other-person login and mutation
uncertainty/no automatic replay. The full author-local suite is 50/50.

## Offline verification

Run from the extracted root:

    sha256sum -c PACKAGE.sha256
    sha256sum -c source.sha256

With the package.json/package-lock.json dependencies already present, run from
apps/mini-app:

    npm test
    npm run check
    npm run build
    npm run build:demo
    python tests/check-wire-fixtures.py /path/to/pinned-openapi.json

The schema command requires the external Backend-owned provisional OpenAPI bytes
with SHA256 51deb7a41d223559022dcb7e17ff24985bd328e51c4a87c797a02763bb801149.
That contract is not included. The clean local restoration used already installed
environment dependencies; it did not install packages or contact external APIs.

source-manifest.json lists all 22 source files. PACKAGE-MANIFEST.json lists every
payload file except itself and PACKAGE.sha256. PACKAGE.sha256 covers every file
except itself, including PACKAGE-MANIFEST.json. The local companion receipt lists
all final archive members and the archive digest, without a recursive self-hash.

The original QA reproducer and its raw logs are deliberately excluded. No secrets,
real student records, exam answer keys, node_modules, .git, environment files or
generated bundles are packaged. Synthetic fixtures and public technical references
remain. The privacy report records bounded pattern-scan and content-review limits.

The package is local only. The old Bot33 archive/laboratory checkpoint is preserved.
No upload, commit, push, Backend/API change, provider/database change or deployment
is part of this action. Owner generated client, real origin/listener and production
auth/reload integration remain outstanding. Local tests do not prove live readiness.
