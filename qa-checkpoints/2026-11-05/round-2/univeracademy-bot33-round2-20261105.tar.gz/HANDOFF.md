# Wire→UI mapping — lokal QA handoff

33/33 lokal unit test (22 transport/lifecycle + 11 yangi mapping), 27 pinned-draft schema fixture, typecheck va production/demo build PASS. Bular real integratsiya dalili emas. Mapperda endpoint, fetch, parallel wire client yoki Backend ichki importi yo‘q. Manba xeshi Backend bildirilgan provisional nusxaga aynan mos.

Exact source nusxa shu katalogdagi apps/mini-app/ ichida. Barcha 22 source fayl xeshlari source-manifest.json va source.sha256da. Mapping va ochiq bandlar apps/mini-app/WIRE-MAPPING.md; HTTP/loading/error/retry xaritasi apps/mini-app/TRANSPORT-CHECKPOINT.md; test stdoutlari evidence/; maxfiylik tekshiruvi privacy-review.jsonda.

Oldingi 22-testli transport nusxasi alohida: /workspace/shared/mini-app-transport-22-snapshot-20261105/. Uning 17 source fayli oldingi ab5e4fc1d8bcea7e5d2201ac564cb77db43112b787fd2ba52a53617417dc35de manifestiga exact-byte mos qilib tiklandi; faol 33-testli kod o‘zgartirilmadi. Uni bu 33-testli checkpoint bilan aralashtirmang.

22-test bosqichidan keyingi aniq o‘zgarishlar:

- apps/mini-app/README.md (modified)
- apps/mini-app/TRANSPORT-CHECKPOINT.md (modified)
- apps/mini-app/WIRE-MAPPING.md (added)
- apps/mini-app/src/flow.ts (modified)
- apps/mini-app/src/wire-map.ts (added)
- apps/mini-app/tests/check-wire-fixtures.py (added)
- apps/mini-app/tests/fixtures/wire.json (added)
- apps/mini-app/tests/wire-map.test.mjs (added)

To‘siq: generated reviewed client, listener va real origin yo‘q; Backend lokal HTTP adapteri client handoffi emas. Actual auth/reload bootstrap, owner callbacks va real wire-to-UI ulanishi tugallangan deyilmaydi. Media/numeric policy explicit caller callbacklar; production default yaratilmagan.

Yuklash taqiqlangan. Upload/commit/push, database/provider/deploy bajarilmadi. Oldingi upload ruxsati bu checkpointga tatbiq etilmaydi.
