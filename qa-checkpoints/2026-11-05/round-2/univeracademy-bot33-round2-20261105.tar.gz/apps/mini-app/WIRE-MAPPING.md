# Wire → UI mapping va sun’iy fixturelar

Holat: **LOCAL PROJECTION CANDIDATE / PINNED DRAFT / NO LIVE INTEGRATION**. Tasdiqlangan Backend client hali olinmagan. Auth/reload bootstrap, client callbacks va haqiqiy endpointlar ulanmagan; avvalgi 22/22 yoki hozirgi mapping testlari real integratsiya dalili emas. Ushbu bosqichda upload/commit/push, provider/database/deploy yo‘q.

Manba: Backendning `25222f787a4e85eb184efb951fc527698b4c3368` commitidagi Mini App handoffi va OpenAPI `0.2.7-statistical-bonus-review.1`, Git blob `fbef1d67d95bcf217303d2456aa23c9874232b4b`, LF SHA-256 `51deb7a41d223559022dcb7e17ff24985bd328e51c4a87c797a02763bb801149`. PROVISIONAL / NOT ACCEPTED holati saqlangan.

Parentning keyingi xabari Backend lokal student HTTP adapterini tayyorlaganini va ayni draft xeshini bildirdi. Generated client, listener va real origin hali yo‘q; bu client handoffi yoki ishlayotgan integratsiya sifatida olinmadi. Mapperga Backend ichki adapter kodi import qilinmagan.

## Qamrov

`src/wire-map.ts` faqat `unknown` payloadni mavjud UI projectionga o‘giradi. Unda HTTP/fetch, endpoint ro‘yxati, parallel API client, generated wire DTO yoki Backendning ichki kodi yo‘q. To‘liq operation schema validatsiyasi kelajakdagi owner clientida qoladi; mapper faqat xavfsiz ko‘rsatish uchun kerakli maydon/scope/current-generation izchilligini tekshiradi. Maydonlar allowlist bilan olinadi; noma’lum staff/auth/key maydonlari UIga ko‘chirilmaydi. Bu malicious server promptida kalit matni yo‘qligini tekshiradigan mexanizm emas.

| Backend payload | UI projection | Muhim chegara |
|---|---|---|
| Profile | Student | person_id va leading-zero qadam_id saqlanadi. registration_complete isimdan hisoblanmaydi; roles authorization manbasi emas. Token/staff maydonlari ko‘chmaydi. |
| Meta | Exam va SeriesView | assignment ID konteksti tekshiriladi; instructions saqlanadi. Meta’da `group_name`/`can_start` yo‘q: group label va startAllowed caller kontekstidan kelishi kerak. Mapper admission yoki recovery huquqini o‘zi chiqarmaydi. |
| Attempt | Attempt va savollar/javoblar | expected assignment/attempt tekshiriladi. Faqat current in_progress savollari olinadi; active id/generation Series bilan mos bo‘lishi kerak. Yetti lifecycle alohida; terminal/ready kontenti bo‘sh. |
| ActiveQuestion/ActiveOption/OutputBlock | Question va DisplayBlock | Server bergan display_position bo‘yicha tartib; random reshuffle yo‘q. Text/formula/image, alt/caption, expiry saqlanadi. Image URL faqat caller bergan media policy orqali o‘tadi, mapper rasmni yuklamaydi. |
| Answer | SavedAnswer | expected question ID, revision>=1 va JSON null clear saqlanadi. Active javob tanlovi ayni savol optioniga tegishli bo‘lishi tekshiriladi. ACK projectioni saqlash so‘rovi yoki durable commit emas. |
| AttemptGradingResult | Result yoki null | ordinary:null nolga aylantirilmaydi. Nullable bonus alohida, oddiy ball/foizga qo‘shilmaydi. expected attempt ID tekshiriladi. Ordinary result review ruxsati bermaydi. |
| History | Assignmentga tegishli HistoryEntry[] | Title/assignment caller kontekstidan. Bekor qilingan predecessor ball/bonusi tarixiy va rasmiy emas; successor natijani meros olmaydi. Score:null entryda attempt ID yo‘q, mapper ID ixtiro qilmaydi. Rasmiy natija pointeri saqlanadi. |

Rounding/midpoint va media URL siyosati tasdiqlanmagani uchun `formatNumber` hamda `assetUrl` majburiy caller callbacklar. Production default yo‘q. Testdagi toFixed faqat 1.5, 2, 75, 2.25 kabi non-midpoint fixture sonlari uchun; u yangi mahsulot yoki numeric policy tasdig‘i emas.

DisplayBlock strukturasi UI modeliga qo‘shildi. Mavjud demo hali oddiy prompt/option text ko‘rsatadi; rich-content renderer va haqiqiy private media yangilash integratsiyasi bu bosqichda ulanmagan. Mapper to‘g‘ri javob, ichki reason yoki peer ma’lumotni so‘ramaydi.

## Fixturelar va tekshiruv

`tests/fixtures/wire.json` — 27 ta sun’iy case: Profile, Meta, yetti Attempt holati, cancelled→successor pointeri, save/clear ACK, ordinary/nullable bonus/result, original attributionli History va mavjud Error kodlari. UUID/ism/rasm/ballar sun’iy. Haqiqiy credential, initData yoki test kaliti yo‘q. Negative unit testdagi synthetic private/key flaglari faqat allowlist tekshiruvining lokal kiritmasi; canonical fixture’da kalit mappingi yo‘q.

```sh
node --test tests/wire-map.test.mjs
python3 tests/check-wire-fixtures.py /path/to/pinned-openapi.json
npm test
npm run check
npm run build
npm run build:demo
```

Python check muhittagi mavjud jsonschema’dan foydalanadi; hech narsa o‘rnatmaydi yoki internetdan olmaydi. U source fayl SHA-256sini tekshirib, keyin actual schema ref va formatlar bilan har bir fixture’ni tekshiradi. OpenAPI repo ichiga ko‘chirilmagan. Noto‘g‘ri source xeshida tekshiruv to‘xtaydi. Schema PASS biznes tranzaksiyasi, auth/scope, server serialization yoki actual API acceptance dalili emas.

Node testlari scope mismatch, eski active generation, ACK clear/revision, nullable ordinary/bonus, server tartibi/deadline, historical cancellation, old bonusni successor kartasiga ko‘chirmaslik, noma’lum maydonlarni chiqarib tashlash va media policy radini tekshiradi. Fixturega moslik va UI mapping alohida tekshiruvlar.

## Backend handoffida yopiladigan bandlar

1. Tasdiqlangan client/xeshni shu projectionga ulash va uning full operation schema validatsiyasi.
2. Meta’da bo‘lmagan group label va startAllowed uchun mavjud reviewed manba; yangi wire maydon yoki endpoint o‘ylab topilmaydi.
3. History score:null entrylarda attempt_id yo‘qligi sabab UI synthetic ID yaratmaydi; kerakli UX owner bilan kelishiladi.
4. Number formatter/midpoint va approved media URL/expiry siyosati; rich renderer integratsiyasi.
5. Haqiqiy auth/reload bootstrap, scoped journal storage, fresh launch/refresh family va real server E2E. Bular tugallangan deb belgilanmagan.

Mavjud screen→HTTP/loading/error/retry xaritasi: `TRANSPORT-CHECKPOINT.md`. Yangi dalillar `/workspace/shared/mini-app-wire-map-20261105/`da lokal tayyorlanadi; nashr uchun alohida ruxsat kerak.
