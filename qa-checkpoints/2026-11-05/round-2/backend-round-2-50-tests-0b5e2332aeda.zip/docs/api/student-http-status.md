# Bitta o‘quvchi HTTP oqimi — tayyor/pending

2026-11-05. API egasi: Backend. `0.2.7-statistical-bonus-review.1` hali
**PROVISIONAL / NOT ACCEPTED**. Asos HEAD:
`ee250df370c945f719cd574814cdb113c78680af`.

**Hech bir HTTP endpoint hozir ishga tushmagan.** Quyidagi «lokal tayyor» belgisi
pure verifier/transition va unit testga tegishli. HTTP router, durable saqlash,
real token, provider, DB/RLS yoki o‘quvchi piloti tayyor degani emas.

| Oqim | Lokal yadro / dalil | HTTP va storage uchun pending |
|---|---|---|
| `POST /auth/telegram`, raw `init_data` | `telegram.ts`: bot HMACi, imzo buzilishi, duplicate field, explicit freshness oralig‘i va signed identity unit testdan o‘tgan | Haqiqiy bot identity/freshness konfiguratsiyasi; consumed proof ledgeri; identity lookup/create; loginning atomik commit va Session mapperi |
| Custom opaque student sessiyasi | Faqat serverdan olinishi shart bo‘lgan `StudentAccess` ichki turi va scope shartlari bor | Access/refresh generator/hash ledgeri, fixed family lifetime, rotation/reuse/family revoke; `/auth/refresh`, `/auth/logout`, `/me`; haqiqiy bearer tekshiruvi. Staff JWT alohida tekshiriladi |
| Profile, guruh va test admission | Startda profile/roster/current group/membership epoch shartlari testlangan | Admin/Teacher vakolatli roster/publish oqimi va DB current scope; real fizika content/key/duration/roster/window |
| `POST /exams/{assignment_id}/attempts` | `{ confirmed: true }` talabi; exclusive admission close; full duration; frozen shuffle/snapshot; existing attemptni davom ettirish testlangan | Stable demo bo‘yicha global unique normal start, durable pinned version/order, lockdan keyingi fresh DB clock, K receipt va to‘liq `Attempt` HTTP mapping |
| `server_now` / `deadline_at` | Ichki millisecond vaqtlar, `startedAt + duration`, admission close bilan qisqarmaslik va equality expiry testlangan | Wire UTC `Z` timestamp mapperi; DBdagi committed start/deadline; har response uchun fresh server_now. UI timeri authoritative emas |
| `PUT /attempts/{attempt_id}/answers/{question_id}` | `expected_revision: 0` yangi javob, keyin ACK revision; null clear; foreign option va stale CAS rad etilishi testlangan | DB unique attempt+question, atomik CAS/series revision, durable commitdan keyingi `Answer` ACK; lost-response va haqiqiy parallel yozuv testi |
| `GET /attempts/{attempt_id}`, generation/reconcile | Server current attempt id+generation mosligi; cancelled/old urinish rad etilishi; active/terminal safe ichki projection testlangan | Durable current Series/pointer/recovery; to‘liq content va `Series` mapperi; committed ACKlarni qayta o‘qish. Recovery successor yaratish bu coreda hali yo‘q |
| `POST /attempts/{attempt_id}/submit` | Committed inputdan ordinaryni bir marta hosil qilish, terminal replay, late submitning expired bo‘lishi va current auth oldin tekshirilishi testlangan | Required K ledgeri/canonical payload conflict; DB lock/unique completion; save/submit/force/deadline/recovery race va current auth har replayda |
| Ordinary / `GET /attempts/{attempt_id}/result` | Off base1, on positive exact kasr; wrong/unanswered0; earned/max/percentage exact ratio; active result rad etilishi testlangan | Reviewed numeric storage/range/serialization/display tie policy; immutable completion row; `CompletedGradingResult`/`AttemptGradingResult` number/UTC/envelope mapperi |
| Alohida nullable `statistical_bonus` | Lokal bonus hisobi/storage/field mapperi hali yo‘q; ordinary hech qanday bonus chaqiruviga bog‘lanmagan | Response’da required key `statistical_bonus` explicit null yoki own saved aggregate sifatida berilishi; snapshot join original attemptga. Bonus activation/snapshot alohida reviewed bosqich |

## Consumer uchun muzlatilmagan wire qaydi

Pinned OpenAPI laboratoriya commit:
`f2c580508cfec9e07f383610201af28edffd854b`; GitHub LF SHA256:
`51deb7a41d223559022dcb7e17ff24985bd328e51c4a87c797a02763bb801149`.
Exact draft shakllari [mini-app-handoff.md](mini-app-handoff.md)da. Generated
client va origin hali yo‘q; `https://api.invalid/api/v1` faqat placeholder.

- Student proof opaque; staff JWT yoki client `roles`i o‘rniga qabul qilinmaydi.
  Ichki `StudentAccess` markerini HTTP bodydan yasash session verification emas.
- Start va submit `Idempotency-Key` talab qiladi. Submit body yo‘q. Lokal
  terminal replay testi hali durable K receipt ledgeri borligini anglatmaydi.
- Save body **faqat** `selected_option_id: UUID|null` va
  `expected_revision: integer>=0`. `generation` bu bodyga qo‘shilmaydi. Client
  pending navbatni `attempt_id + generation + question_id` bilan bog‘laydi;
  server current generationni DB Seriesdan oladi.
- ACK: `{data:{question_id,selected_option_id,revision,saved_at,series_state_revision}}`.
  `409 REVISION_CONFLICT` yoki yo‘qolgan javobdan keyin GET orqali reconcile;
  boshqa qurilma niyatini yangi revision bilan avtomatik bosib ketish yo‘q.
  Successor/terminal topilsa eski pending javoblar unga ko‘chirilmaydi.
- `now == deadline` kech: save javobni qabul qilmaydi va expired/ordinary
  transitionni **commit qilgach** `409 ATTEMPT_EXPIRED` qaytaradi. Submit shu
  holatda expired ordinary natijani `200` bilan qaytaradi. Error sabab terminal
  transition rollback qilinishi mumkin emas.
- Completed javobdagi ordinary non-null. Umumiy result shakli:
  `{data:{attempt_id,ordinary,statistical_bonus}}`. Bonus explicit nullable,
  alohida ball; ordinaryga qo‘shilmaydi va oddiy foizni almashtirmaydi.
  Yo‘q bonus, cohortdan tashqaridagi pupil yoki snapshotga kirmagan successor
  uchun null. Pupilga staff counts, key, peers yoki sertifikat darajasi berilmaydi.
- Ichki camelCase, millisecond va BigInt/Ratio turlari public wire emas.
  `Transition.record` private key/storage ma’lumotini tutadi; HTTPga yoki
  frontend bundlega chiqarilmaydi.

## Ochiq bandlar

Session TTL/freshness/skew, staff/bot provider konfiguratsiyasi va delegated Admin
scope; numeric storage/finite number/midpoint; API exact hash bo‘yicha consumer
review; real content/key/duration/roster/UTC window hal qilinmagan. Mahsulotning
positive fractional points/display2 va roster huquqlari qayta tanlanmaydi.
`getResultTBD`/pending summary eski review yorlig‘i sifatida qolgan; nom yoki
kontrakt yashirin o‘zgartirilmadi. Rasch bu oqimga qo‘shilmaydi.

## QA dalili va navbatdagi qabul mezoni

[Checkpoint1](backend-qa-checkpoint.md)ning barcha fayl xeshlari qayta o‘qilib
tekshirildi, kodi o‘zgarmagan. Uning oxirgi kuzatilgan natijasi:

```sh
node --test tests/backend/*.test.ts
```

Node.js `v24.22.1`: **23/23 pass, 0 fail, 0 skipped, exit0**. Bu hujjat uchun
testlar yangi HTTP/DB sinovi sifatida qayta talqin qilinmaydi. HTTP requests,
consumed replay, real bearer/JWT, Postgres/RLS, concurrent DB writes va real
o‘quvchi sinovi **NOT_RUN**. Static TypeScript typecheck ham bajarilmagan.

Keyingi qabul: ruxsatli lokal DB/storage va HTTP adapteridan o‘tgan synthetic
login→profile/roster→start→save/reconcile→submit→result oqimi; current auth,
lost ACK, CAS va deadline race, uniqueness/idempotency va key privacy dalili.
Real o‘quvchiga ochish alohida real Telegram/staff integratsiyasi, tekshirilgan
content, ruxsatli deploy va smoke/pilotga bog‘liq.

DB uchun alohida taklif: [db-change-plan.md](db-change-plan.md). Hozir SQL,
migration fayli, baza/provider o‘zgarishi yoki GitHub upload bajarilmadi.

Ushbu ikki yangi hujjat va o‘zgarmagan oldingi checkpoint uchun joriy aniq fayl
ro‘yxati/xeshlari [checkpoint2](backend-checkpoint-2.json)da. U 17 lokal o‘zgarishni
qamraydi: oldingi 14 fayl aynan saqlangan, 2 yangi hisobot va yangi manifest.
Checkpoint1ning 14 faylli to‘plami va receipt xeshi alohida o‘zgarmagan holda qoladi.
