# Student HTTP review va lokal adapter — 2026-11-05

**API egasi: Backend. Umumiy API holati: PROVISIONAL / NOT ACCEPTED.**
Quyidagi ACCEPT lokal adapterga tegishli semantik va wire chegarasidir;
production/APIning umumiy qabuli yoki yangi mahsulot vakolati emas.

Asos HEAD: `ee250df370c945f719cd574814cdb113c78680af`.
Pinned OpenAPI: laboratoriya commit
`f2c580508cfec9e07f383610201af28edffd854b`, versiya
`0.2.7-statistical-bonus-review.1`, GitHub LF SHA256
`51deb7a41d223559022dcb7e17ff24985bd328e51c4a87c797a02763bb801149`.
Oldingi nashr qilingan 14 fayl o‘zgarmagan; yangi adapter alohida lokal fayllarda.
Oldingi 23 testli checkpoint va yangi HTTP dalili aralashtirilmaydi.

## Bot/client handoff

Bot yuqoridagi exact OpenAPI xeshini hozircha draft mock/transport adapter uchun
ishlatishi mumkin. To‘liq shakllar oldingi [mini-app-handoff.md](mini-app-handoff.md)da;
ular shu pinned draftdan. **Generated API client/SDK, tinglayotgan server va
haqiqiy origin hali tayyor emas.** `https://api.invalid/api/v1` ishlamaydigan
placeholder. `student-contract.fixture.json` ham client emas. Consumer sign-off
va haqiqiy integratsiyadan oldin quyidagi BLOCKlar alohida yopilishi kerak.

## Aniq accept/block

| Band | Xulosa | Sabab / dalil |
|---|---|---|
| Telegram raw initData/HMAC va profile | ACCEPT lokal | Verified identity; consume va sessiya bitta transaction; profile whitelist; required ism/familiya; client role/group maydoni rad etiladi |
| Opaque access/refresh, replay va proof ajratilishi | ACCEPT lokal; BLOCK durable production | Random opaque proof; SHA256 ledger; initData signature ham qayta SHA256 qilinib consume qilinadi; staff JWT student proof sifatida o‘tmaydi; refresh reuse family revocationni401dan oldin commit qiladi |
| TTL/freshness/skew/tombstone/yangi login | BLOCK production | Raqamlar va `newLogin=revoke_previous` tanlovi hali reviewed production konfiguratsiya emas. Parameterlar majburiy, default yo‘q; testdagi qiymatlar faqat synthetic. Absolute family expiry rotationda uzaymaydi |
| Access expiry xatosi/client retry mapping | BLOCK consumer sign-off | Kandidat access/family expiryga401 `APP_SESSION_EXPIRED`, unknown/revokedga `SESSION_REVOKED`, rotationga `ACCESS_SUPERSEDED` beradi. Bearer expiryda refresh/fresh-launch UI kelishuvi exact draftga tekshirilsin; yangi enum kiritilmadi |
| Test metadata va roster | ACCEPT semantika; BLOCK real admin/storage | Faqat current group/epoch grant yoki own history. Metadata savol/kalitni bermaydi. O‘quvchi o‘zini guruhga qo‘shmaydi |
| Start/resume, `server_now` va `deadline_at` | ACCEPT lokal | Lockdan keyingi vaqt; exclusive admission close; full duration; qayta kirish yoki auth expiry test vaqtini o‘zgartirmaydi; wire UTC Z |
| Save/clear va reconcile | ACCEPT lokal | Required `expected_revision`, initial0, clear revisionni oshiradi; option shu savolniki; pending navbat attempt_id+generationga bog‘liq, generation bodyga qo‘shilmaydi; stale generation va epoch rad etiladi |
| Commit/ACK va expiry409 | ACCEPT lokal transaction boundary; BLOCK real durability | Transaction resolve bo‘lmaguncha response yo‘q; commit failure503; late save terminal+ordinaryni commit qilib409 beradi; xato uchun rollback qilinmaydi |
| Idempotent start/submit | ACCEPT lokal; BLOCK DB concurrency/retention | Actor+method+canonical target+K va payload receipt; auth/scope oldin; same/different K bitta attempt/completion; current receipt eski vakolatni tiklamaydi. DB constraint/retention hali yo‘q |
| Ordinary formula | ACCEPT avvalgi mahsulot semantikasi | Off base1/on positive fractional; wrong/unanswered0; exact earned/max/percentage; bonusga bog‘liq emas |
| Numeric storage/serialization/display | BLOCK production | DB representation/range/scale, JSON numberning finite projection siyosati va midpoint tie qabul qilinmagan. Serverdan explicit `NumericPresentation` talab qilinadi; yo‘q yoki nonfinite bo‘lsa409 `GRADING_POLICY_UNRESOLVED`. HALF_UP default qilinmadi |
| Nullable bonus va history | ACCEPT wire/attribution | `statistical_bonus` doim required key, nullable own aggregate; predecessor bonus successorga ko‘chmaydi. History faqat pupil-safe cancellation/score. Activation/hisoblash bu adapterda yo‘q |
| Image/media, ready recovery va staff HTTP | BLOCK implementatsiya | Text/formula projection bor; private image signing bo‘lmagani uchun503. Recovery yaratish/ready start va staff/provider/admin endpointlari hali implementatsiya qilinmagan |

`getResultTBD` va pending summary eski draft yorlig‘i sifatida qoladi; operationId
yoki manba OpenAPI yashirin tahrirlanmadi. Minimal ordinary oqimni Raschga
bog‘lash yoki Admin huquqini kengaytirish qilinmadi.

## Hozir lokal nima ishlaydi

`student-http.ts` standard `Request → Response` handlerini beradi. U listener
ochmaydi, URL/providerga ulanmaydi, `.env` yoki secret o‘qimaydi va deploy
qilinmaydi. 13 draft operation yo‘li bog‘langan:

1. `POST /auth/telegram`, `/auth/refresh`, `/auth/logout`.
2. `GET/PATCH /me`.
3. `GET /exams`, `/exams/{assignment_id}`.
4. `POST /exams/{assignment_id}/attempts`, `GET /attempts/{attempt_id}`.
5. `PUT /attempts/{attempt_id}/answers/{question_id}`.
6. `POST /attempts/{attempt_id}/submit`, `GET /attempts/{attempt_id}/result`.
7. `GET /exams/{assignment_id}/history`.

`student-state.ts` explicit session/numeric policy va transaction portini beradi.
`student-wire.ts` whitelist projection qiladi: profile, metadata, Attempt/Series,
Answer, ordinary/bonus va history. Ichki record, key, staff actor/reason va
BigInt/Ratio HTTPga chiqmaydi. JSON Schema uzunligi Unicode codepoint bo‘yicha
saqlanadi; Logout bodyga Refreshning maxLength cheklovi o‘zicha ko‘chirilmadi.
Hamma response/error `Cache-Control: no-store`, JSON envelope va error request_idga ega.

Test storage `http-fixture.ts` ichida: bitta global lock, cloned candidate state va
aniq commit/abort. **Bu RAM fixture, durable storage emas.** Parallel fixture
so‘rovlari faqat handlerning transaction tartibini isbotlaydi; PostgreSQL isolation,
RLS, deadlock yoki yuklama isboti emas. Whole-state nusxa olish ham faqat shu
lokal prototipga tegishli; 10 million/10 ming parallel sig‘im da’vosi yo‘q.

## Storage/tranzaksiya rejasi

SQLsiz mantiqiy schema/constraint, auth/RLS va rollback talablari
[db-change-plan.md](db-change-plan.md)da qoladi. Adapter uchun aniq port sharti:

```text
transaction(work):
  kerakli current identity/family/person+demo/attempt/grant locklarini olish
  current state ni aynan shu transactionda yuklash
  work({ state, now: freshLockedClock })
  qaytarilgan state/resultni atomik commit qilish
  faqat commitdan keyin Promise ni resolve qilish
```

Throw bo‘lsa abort; **qaytarilgan error completion bo‘lsa commit**. Handler
error response va numeric/wire mappingni transaction resolvedan keyin bajaradi.
Shuning uchun expiry409 yoki refresh reuse401 kerakli terminal/revocation holatini
yo‘qotmaydi. Commit rad etilsa muvaffaqiyat ACK yoki token javobi chiqmaydi.
Permanent store ushbu port shartiga amal qilgani alohida real sinovda isbotlanadi.

Kerakli durable invariantlar: unique consumed proof/token hash, family rotation
va current revocation; global person+stable-demo normal usage; current generation;
unique attempt+question va CAS; completion/ordinary/official pointer bir commit;
actor/operation/K receipt va canonical payload; immutable original-attempt bonus
join. Token/ordinary/answer commitidan tashqari joyda muvaffaqiyat deyilmaydi.
Replica lag orqali current authorization/read-after-write buzilmaydi.

Hozirgi `StudentState` obyektlari real jadval nomi yoki DB schema tanlovi emas.
Haqiqiy adapterdan oldin actual schema/keys/grants/RLS, storage/numeric bounds,
scope va timeout/retention tekshiriladi; exact diff/backfill/rollback reja alohida
ko‘riladi. Bu ishda baza so‘ralmadi, SQL yoki migration yaratilmagan/qo‘llanmagan.

## Adminning minimal yo‘li — huquqlar o‘zgarmaydi

| Bosqich | Draft endpoint / vakolat | Hozirgi holat |
|---|---|---|
| Staff kirishi/current grant | Verified staff Auth JWT, approved/enabled state, group+subject capability | BLOCK provider/bootstrap/delegated Admin scope |
| Group | Mavjud ruxsatli group ishlatiladi; yangi groupning direct POSTi Ownerga, Teacher request/approval orqali | Admin direct group-create huquqi taxmin qilinmaydi |
| Roster candidate/member | `GET /admin/students/unassigned`, exact `/lookup`, `PUT /admin/groups/{group_id}/members` | Scoped Teacher manage_roster yoki tegishli staff scope; wrong/foreign affinity404; real endpoint pending |
| Demo/version | `POST /admin/demos`, `POST /admin/demos/{demo_id}/versions` | Approved-subject content grant; Admin mutation capability reviewed bo‘lishi kerak; individual boolean explicit, UI initial off |
| Savollar/key/publish | `PUT /admin/versions/{version_id}/questions/{question_id}`, `POST .../publish` | Four options/key/base/media checks va frozen publish; haqiqiy content/key hali tekshirilmagan |
| Assignment/eligibility | `POST /admin/assignments`, kerak bo‘lsa `PUT .../{assignment_id}/participants` | Current group/subject/epoch, pinned version, Asia/Tashkent admission va review policy; student deadline qisqarmaydi |

Admin tayyorlaydigan birinchi fizika testi uchun tegishli real vakolat/grant va
ushbu endpointlar kerak. Test fixtureda oldindan yozilgan synthetic assignment
admin oqimi tayyor degani emas. Hech qanday public seed/role-bypass endpoint yo‘q.
Minimal admin route amalga oshirilmagani uchun student adapter `/admin/*`ga
muvaffaqiyat bermaydi. Fizikadan keyin matematika, Rasch keyingi bosqichda.

## Tekshiruv dalillari

- `node --test tests/backend/*.test.ts`: oldingi23 va yangi20 HTTP/contract testi,
  jami **43/43 pass**, fail0/skipped0. Node.js `v24.22.1`.
- `student-contract.fixture.json` pinned manbadan faqat13 operation response va
  ularga bog‘liq37 schemani olgan test extract. Generated client yoki yangi API
  kontrakti emas. Captured response/errorlar Pythonning mavjud `jsonschema`
  Draft202012/FormatChecker vositasi bilan shu sxemalarga tekshirildi.
- Strict server TypeScript tekshiruvi (TypeScript5.9.3, faqat `/tmp` tool cache):

```sh
npm exec --cache /tmp/univeracademy-typescript-cache --yes --package typescript@5.9.3 -- tsc --noEmit --allowImportingTsExtensions --target es2023 --module esnext --moduleResolution bundler --lib es2023,dom,dom.iterable --strict supabase/functions/univeracademy-api/*.ts
```

Testlar haqiqiy Telegram launch/staff provider, persistent session ledger, DB/RLS,
haqiqiy parallel DB yozuvi, socket/listener/CORS/rate-limit/media, Mini App
end-to-end yoki real pilotni bajarmaydi. Numeric test callbacki production policy
emas. Keyingi gate — reviewed policylar va ruxsatli durable adapter, so‘ng aniq
origin orqali integratsiya va real content/smoke/pilot dalili.

GitHub upload/commit/push, provider/baza, migration va deploy bu bosqichda yo‘q.
ECC yo‘qligi ishni to‘xtatmadi; Ponytail tamoyili bilan yangi runtime dependency
qo‘shilmadi. Oldingi checkpointlar va yangi ishning xeshlari alohida yuritiladi.
