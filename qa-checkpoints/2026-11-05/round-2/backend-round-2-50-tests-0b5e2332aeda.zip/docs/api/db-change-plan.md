# Birinchi fizika HTTP oqimi uchun DB o‘zgarish taklifi

2026-11-05. **PLAN ONLY / NOT APPLIED / NOT ACCEPTED.** Bu konseptual schema,
constraint va tranzaksiya rejasi; DDL yoki migration emas. API egasi Backend,
kontrakt `0.2.7-statistical-bonus-review.1` provisional. Hozirgi HEAD:
`ee250df370c945f719cd574814cdb113c78680af`.

## Boshlang‘ich dalil va cheklov

Avvalgi read-only inventarda `univeracademy-mvp` uchun Edge Functionlar va
migration yozuvlari bo‘sh, `public`da jadval ko‘rinmagan. Bu barcha private schema,
Auth, Storage, grant/RLS yoki eski muhitlar bo‘sh degani emas. Ushbu reja yozishda
jonli provider/baza qayta so‘ralmadi va o‘zgartirilmadi. Nomzod obyekt nomlari
real schema nomlari deb qabul qilinmasin.

DDL tayyorlashdan oldin target identity, barcha tegishli schema/table/function,
RLS/grant/owner/bypass holati, index/constraint, mavjud ma’lumotlar va dependencylar
alohida o‘qib inventarlanadi. Bo‘sh deb taxmin qilib reset/drop/recreate qilinmaydi.
Supabase boshqaradigan Auth schemaga qo‘lda bootstrap kiritish rejalashtirilmagan.

## Birinchi oqim uchun mantiqiy saqlash guruhlari

| Ma’lumot | Rejadagi invariant/constraint | Ochiq tafsilot |
|---|---|---|
| Person va external identity | O‘zgarmas person UUID; Telegram subject uchun yagona identity mapping; studentning doimiy 10 xonali IDsi unique va auth proof emas | Mavjud identity bilan moslik va bootstrap |
| Student session family, access/refresh, consumed initData | Proof/tokenlarning faqat hash/fingerprinti; unique consumed proof; access va refresh bir familyga bog‘liq; revocation/expiry authoritative | TTL/skew/tombstone retention, hash/key rotation va yangi login family siyosati reviewed bo‘lishi kerak; raw token/log/seed yo‘q |
| Staff current access/roles/grants | Providerdan verified identity; approved/enabled state, group/subject va capability DBdan; client roli authoritative emas | Delegated Admin mutation vakolatlari va provider binding; huquq kengaytirilmaydi |
| Group, membership/placement, roster grant | Bitta active group; affinity faqat ruxsatli transfer bilan o‘zgaradi; membership epoch eski unstarted grantni bekor qiladi | Mavjud schema va command revision mosligi; active attempt/approved-ready recoveryda removal/transfer to‘sig‘i |
| Stable demo, immutable published version, question/option/key | Normal foydalanish stable demoga tegishli; version publishdan so‘ng frozen; nonempty questions, four distinct options va o‘z questioniga tegishli correct key; required individual boolean | Actual fizika content/media; points parsing/precision/range; server key private saqlanadi |
| Assignment/admission | Original group+exact session+pinned version; UTC opens/closes va stored timezone; ro‘yxatdagi kech pupilning himoyalangan Asia/Tashkent start huquqi | Real kun/window; classroom end avtomatik admission close emas |
| Person+stable demo series/current pointer | Global bitta normal foydalanish; unique person+stable demo; monoton generation/state revision; current/official attempt pointerlar izchil | Recovery CAS/approval va mavjud history mosligi |
| Attempt va order/snapshot | Unique attempt identity va series generation; immutable version/order/base; start+full duration deadline; terminal reason/time va current pointer mos | Snapshotning aniq normalized/storage representationi va private media mapping |
| Javoblar | Unique attempt+question; option pinned questionga tegishli; revision0 initial/no row; har save/clear yangi revision va series revision | Atomik insert/update CAS usuli va durable ACK adapteri |
| Ordinary completion | Bitta completed attemptga bitta immutable earned/max/percentage source; nonempty/musbat max; wrong/unanswered0; ordinary bonussiz commit bo‘ladi | Exact decimal/rational representation, DB bound va finite JSON/display rounding hali tanlanmagan |
| Idempotency command receipts | Actor+method+canonical target+operation+K va canonical payload hash; same command receipt; differing payload409; replayda current auth | Expiry/retention va receiptning static/dynamic response qismlari; raw proof saqlanmaydi |

Har FK/reference haqiqiy identity va version chegarasini saqlaydi. Answer option
faqat shu question/pinned versiondan olinadi; result nested attempt_id va current
series generationni server ham tekshiradi. Cross-record invariantlarning hammasi
oddiy JSON Schema yoki bitta CHECK orqali isbotlanadi deb yozilmaydi.

## Qisqa tranzaksiyalar va HTTP natijalari

1. **Login:** tashqi initData HMAC/freshness tekshiruvi → DB tranzaksiyasida
   consumed fingerprintni yagona consume qilish, current account va identityni
   tekshirish, reviewed family siyosati bo‘yicha session yozish → commitdan keyin
   raw access/refreshni faqat shu HTTP javobda berish. Bir proofning parallel
   loginlari ikkita sessiya yaratmasin. Lost login javobi qayta consume ruxsati emas.
2. **Refresh/logout:** proof current family bilan atomik tekshiriladi; refresh
   consume/rotation va old access revoke bitta transaction. Reuse family revoke
   qiladi; invalid bearer body proofga yashirin downgrade qilinmaydi. Logout
   test attempt/timerga tegmaydi. Retention raqami taxmin qilinmaydi.
3. **Start:** current auth/scope → person/stable-demo series va tegishli
   membership/admissionni kelishilgan lock tartibida tekshirish → lockdan keyingi
   fresh `clock_timestamp()` bilan `opens <= now < closes` → unique normal attempt,
   pinned order/key/base va `deadline=start+full duration`ni atomik yozish.
   Tranzaksiya boshidagi vaqt lock kutishidan keyingi admission qaroriga asos
   bo‘lmaydi. Global DB uniqueness ikki parallel startni to‘xtatadi; client Ksi
   yagona himoya emas. Receipt/current holat mosligi replayda qayta tekshiriladi.
4. **Save/reconcile:** current proof/scope/current attempt+generation → series/
   attempt lock → fresh clock. Kech bo‘lsa avval terminal expiry+ordinary commit,
   so‘ng409. Aks holda option relation va `expected_revision` bilan CAS, answer
   va series revision bitta commit; keyin ACK. Lost ACKdan keyingi GET aynan
   committed holatni o‘qiydi. Primary/read-after-write izchilligi saqlanadi.
5. **Submit/force/deadline:** bir xil attempt/series lock tartibi saqlangan
   javoblar va completionni tartiblaydi. Current auth har replayda oldin;
   idempotency payload/receipt tekshiruvi, yangi bo‘lsa ordinary+terminal state+
   official pointer+receipt bir commit. Deadline tengligida expired, self-submit
   emas. Existing completed result qayta hisoblanmaydi. Error response yuborish
   kerakligi terminal materializationni rollback qilish sababi bo‘lmaydi.
6. **Recovery/history:** faqat Owner/scoped authorized Admin vakolati va
   expected current state bilan; predecessor saqlanadi/cancelled nonofficial,
   successor blank yangi generation va full duration bilan. Eski javob/bonus
   ko‘chirilmaydi. Ready recovery start huquqi admission/bonus barrierga kiradi.

Bot/provider HTTP chaqiruvlari va notification yuborish DB lock ichida bajarilmaydi.
Qaysi obyektlar qaysi tartibda lock qilinishi real schema uchun bitta umumiy
tartibda yoziladi; shunchaki «transaction bor» deadlock/concurrency isboti emas.
Timeout/retry limitlari va pool konfiguratsiyasi alohida reviewed qiymatlardir.

## Bonus — alohida optional bosqich

Birinchi ordinary natija uchun bonus jadvali yoki alohida worker shart emas.
HTTP mapper mavjud bonus bo‘lmasa required `statistical_bonus` keyini explicit
null qilib beradi; keyinchalik original attemptga scoped aggregate join qilinadi.

Bonus qo‘shiladigan alohida diffda canonical original session+
`statistical_bonus_v1` uchun unique calculation, immutable selected pupil/attempt
va question/key/base/committed answer/unanswered facts, policy/input hash/time,
per-question wrong/N hamda per-person exact total ko‘rsatiladi. K yoki policy
versiyasi logical uniquenessni bo‘lmaydi. Current auth → canonical lock → existing
snapshot → faqat yo‘q bo‘lsa admission/all-started/recovery/numeric/cohort gate.
N1 mumkin; N0/no snapshot va synchronous201/200 mexanikasi review taklifi holida.
Teacher/Owner activation huquqi saqlanadi, Admin POST/replay qilmaydi. Ordinary
yangilanmaydi. Successor joini predecessor bonusini meros olmaydi. Rasch qo‘shilmaydi.

## Scope, RLS va index rejasi

- Frontend custom student proofi Supabase Auth JWT deb olinmaydi. `auth.uid()`ni
  opaque studentga bevosita qo‘llash bilan to‘liq RLS qurildi deb bo‘lmaydi.
  Verified server identityni DB tranzaksiyasiga xavfsiz yetkazish va role/policy
  mapping alohida reviewed bo‘ladi; client tanlagan person/group contextiga ishonilmaydi.
- Key va session ledgerlar browser/Data APIga ochilmaydi. Exposed schema uchun
  grant va RLS birga ko‘riladi; private schema uchun ham least privilege/row
  isolation rejalashtiriladi. Session context transaction/pool oralig‘ida boshqa
  pupilga sizib o‘tmasligi tekshiriladi. Bypass/service-role ishlatilsa serverdagi
  current auth/scope talabi yo‘qolmaydi; FORCE RLS ham BYPASSRLSni tekshirmaslik
  uchun sabab emas. `SECURITY DEFINER` avtomatik permission yechimi emas.
- Dastlab unique identity/fingerprint, active membership, person+stable demo,
  attempt+question, generation/receipt lookup va kerakli FK join/pagination
  indekslari ko‘rib chiqiladi. Har bir index actual query va existing constraint
  bilan solishtiriladi; takror yoki barcha ustunga taxminiy index yaratilmaydi.
- Avval bitta PostgreSQL va qisqa transactionlar. Replica/sharding/partition yoki
  10 ming parallel foydalanuvchi tayyorligi bu reja bilan tasdiqlanmaydi.

## Keyingi alohida review/approval uchun tayyorlanadigan to‘plam

Bu hujjat ruxsat yoki SQL execution emas. Keyingi konkret taklif quyidagilarni
o‘z ichiga oladi:

1. Target identity va amaldagi schema/RLS/grant/index inventari; mavjud kod va
   ma’lumot bilan moslik, qaysi obyekt add/alter bo‘lishi va qaysisi o‘zgarmasligi.
2. Reviewed numeric/session/scope qarorlari bilan aniq schema/constraint/index/
   function/policy diffi. CLI va migration workflow joriy versiya/help orqali
   tekshiriladi; timestamp migration nomi hozir o‘ylab topilmadi.
3. Existing data bo‘lsa alohida backfill/mapping/reconciliation; validatsiyasiz
   NOT NULL/unique qo‘ymaslik; normal usage/history/bonus attributionni saqlash.
4. Faqat ruxsatli lokal/test DBda synthetic fixture va haqiqiy parallel request
   sinovi; constraint/RLS hamda current scope/revocation testlari. Migration
   apply uchun foydalanuvchining aniq scope tasdig‘i bundan alohida olinadi.
5. Oldingi data/schema qayta tiklash rejasi, rollback/forward-fix va yangi yozuv
   bo‘lgan holatdagi data preservation. Session revoke/ordinary/historyni
   yo‘qotadigan blind down/drop/recreate rollback taklif qilinmaydi.
6. GitHub upload, provider configure yoki deploy uchun exact diff/files va
   alohida tasdiq. Real roster, test kaliti, raw token va dump public repoga
   seed/fixture qilib qo‘yilmaydi.

## DB qabul mezonlari — hozir NOT_RUN

- Ikki parallel login/start/refreshda yagona logical natija va to‘g‘ri reuse/revoke;
  revoked proof yoki scope existing receipt orqali o‘tmasligi.
- Ikki parallel initial save/CAS, save/submit/force/deadline, stale generation va
  recoveryda nol yo‘qolgan ACK, nol takror completion; transaction rollback,
  connection uzilishi va lost-response’dan keyin to‘g‘ri reconcile.
- Durable restartdan so‘ng answer/order/time/ordinary/current pointer bir xil;
  `deadline_at` admission yoki session expiry bilan qisqarmasligi/uzaymasligi.
- Boshqa pupil/group/subject/student-vs-staff proofi bilan query/HTTP rad etilishi;
  RLS, grants, key/media privacy va pool context isolation.
- Positive fractional/large approved bounds/recurring percentage uchun reviewed
  exact storage va finite wire/display mosligi; partial ordinary yoki bonus
  ko‘rinmasligi; successor attribution va history izchilligi.
- Avval 10–30 kishilik pilotga mos sinov; 10 ming parallel maqsad uchun alohida
  o‘lchov. p95, timeout va ruxsatli xatolar chegarasi taxmin qilinmaydi.

Hozir mavjud dalil faqat [student-http-status.md](student-http-status.md) va
[checkpoint1](backend-qa-checkpoint.md)dagi 23 lokal unit test. DB qabul mezonlari
bajarilgan emas. Supabase/Postgres best-practices skillining RLS, indexes va
short-transactions ko‘rsatmalari ko‘rildi; misol SQL current student proofiga
moslashtirilmasdan ko‘chirilmadi. Migration yaratilmagan yoki qo‘llanmagan.
