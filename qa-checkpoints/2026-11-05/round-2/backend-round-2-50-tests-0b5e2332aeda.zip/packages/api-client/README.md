# Student client — yagona lokal handoff

Mas’ul Backend; Bot/Mini App va keyingi consumerlar bir xil nusxani ishlatadi.
Mashina o‘qiydigan yagona handoff: [HANDOFF.json](HANDOFF.json).

**LOCAL FIXTURE ONLY. Umumiy API hali PROVISIONAL / NOT ACCEPTED.** Bu clientning
yaratilishi consumer sign-off, production yoki eski acceptance ko‘chganini
anglatmaydi. Eski checkpoint hisobotlari o‘z sanasidagi holatni saqlaydi; ushbu
README/HANDOFF yangi lokal client bosqichining kirish nuqtasi.

API: `0.2.7-statistical-bonus-review.1`.
To‘liq pinned OpenAPI GitHub LF SHA256:
`51deb7a41d223559022dcb7e17ff24985bd328e51c4a87c797a02763bb801149`.
Manba commit: `f2c580508cfec9e07f383610201af28edffd854b`.

- `student-openapi.json`: shu manbadan aynan13 student operation va request/response
  uchun43 transitive schema; yangi kontrakt yoki barcha API qabul qilinganligi emas.
- `student-types.d.ts`: `openapi-typescript@7.13.0` chiqargan type-only fayl.
  DTOlar qo‘lda parallel yozilmagan; generated faylni tahrirlamang.
- `student-client.ts`: shu turlarga asoslangan, dependency talab qilmaydigan
  `createLocalStudentClient`. Faqat explicit local transport va exact hash bilan
  yaratiladi. Production host, noto‘g‘ri hash va native-fetch fallback rad etiladi.

```ts
import { createLocalStudentClient, STUDENT_CONTRACT_SHA256 } from "./student-client.ts";

// Lokal test/integration fixture; bu haqiqiy origin yoki production konfiguratsiya emas.
const client = createLocalStudentClient({
  mode: "local_fixture",
  contractSha256: STUDENT_CONTRACT_SHA256,
  baseUrl: "http://local.invalid/api/v1",
  transport: localRequestHandler,
});
```

`localRequestHandler` shu testda caller tomonidan beriladigan `Request→Response`
funksiya. SDK listener yoki serverni o‘zi ochmaydi. `https://api.invalid/api/v1`
placeholderga ham, real providerga ham ulanmaydi.

## Client chegarasi

13 operation: Telegram login, refresh/logout, me GET/PATCH, exams/list/detail,
start/resume, save/clear, submit/result/history. Hamma muvaffaqiyatli javob
original `{ data: ... }` envelope bilan qaytadi. Required Kni caller start/submitga
beradi; SDK uni o‘zi almashtirmaydi. Save faqat original `selected_option_id` va
`expected_revision`; generation navbatning attempt identitysi bilan Botda bog‘lanadi.

Access tokenlar har callga explicit beriladi; SDK JWT decode, localStorage,
background refresh/timer, role/grant, rounding yoki bonus hisoblamaydi. Session
tugashi test timerini o‘zgartirmaydi. Refresh single-flight: ayni pending proof
uchun bitta request. Tugagan yoki javobi yo‘qolgan proof qayta jo‘natilmaydi;
yangi Telegram launch callerning explicit amali. SDK boshqa amallarni ham
avtomatik retry qilmaydi. Lost submit/start javobida caller ayni K bilan retry
yoki GET/reconcile yo‘lini ishlatadi.

`StudentApiError` API status/code/requestIdni beradi; raw body, token yoki server
message xatoga ko‘chirilmaydi. `StudentClientProtocolError` local config/transport
envelope xatosi, u yangi server error kodi emas. Generated typing to‘liq runtime
JSON Schema validation o‘rnini bosmaydi; server/HTTP testlari pinned schemani
alohida tekshiradi. Kalit yoki ichki BigInt/Ratio clientga kirmaydi.

## Integratsiyani bloklayotgan bandlar

| ID | Ochiq band | Yopish uchun kerak |
|---|---|---|
| S1 | initData freshness/future skew, access/family TTL, logout tombstone, yangi login family siyosati | Raqamlari va revoke/expiry chegaralari reviewed configda; synthetic policy production deb ko‘rsatilmasin |
| S2 | Bearer expiry401dan keyingi Bot refresh/fresh-launch mapping | `APP_SESSION_EXPIRED`, `SESSION_REVOKED`, `ACCESS_SUPERSEDED`, refresh reuse/lost response bo‘yicha consumer review; hozir auto qaror yo‘q |
| N1 | Numeric DB precision/scale/range, exact storage va finite JSON presentation/midpoint | Backend numeric policy, chegaralar va server/UI test vektorlari. Positive fractional va display2 tasdiqlangan; HALF_UP yangi default emas |
| D1 | Durable transactions/current authorization/CAS/uniqueness/idempotency | Haqiqiy storage/DB/RLS va parallel request/lost ACK sinovi; RAM fixture production dalili emas |
| A1 | Staff identity/bootstrap va delegated Admin mutation scope | Verified staff JWT va current enabled/approved group/subject/capability; client `roles`i vakolat emas |
| A2 | Birinchi admin testi uchun minimal yo‘l | Ruxsatli group → scoped roster → approved-subject demo/version/key/publish → assignment/eligibility; Adminga direct group-create yoki broad lookup berilmaydi |
| I1 | Media/ready recovery, listener/origin/CORS/rate/body chegaralari | Implementatsiya va real integratsiya dalili; bu SDK production hostni qabul qilmaydi |
| P1 | Fizika content/key/duration/roster/window va Telegram launch | Haqiqiy material va kirish usuli tekshirilishi; alohida ruxsatli deploy/smoke/pilot |

Student semantikasi va storage portining oldingi batafsil reviewi:
[student-http-review.md](../../docs/api/student-http-review.md), SQLsiz reja:
[db-change-plan.md](../../docs/api/db-change-plan.md). Ular production acceptance
emas. Admin roster/content/assignment endpointlari bu student clientga qo‘shilmadi;
product huquqi kengaytirilmadi. Rasch keyingi bosqichda qoladi.

## QA va qayta chiqarish

```sh
node --test tests/backend/*.test.ts
npm exec --cache /tmp/univeracademy-typescript-cache --yes --package typescript@5.9.3 -- tsc --noEmit --allowImportingTsExtensions --target es2023 --module esnext --moduleResolution bundler --lib es2023,dom,dom.iterable --strict supabase/functions/univeracademy-api/*.ts packages/api-client/student-client.ts
npm exec --cache /tmp/univeracademy-typescript-cache --yes --package openapi-typescript@7.13.0 -- openapi-typescript packages/api-client/student-openapi.json -o /tmp/univeracademy-student-types-check.d.ts
```

Oldingi HTTP checkpoint43 testi o‘zgarmagan. Shared client uchun7 test qo‘shildi:
eng yangi nusxa **50/50 pass**; strict server+client TypeScript ham o‘tdi.
Generatorning `/tmp` chiqishi bilan `student-types.d.ts` baytlari solishtiriladi.
Runtime dependency qo‘shilmagan, tool cache faqat `/tmp`da.

Round-2 uchun source fayl/xesh ro‘yxati, base/HEAD, public privacy va test dalili
`docs/api/backend-round-2-source-manifest.json`da qayd etiladi. Haqiqiy token,
o‘quvchi yoki imtihon kaliti ishlatilmagan; eski va yangi synthetic fixturelar
oshkora. Yangi nusxa upload/commit/push qilinmagan; oldingi ruxsat unga tegishli emas.

