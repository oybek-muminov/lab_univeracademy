import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { ratio } from "../../supabase/functions/univeracademy-api/ordinary.ts";
import { seriesKey } from "../../supabase/functions/univeracademy-api/student-state.ts";
import { capturedReplies, clock, fixture, id, ids, signedInitData, testNumbers, testPolicy }
  from "./http-fixture.ts";

type Fixture = ReturnType<typeof fixture>;
async function session(f: Fixture, telegramId = 4_000_000_001, query = "synthetic-login") {
  const response = await f.login(telegramId, query);
  assert.equal(response.status, 200);
  return response.json.data;
}
async function start(f: Fixture, token: string, key = "start-key-0001") {
  const response = await f.call("POST", `/exams/${ids.assignment}/attempts`,
    { token, key, body: { confirmed: true } });
  assert.equal(response.status, 200);
  return response.json.data;
}
async function save(f: Fixture, token: string, attempt: string, revision = 0, option: string | null = ids.correct) {
  return f.call("PUT", `/attempts/${attempt}/answers/${ids.question}`,
    { token, body: { selected_option_id: option, expected_revision: revision } });
}
async function submit(f: Fixture, token: string, attempt: string, key = "submit-key-001") {
  return f.call("POST", `/attempts/${attempt}/submit`, { token, key });
}
function holdNextCommit(f: Fixture) {
  let release!: () => void, entered!: () => void;
  const held = new Promise<void>((resolve) => { release = resolve; });
  const ready = new Promise<void>((resolve) => { entered = resolve; });
  f.store.beforeCommit = async () => { f.store.beforeCommit = null; entered(); await held; };
  return { ready, release };
}

test("HTTP synthetic pupil completes profile→test→start/resume→save/clear→submit/result/history", async () => {
  const f = fixture(), s = await session(f), token = s.access_token;
  assert.match(token, /^[0-9a-f]{64}$/);
  assert.ok(f.store.state.access[createHash("sha256").update(token).digest("hex")]);
  assert.equal(f.store.state.access[token], undefined);
  assert.equal(f.store.state.refresh[s.refresh_token], undefined);
  const initSignature = new URLSearchParams(signedInitData()).get("hash")!;
  assert.equal(f.store.state.consumedInitData[initSignature], undefined);
  assert.equal(f.store.state.consumedInitData[createHash("sha256").update(initSignature).digest("hex")], true);
  assert.equal((await f.call("GET", "/me", { token })).json.data.person_id, ids.person);
  const profile = await f.call("PATCH", "/me", { token, body: { first_name: "Yangi", last_name: "Sun’iy" } });
  assert.equal(profile.json.data.first_name, "Yangi");
  assert.equal(profile.json.data.registration_complete, true);
  const exams = await f.call("GET", "/exams", { token });
  assert.equal(exams.json.data.length, 1);
  assert.equal(exams.json.data[0].question_count, 2);
  assert.ok(!("questions" in exams.json.data[0]));
  assert.equal((await f.call("GET", `/exams/${ids.assignment}`, { token })).status, 200);
  const attempt = await start(f, token);
  assert.equal(Date.parse(attempt.deadline_at) - Date.parse(attempt.started_at), 60_000);
  assert.ok(Date.parse(attempt.deadline_at) > clock + 1000);
  assert.equal(attempt.generation, 1);
  assert.equal((await save(f, token, attempt.id)).json.data.revision, 1);
  assert.equal((await save(f, token, attempt.id, 1, null)).json.data.revision, 2);
  assert.equal((await save(f, token, attempt.id, 2)).json.data.revision, 3);
  const resumed = await f.call("GET", `/attempts/${attempt.id}`, { token });
  assert.deepEqual(resumed.json.data.questions, attempt.questions);
  assert.equal(resumed.json.data.answers[0].revision, 3);
  const submitted = await submit(f, token, attempt.id);
  assert.equal(submitted.status, 200);
  assert.equal(submitted.json.data.ordinary.earned_points, 1);
  assert.equal(submitted.json.data.ordinary.max_points, 2);
  assert.equal(submitted.json.data.ordinary.percentage, 50);
  assert.equal(submitted.json.data.statistical_bonus, null);
  const result = await f.call("GET", `/attempts/${attempt.id}/result`, { token });
  assert.deepEqual(result.json, submitted.json);
  const history = await f.call("GET", `/exams/${ids.assignment}/history`, { token });
  assert.equal(history.json.data.attempts[0].lifecycle_status, "submitted");
  assert.deepEqual(history.json.data.attempts[0].score, result.json.data);
  assert.equal(result.headers.get("cache-control"), "no-store");
});

test("HTTP auth rejects tamper, consumed initData, staff proof and disabled account", async () => {
  const f = fixture();
  assert.equal((await f.call("GET", "/me")).status, 401);
  assert.equal((await f.call("GET", "/me", { token: "eyJhbGciOiJSUzI1NiJ9.synthetic.staff" })).status, 401);
  const tampered = await f.call("POST", "/auth/telegram", {
    body: { init_data: signedInitData().replace("synthetic-login", "tampered-login") } });
  assert.equal(tampered.status, 401);
  const s = await session(f);
  assert.equal((await f.login()).json.error.code, "INIT_DATA_REPLAY");
  f.store.state.people[ids.person].enabled = false;
  assert.equal((await f.call("GET", "/me", { token: s.access_token })).json.error.code, "ACCOUNT_DISABLED");
  assert.equal(Object.keys(f.store.state.consumedInitData).length, 1);
});

test("HTTP refresh rotates, preserves absolute expiry and commits family revoke on reuse401", async () => {
  const f = fixture(), first = await session(f);
  const rotated = await f.call("POST", "/auth/refresh", { body: { refresh_token: first.refresh_token } });
  assert.equal(rotated.status, 200);
  assert.notEqual(rotated.json.data.access_token, first.access_token);
  assert.equal(rotated.json.data.refresh_expires_at, first.refresh_expires_at);
  assert.equal((await f.call("GET", "/me", { token: first.access_token })).json.error.code, "ACCESS_SUPERSEDED");
  assert.equal((await f.call("GET", "/me", { token: rotated.json.data.access_token })).status, 200);
  const reused = await f.call("POST", "/auth/refresh", { body: { refresh_token: first.refresh_token } });
  assert.equal(reused.json.error.code, "REFRESH_REUSED");
  assert.equal(Object.values(f.store.state.families)[0].revokedAt, clock);
  assert.equal((await f.call("GET", "/me", { token: rotated.json.data.access_token })).json.error.code, "SESSION_REVOKED");
});

test("HTTP explicit TTL/fresh login never resets an existing exam deadline", async () => {
  const f = fixture(), first = await session(f), a = await start(f, first.access_token);
  f.store.time += testPolicy.accessTtlMs;
  assert.equal((await f.call("GET", "/me", { token: first.access_token })).json.error.code, "APP_SESSION_EXPIRED");
  const refreshed = await f.call("POST", "/auth/refresh", { body: { refresh_token: first.refresh_token } });
  assert.equal(refreshed.json.data.refresh_expires_at, first.refresh_expires_at);
  const fresh = await session(f, 4_000_000_001, "fresh-synthetic-login");
  assert.equal((await f.call("GET", "/me", { token: refreshed.json.data.access_token })).status, 401);
  assert.equal(f.store.state.attempts[a.id].deadlineAt, Date.parse(a.deadline_at));
  assert.equal((await f.call("GET", `/attempts/${a.id}`, { token: fresh.access_token })).json.data.deadline_at, a.deadline_at);
  f.store.time = clock + testPolicy.accessTtlMs + testPolicy.familyTtlMs;
  assert.equal((await f.call("POST", "/auth/refresh", { body: { refresh_token: fresh.refresh_token } })).json.error.code,
    "REFRESH_EXPIRED");
});

test("HTTP session policy has no implicit defaults; new pupils cannot self-assign roles/groups", async () => {
  const blocked = fixture({ sessionPolicy: undefined });
  assert.equal((await blocked.login()).status, 503);
  assert.equal(Object.keys(blocked.store.state.families).length, 0);
  const f = fixture(), s = await session(f, 4_000_000_999, "new-synthetic-pupil");
  assert.equal(s.profile.registration_complete, false);
  assert.equal(s.profile.active_group_id, null);
  assert.match(s.profile.qadam_id, /^\d{10}$/);
  assert.deepEqual((await f.call("GET", "/exams", { token: s.access_token })).json.data, []);
  assert.equal((await f.call("PATCH", "/me", { token: s.access_token,
    body: { first_name: "X", last_name: "Y", roles: ["owner"] } })).status, 422);
  assert.equal((await f.call("POST", "/admin/groups", { token: s.access_token, body: {} })).status, 404);
});

test("HTTP logout needs proof, never downgrades invalid bearer, and obeys explicit tombstone", async () => {
  const f = fixture(), a = await session(f), b = await session(f, 4_000_000_002, "other-synthetic");
  assert.equal((await f.call("POST", "/auth/logout")).json.error.code, "LOGOUT_PROOF_REQUIRED");
  assert.equal((await f.call("POST", "/auth/logout", { token: a.access_token,
    body: { refresh_token: b.refresh_token } })).json.error.code, "LOGOUT_PROOF_MISMATCH");
  assert.equal((await f.call("POST", "/auth/logout", { token: "invalid-bearer",
    body: { refresh_token: a.refresh_token } })).status, 401);
  assert.equal((await f.call("POST", "/auth/logout", { token: a.access_token })).status, 200);
  assert.equal((await f.call("GET", "/me", { token: a.access_token })).status, 401);
  assert.equal((await f.call("POST", "/auth/logout", { body: { refresh_token: a.refresh_token } })).status, 200);
  f.store.time += testPolicy.logoutTombstoneMs + 1;
  assert.equal((await f.call("POST", "/auth/logout", { body: { refresh_token: a.refresh_token } })).status, 401);
});

test("HTTP private targets and revoked scope cannot be recovered via idempotency replay", async () => {
  const f = fixture(), a = await session(f), b = await session(f, 4_000_000_002, "other-synthetic");
  const attempt = await start(f, a.access_token);
  assert.deepEqual((await f.call("GET", "/exams", { token: b.access_token })).json.data, []);
  assert.equal((await f.call("GET", `/exams/${ids.assignment}`, { token: b.access_token })).status, 404);
  assert.equal((await f.call("GET", `/attempts/${attempt.id}`, { token: b.access_token })).status, 404);
  delete f.store.state.grants[ids.person][ids.assignment];
  assert.equal((await f.call("POST", `/exams/${ids.assignment}/attempts`, {
    token: a.access_token, key: "start-key-0001", body: { confirmed: true } })).status, 403);
  assert.equal((await save(f, a.access_token, attempt.id)).status, 404);
  assert.equal(f.store.state.attempts[attempt.id].answers.length, 0);
});

test("HTTP clear/CAS/lost ACK and parallel fixture writes reconcile committed revisions", async () => {
  const f = fixture(), s = await session(f), a = await start(f, s.access_token);
  const responses = await Promise.all([save(f, s.access_token, a.id), save(f, s.access_token, a.id, 0, ids.wrong)]);
  assert.deepEqual(responses.map((r) => r.status).sort(), [200, 409]);
  assert.equal(f.store.state.attempts[a.id].answers[0].revision, 1);
  // The first successful response could have been lost; retrying old CAS must not overwrite it.
  assert.equal((await save(f, s.access_token, a.id)).json.error.code, "REVISION_CONFLICT");
  const resumed = await f.call("GET", `/attempts/${a.id}`, { token: s.access_token });
  assert.equal(resumed.json.data.answers[0].selected_option_id, ids.correct);
  assert.equal((await save(f, s.access_token, a.id, 1, null)).json.data.revision, 2);
  assert.equal((await f.call("PUT", `/attempts/${a.id}/answers/${ids.question}`, { token: s.access_token,
    body: { selected_option_id: ids.correct, expected_revision: 2, generation: 1 } })).status, 422);
  assert.equal((await save(f, s.access_token, a.id, 2, id(204))).json.error.code, "INVALID_OPTION");
});

test("HTTP success waits for commit; rejected commit returns503 with no accepted answer", async () => {
  const f = fixture(), s = await session(f), a = await start(f, s.access_token);
  const held = holdNextCommit(f);
  let replied = false;
  const pending = save(f, s.access_token, a.id).then((r) => { replied = true; return r; });
  await held.ready;
  assert.equal(replied, false);
  assert.equal(f.store.state.attempts[a.id].answers.length, 0);
  held.release();
  assert.equal((await pending).status, 200);
  assert.equal(f.store.state.attempts[a.id].answers.length, 1);
  f.store.failNextCommit = true;
  const failed = await save(f, s.access_token, a.id, 1, null);
  assert.equal(failed.status, 503);
  assert.equal(f.store.state.attempts[a.id].answers[0].revision, 1);
});

test("HTTP admission uses the clock after a queued transaction acquires its lock", async () => {
  const f = fixture(), s = await session(f);
  const held = holdNextCommit(f);
  const occupying = f.store.transaction(async () => null);
  await held.ready;
  const pending = f.call("POST", `/exams/${ids.assignment}/attempts`, {
    token: s.access_token, key: "queued-start-key", body: { confirmed: true } });
  f.store.time = clock + 1000; // Admission closes while the request waits for its lock.
  held.release();
  await occupying;
  const response = await pending;
  assert.equal(response.json.error.code, "ADMISSION_CLOSED");
  assert.equal(Object.keys(f.store.state.attempts).length, 0);
  assert.equal(f.store.events.at(-2), "lock");
  assert.equal(f.store.events.at(-1), "clock");
});

test("HTTP expiry409 commits ordinary/terminal state instead of rolling it back", async () => {
  const f = fixture(), s = await session(f), a = await start(f, s.access_token);
  await save(f, s.access_token, a.id);
  f.store.time = Date.parse(a.deadline_at);
  assert.equal((await save(f, s.access_token, a.id, 1, null)).status, 401);
  assert.equal(f.store.state.attempts[a.id].status, "in_progress"); // Auth precedes side effects.
  const fresh = await session(f, 4_000_000_001, "after-expiry-login");
  assert.equal(f.store.state.attempts[a.id].deadlineAt, Date.parse(a.deadline_at));
  const late = await save(f, fresh.access_token, a.id, 1, null);
  assert.equal(late.status, 409);
  assert.equal(late.json.error.code, "ATTEMPT_EXPIRED");
  assert.equal(f.store.state.attempts[a.id].status, "expired");
  assert.deepEqual(f.store.state.attempts[a.id].ordinary!.earned, ratio(1n));
  assert.equal(f.store.state.attempts[a.id].answers[0].selectedOptionId, ids.correct);
  // New valid auth does not reset the expired exam.
  const result = await f.call("GET", `/attempts/${a.id}/result`, { token: fresh.access_token });
  assert.equal(result.json.data.ordinary.earned_points, 1);
  assert.deepEqual((await f.call("POST", `/attempts/${a.id}/submit`, {
    token: fresh.access_token, key: "late-submit-key" })).json, result.json);
});

test("HTTP idempotent submit keys share one completion and failed commit creates no receipt", async () => {
  const f = fixture(), s = await session(f), a = await start(f, s.access_token);
  assert.equal((await f.call("POST", `/attempts/${a.id}/submit`, { token: s.access_token })).status, 422);
  assert.equal(f.store.state.attempts[a.id].status, "in_progress");
  f.store.failNextCommit = true;
  assert.equal((await submit(f, s.access_token, a.id)).status, 503);
  assert.equal(f.store.state.attempts[a.id].ordinary, null);
  const receiptsBefore = Object.keys(f.store.state.receipts).length;
  const responses = await Promise.all([submit(f, s.access_token, a.id), submit(f, s.access_token, a.id),
    submit(f, s.access_token, a.id, "another-submit-key")]);
  for (const r of responses) assert.equal(r.status, 200);
  assert.deepEqual(responses[0].json, responses[1].json);
  assert.deepEqual(responses[0].json, responses[2].json);
  assert.equal(f.store.state.attempts[a.id].stateRevision, 2);
  assert.equal(Object.keys(f.store.state.receipts).length, receiptsBefore + 2);
});

test("HTTP numeric policy is explicit; mapping failure cannot undo completed expiry/ordinary", async () => {
  const f = fixture({ numericPresentation: undefined }), s = await session(f), a = await start(f, s.access_token);
  const response = await submit(f, s.access_token, a.id);
  assert.equal(response.json.error.code, "GRADING_POLICY_UNRESOLVED");
  assert.equal(f.store.state.attempts[a.id].status, "submitted");
  assert.ok(f.store.state.attempts[a.id].ordinary);
  const bad = fixture({ numericPresentation: { policyId: "TEST_ONLY_BAD", toFiniteNumber: () => Infinity } });
  const b = await session(bad), attempt = await start(bad, b.access_token);
  assert.equal((await submit(bad, b.access_token, attempt.id)).json.error.code, "GRADING_POLICY_UNRESOLVED");
  assert.ok(!JSON.stringify(response.json).includes("numerator"));
});

test("HTTP projection strips private fields and history remains own-safe after group removal", async () => {
  const f = fixture(), s = await session(f), a = await start(f, s.access_token);
  (f.store.state.attempts[a.id] as unknown as Record<string, unknown>).staff_actor = "PRIVATE_SENTINEL";
  f.store.state.assignments[ids.assignment].reviewGate.internal_reason = "PRIVATE_SENTINEL";
  (f.store.state.people[ids.person].profile as unknown as Record<string, unknown>).raw_token = "PRIVATE_SENTINEL";
  await submit(f, s.access_token, a.id);
  delete f.store.state.grants[ids.person][ids.assignment];
  const history = await f.call("GET", `/exams/${ids.assignment}/history`, { token: s.access_token });
  assert.equal(history.status, 200);
  for (const path of ["/me", `/exams/${ids.assignment}`, `/attempts/${a.id}/result`]) {
    const wire = JSON.stringify((await f.call("GET", path, { token: s.access_token })).json);
    for (const field of ["PRIVATE_SENTINEL", "correctOptionId", "individualPoints", "numerator", '"published"']) {
      assert.ok(!wire.includes(field));
    }
  }
  assert.equal(history.json.data.attempts[0].score.ordinary.max_points, 2);
});

test("HTTP successor rejects old pending saves and never inherits predecessor bonus", async () => {
  const f = fixture(), s = await session(f), a = await start(f, s.access_token);
  await submit(f, s.access_token, a.id);
  const old = f.store.state.attempts[a.id], successorId = id(999);
  f.store.state.bonuses[a.id] = { calculationId: id(888), earned: ratio(5n), calculatedAt: clock };
  f.store.state.attempts[a.id] = { ...old, status: "cancelled" };
  f.store.state.cancellations[a.id] = { cancelledAt: clock, priorStatus: "submitted" };
  f.store.state.attempts[successorId] = { ...structuredClone(old), id: successorId, generation: 2,
    status: "in_progress", answers: [], ordinary: null, completedAt: null };
  const series = f.store.state.series[seriesKey(ids.person, ids.demo)];
  series.currentAttemptId = successorId; series.generation = 2; series.officialAttemptId = null;
  series.recoveryState = "active";
  series.recovery = { opensAt: clock, closesAt: clock + 10_000, durationMs: 60_000 };
  assert.equal((await save(f, s.access_token, a.id)).json.error.code, "ATTEMPT_SUPERSEDED");
  const result = await submit(f, s.access_token, successorId);
  assert.equal(result.json.data.statistical_bonus, null);
  const history = await f.call("GET", `/exams/${ids.assignment}/history`, { token: s.access_token });
  const [predecessor, successor] = history.json.data.attempts;
  assert.equal(predecessor.lifecycle_status, "cancelled");
  assert.equal(predecessor.score.statistical_bonus.earned_points, 5);
  assert.deepEqual(Object.keys(predecessor.cancellation).sort(), ["cancelled_at", "prior_status", "reason_code"]);
  assert.equal(successor.score.statistical_bonus, null);
});

test("HTTP parallel login consumes a proof once; rejected commit does not consume it", async () => {
  const f = fixture();
  const responses = await Promise.all([f.login(), f.login()]);
  assert.deepEqual(responses.map((r) => r.status).sort(), [200, 409]);
  assert.equal(Object.keys(f.store.state.families).length, 1);
  assert.equal(Object.keys(f.store.state.consumedInitData).length, 1);
  const failing = fixture();
  failing.store.failNextCommit = true;
  assert.equal((await failing.login()).status, 503);
  assert.equal(Object.keys(failing.store.state.consumedInitData).length, 0);
  assert.equal((await failing.login()).status, 200);
});

test("HTTP parallel start keys share one attempt and stale membership cannot replay it", async () => {
  const f = fixture(), s = await session(f);
  const paths = `/exams/${ids.assignment}/attempts`;
  const responses = await Promise.all(["start-key-0001", "start-key-0001", "different-start-key"]
    .map((key) => f.call("POST", paths, { token: s.access_token, key, body: { confirmed: true } })));
  assert.ok(responses.every((r) => r.status === 200));
  assert.equal(new Set(responses.map((r) => r.json.data.id)).size, 1);
  assert.equal(Object.keys(f.store.state.attempts).length, 1);
  f.store.state.grants[ids.person][ids.assignment].membershipEpoch++;
  assert.equal((await f.call("POST", paths, { token: s.access_token, key: "start-key-0001",
    body: { confirmed: true } })).status, 403);
});

test("HTTP profile length follows Unicode codepoints from JSON Schema, without changing roles", async () => {
  const f = fixture(), s = await session(f);
  const allowed = await f.call("PATCH", "/me", { token: s.access_token,
    body: { first_name: "😀".repeat(100), last_name: "Synthetic" } });
  assert.equal(allowed.status, 200);
  assert.equal(Array.from(allowed.json.data.first_name).length, 100);
  assert.equal((await f.call("PATCH", "/me", { token: s.access_token,
    body: { first_name: "😀".repeat(101), last_name: "Synthetic" } })).status, 422);
});

test("HTTP logout does not invent Refresh maxLength; malformed JSON has closed error envelope", async () => {
  const f = fixture(), s = await session(f);
  const unknown = await f.call("POST", "/auth/logout", { body: { refresh_token: "x".repeat(1025) } });
  assert.equal(unknown.status, 401);
  assert.equal(unknown.json.error.code, "REFRESH_INVALID");
  const malformed = await f.call("PATCH", "/me", { token: s.access_token, raw: "{" });
  assert.equal(malformed.status, 400);
  assert.equal(malformed.json.error.code, "MALFORMED_JSON");
});

test("HTTP error envelopes and successful wire conform to pinned provisional OpenAPI schemas", () => {
  const contract = JSON.parse(readFileSync(new URL("./student-contract.fixture.json", import.meta.url), "utf8"));
  assert.equal(contract.source.sha256, "51deb7a41d223559022dcb7e17ff24985bd328e51c4a87c797a02763bb801149");
  const python = `import json,sys,jsonschema
data=json.load(sys.stdin)
contract=data['contract']
for case in data['cases']:
    found=None
    for operation,definition in contract['operations'].items():
        method,path=operation.split(' ',1)
        import re
        if method==case['method'] and re.fullmatch(re.sub(r'\\{[^}]+\\}',r'[^/]+',path),case['path']):
            found=definition['responses'].get(str(case['status']))
            break
    schema=found or {'$ref':'#/components/schemas/Error'}
    root={'components':contract['components'],**schema}
    errors=list(jsonschema.Draft202012Validator(root,format_checker=jsonschema.FormatChecker()).iter_errors(case['json']))
    if errors: raise AssertionError(case['method']+' '+case['path']+' '+str(case['status'])+': '+str(errors[0]))
print('Pinned OpenAPI responses validated:',len(data['cases']))`;
  const output = execFileSync("python", ["-c", python],
    { input: JSON.stringify({ contract, cases: capturedReplies }), encoding: "utf8" });
  assert.match(output, /Pinned OpenAPI responses validated: \d+/);
  assert.ok(capturedReplies.length > 60);
});
