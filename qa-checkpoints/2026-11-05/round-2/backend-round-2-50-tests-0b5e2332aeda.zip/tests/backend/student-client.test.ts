import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createLocalStudentClient, STUDENT_CONTRACT_SHA256, StudentApiError, StudentClientProtocolError }
  from "../../packages/api-client/student-client.ts";
import { fixture, ids, signedInitData } from "./http-fixture.ts";

function client(f: ReturnType<typeof fixture>, transport = f.handler) {
  return createLocalStudentClient({ mode: "local_fixture", contractSha256: STUDENT_CONTRACT_SHA256,
    baseUrl: "http://local.invalid/api/v1", transport });
}

test("shared generated-type client completes all13 student operations against the local adapter", async () => {
  const f = fixture(), c = client(f);
  const session = (await c.telegramLogin({ init_data: signedInitData() })).data;
  const token = session.access_token;
  assert.equal((await c.me(token)).data.person_id, ids.person);
  assert.equal((await c.updateProfile(token, { first_name: "Local", last_name: "Synthetic" })).data.first_name, "Local");
  assert.equal((await c.exams(token)).data.length, 1);
  assert.equal((await c.exam(token, ids.assignment)).data.question_count, 2);
  const a = (await c.startAttempt(token, ids.assignment, { confirmed: true }, "client-start-key")).data;
  assert.equal((await c.saveAnswer(token, a.id, ids.question,
    { selected_option_id: ids.correct, expected_revision: 0 })).data.revision, 1);
  assert.equal((await c.resumeAttempt(token, a.id)).data.answers[0].revision, 1);
  const submitted = await c.submitAttempt(token, a.id, "client-submit-key");
  assert.equal(submitted.data.ordinary.percentage, 50);
  assert.equal(submitted.data.statistical_bonus, null);
  assert.deepEqual(await c.result(token, a.id), submitted);
  assert.equal((await c.history(token, ids.assignment)).data.attempts[0].lifecycle_status, "submitted");
  const refreshed = await c.refresh({ refresh_token: session.refresh_token });
  assert.equal((await c.logout({ accessToken: refreshed.data.access_token })).data.ok, true);
});

test("shared draft client rejects wrong contract hash/production host and has no native transport fallback", () => {
  let calls = 0;
  const transport = async () => { calls++; return new Response(); };
  const input = { mode: "local_fixture" as const, contractSha256: STUDENT_CONTRACT_SHA256,
    baseUrl: "http://local.invalid/api/v1", transport };
  assert.throws(() => createLocalStudentClient({ ...input, contractSha256: "wrong" }), /CONTRACT_HASH_MISMATCH/);
  // Negative test URLs/proofs below are synthetic; user:password is not a real credential.
  for (const baseUrl of ["https://api.invalid/api/v1", "https://example.com/api/v1",
    "http://local.invalid/other", "http://user:password@local.invalid/api/v1"]) {
    assert.throws(() => createLocalStudentClient({ ...input, baseUrl }), /INVALID_LOCAL_BASE_URL/);
  }
  assert.throws(() => createLocalStudentClient({ ...input, mode: "production" as never }), /DRAFT_CLIENT_LOCAL_ONLY/);
  assert.throws(() => createLocalStudentClient({ ...input, transport: undefined as never }), /INVALID_LOCAL_BASE_URL/);
  assert.equal(calls, 0);
});

test("shared client refresh is single-flight and never retries an already-attempted proof", async () => {
  const f = fixture();
  let refreshCalls = 0;
  const c = client(f, async (request) => {
    if (new URL(request.url).pathname.endsWith("/auth/refresh")) refreshCalls++;
    return f.handler(request);
  });
  const s = (await c.telegramLogin({ init_data: signedInitData() })).data;
  const [a, b] = await Promise.all([c.refresh({ refresh_token: s.refresh_token }), c.refresh({ refresh_token: s.refresh_token })]);
  assert.deepEqual(a, b);
  assert.equal(refreshCalls, 1);
  await assert.rejects(c.refresh({ refresh_token: s.refresh_token }), /REFRESH_PROOF_ALREADY_ATTEMPTED/);
  assert.equal(refreshCalls, 1);
});

test("lost refresh response is not retried; fresh Telegram proof is an explicit caller action", async () => {
  const f = fixture();
  let refreshCalls = 0;
  const c = client(f, async (request) => {
    const response = await f.handler(request);
    if (new URL(request.url).pathname.endsWith("/auth/refresh")) {
      refreshCalls++; throw new Error("synthetic lost response");
    }
    return response;
  });
  const s = (await c.telegramLogin({ init_data: signedInitData() })).data;
  await assert.rejects(c.refresh({ refresh_token: s.refresh_token }), /synthetic lost response/);
  await assert.rejects(c.refresh({ refresh_token: s.refresh_token }), /REFRESH_PROOF_ALREADY_ATTEMPTED/);
  assert.equal(refreshCalls, 1);
  const fresh = await c.telegramLogin({ init_data: signedInitData(4_000_000_001, "explicit-new-launch") });
  assert.equal((await c.me(fresh.data.access_token)).data.person_id, ids.person);
});

test("shared client preserves API code/request_id and never includes raw error body in its error", async () => {
  const f = fixture(), c = client(f);
  await assert.rejects(c.me("synthetic-invalid-proof"), (e: unknown) =>
    e instanceof StudentApiError && e.status === 401 && e.code === "SESSION_REVOKED" &&
    /^[0-9a-f-]{36}$/.test(e.requestId));
  const bad = client(f, async () => new Response(JSON.stringify({ error: {
    code: "FORBIDDEN", request_id: ids.person, message: "PRIVATE_SYNTHETIC_MARKER",
  } }), { status: 403 }));
  await assert.rejects(bad.me("synthetic-invalid-proof"), (e: unknown) =>
    e instanceof StudentApiError && !String(e).includes("PRIVATE_SYNTHETIC_MARKER"));
  const malformed = client(f, async () => new Response("not JSON", { status: 200 }));
  await assert.rejects(malformed.me("synthetic-invalid-proof"), StudentClientProtocolError);
});

test("shared client does not retry submit automatically; caller's same K recovers committed receipt", async () => {
  const f = fixture();
  let submitCalls = 0;
  const c = client(f, async (request) => {
    const response = await f.handler(request);
    if (new URL(request.url).pathname.endsWith("/submit") && ++submitCalls === 1) {
      throw new Error("synthetic lost submit response");
    }
    return response;
  });
  const s = (await c.telegramLogin({ init_data: signedInitData() })).data;
  const a = (await c.startAttempt(s.access_token, ids.assignment, { confirmed: true }, "client-start-key")).data;
  await assert.rejects(c.submitAttempt(s.access_token, a.id, "stable-submit-key"), /synthetic lost submit response/);
  assert.equal(submitCalls, 1);
  assert.equal(f.store.state.attempts[a.id].status, "submitted");
  const retry = await c.submitAttempt(s.access_token, a.id, "stable-submit-key");
  assert.equal(submitCalls, 2);
  assert.equal(retry.data.ordinary.earned_points, 0);
  assert.equal(f.store.state.attempts[a.id].stateRevision, 2);
});

test("shared client source slice retains13 draft operations and pinned full-source identity", () => {
  const source = JSON.parse(readFileSync(new URL("../../packages/api-client/student-openapi.json", import.meta.url), "utf8"));
  assert.equal(source["x-source"].full_openapi_sha256, STUDENT_CONTRACT_SHA256);
  assert.equal(source["x-source"].status, "PROVISIONAL_TEST_ONLY_NO_PRODUCTION_ACCEPTANCE");
  const operations = Object.values(source.paths).flatMap((p) => Object.keys(p as object)
    .filter((method) => ["get", "post", "put", "patch"].includes(method)));
  assert.equal(operations.length, 13);
  assert.equal(Object.keys(source.components.schemas).length, 43);
});
